# Slayers 2 Fishing Bot (Android) - v2.7

Screen-reading + touch automation for the fishing bar minigame (keep the white square inside the yellow-green box).
No injection, no memory reading. Captures the screen (MediaProjection), finds the two shapes by colour,
presses/holds through an Accessibility service. Works on Android 8+ (Galaxy S21: Android 11-14+).

**What was tested (in the author's sandbox):** the bar detector on a real 2400x1080 screenshot of the minigame
(found square y=725, box y=670 correctly); the tracking controller in a physics simulation (about 65-75% of the time
inside the box on two very different guessed game-physics models); XML/YAML validity and Java syntax.
**Not tested:** compiling against the Android SDK, and running on a real phone / in the real game. Do the checklist below.

## The app (v1.6)
Four tabs on the left rail:
- **Home** - big START/STOP, live status, rounds played, and a live mini-preview of what the bot sees
  (yellow box = target, white square = your indicator).
- **Setup** - five cards (Accessibility, screen capture, floating button, background use, notifications), each with a
  green/red chip and a button that opens the right settings page.
- **Tune** - "Pick on screen" for the cast point (tap the water), hold point, optional collect-button tap and the bar area
  (tap top then bottom of the bar), plus steppers/sliders for timing and steering. Everything saves instantly and applies live.
- **Guide** - how fishing works in Slayers 2 (permit, rod, minigame inputs, loot), from community guides, Sept 2026.

Flow the bot follows (confirmed in-game): press the hand-icon Cast button -> wait for the bite -> minigame starts by itself ->
short presses keep the white square inside the box (holding lifts, releasing lowers; the box is yellow outside, green inside) ->
HOLD the white finger Collect circle for ~2 s -> cast again.

### What changed in v2.7 (never press the Wall-Climb button)
- The trace showed the bot's collect press landing at (1090, 746): that was the Wall-Climb button, which looks like the collect button
  (white disc with a finger). Differences measured from your screenshots: the climb disc is about 90 px, a collect disc is 32-68 px
  (smaller the farther the fish is); the climb button is already on screen before the bite, the collect button only appears after it.
- The bot now (1) remembers every such disc that is on screen while it waits for a bite (the climb button), (2) after the minigame only
  accepts a NEW disc that is not at one of those places, (3) ignores any disc larger than "Largest collect button" (default 76 px,
  Tune), and (4) never presses the fixed fallback spot if a remembered button sits on or next to it.
- The disc finder also strips thin strokes before measuring, so a collect button that touches a name tag (as in your last screenshot,
  "Zebra Fish" under "Monster Hunter 2537") is still found; it also no longer mistakes the white text of the climb label for a disc.
- Trace "C" lines are now: x, y, disc diameter (0 = fixed spot), attempt.
- Tip: keep the Hold point away from the climb button (it sat about 60 px from the default hold point in your screenshot).

### What changed in v2.6 (collect button detection)
- Measured from the recording: the collect prompt is a bright white disc with a BLACK FINGER inside, its size depends on distance
  (about 35 px far away, 66 px close), it moves with the fish and can flicker for half a second at a time. The old finder only
  accepted 54-96 px discs. The new finder accepts 24-100 px, requires the black finger (30-40% dark pixels in the middle) and so
  ignores the cast button (a white hand, about 9% dark), tracks the button from frame to frame, waits up to 7 s for it, lets it settle
  for 120 ms, then holds at its latest position (default hold 2.4 s) and retries up to 3 times if it is still there.
- Replayed over your recording: found in every window where the prompt is visible, no detections at all during the minigame, nothing
  on the normal minigame screenshots, and found on your catch screenshot at the right spot.
- The saved trace now has "C" lines (x, y, found by the detector 1/0, attempt) so collect attempts can be checked.

### What changed in v2.5 (from the first saved trace)
- The trace showed the bot pressed only 6 times in 31 seconds. A brief detection dropout (about 1 s) made it think the minigame had
  ended, so it went into the collect routine (waiting for a button that was not there, then holding a fixed spot for ~2 s three times)
  while the real minigame carried on unattended. The fixed-spot holds even lifted the square on their own.
  Fixes: the bar must be gone for 1.5 s before a minigame counts as finished; a "minigame" shorter than 1.5 s is treated as a misread;
  the collect routine and the cast wait now stop immediately when the bar comes back.
- Perception was flickering: the box was sometimes read as only 2-6 px tall and a false "square" sat at one spot for seconds, producing
  huge velocity spikes (that is why it pressed 250 ms at zero error). Now: capture at full resolution, the square must be a 14-62 px
  tall run (gaps up to 8 px are merged because the box outline cuts through the square), the candidate nearest to the previous position
  wins, sudden jumps are ignored, partial box readings are completed with the known box height, and velocity is clamped.
  Replayed over your recording: square and box found in 100% of frames, 0% wrong.
- The trace also measured the phone's press dead time: only 8-27 ms. Control defaults were re-tuned for that (hover 60, response 80,
  damping 8, auto-balance 4, presses 70-250 ms).

### What changed in v2.4 (measured from a screen recording of real play)
- **Detector bug fixed.** Replaying the old detector over the recording showed it misread the square's position in 57% of frames:
  while the square sat inside the green box it turns light green, which the old test did not count as "white", so the bot read the
  bar's top cap instead and released the finger exactly when it should have held. The new test counts light-green too and ignores
  the thin top cap (0% misreads on the same frames, 94% detected).
- **Real game physics measured:** holding lifts the square slowly (about 0.4 bar/s) while gravity pulls it down about twice as fast
  (about 0.8 bar/s), with about 0.3 s of smoothing. So the finger must be down about 2/3 of the time just to stay level; the old
  hover of 40% made the square sag. New defaults: hover 62, response 80, damping 8, auto-balance 4.
- **Press length scales with the push needed** (70 ms for tiny corrections up to 250 ms for hard pushes) because every press has dead
  time. In the author's simulation of the measured physics, in-box time went from about 29% (old settings) to about 90% (guesses
  about phone latency, so treat as indicative).
- **Collect button is found, not assumed.** In the recording the collect prompt never showed at the saved spot (and it follows the fish),
  so after a catch the bot now scans for the round white button (up to 5 s), holds it ~2 s, checks it vanished and retries up to 3 times.
- Default press style is "Presses" (consistent). Auto-learning is still available in Tune.

### What changed in v2.3 (80% but failed at the end)
- **Auto press style**: the bot now tries three ways of pressing (balanced / adaptive / smooth hold) in 6-second windows, scores each by
  how long the square stayed inside the box, remembers the scores and favours the best one. Tune > Press style lets you force one.
  Smooth hold drops out automatically if the phone does not respond to it.
- **Adaptive style**: longer presses when the square is far below the box, shorter ones near it (in the author's simulation this helped a lot
  on games where the square reacts instantly, and cost a little on games with heavy inertia, which is why it is learned rather than fixed).
- **Trace**: Home > "Save last fishing trace" writes Download/slayers_trace.csv with the square/box positions about 60 times a second and
  every press. Attach it in the chat to get the settings tuned to your game's real physics.

### What changed in v2.2
- Screen capture can now really be stopped: **Stop screen capture** on Home and in Setup, and **STOP capture** in the
  notification. It ends the bot, the capture (the recording indicator disappears), the floating button and the notification.
  You can also stop it from Android's own status-bar "stop sharing" chip. Grant capture again the next time you fish.

### What changed in v2.1 (overshoots / doesn't reach / random misses)
- Screenshots from v2.0 showed "g 50/86": the phone cancelled 86 of 136 presses, because each new press was sent before the
  previous one finished. Lost presses explain "sometimes it doesn't reach" and "sometimes it doesn't work the way it should".
- v2.1 sends ONE press, waits until the phone says it finished, then decides again. Nothing is cancelled any more.
- New defaults: press length 80 ms, check again after 30 ms, hover 40, response 40, damping 12.
- Home now shows "press lag": the phone's dead time per press. In the author's simulation (guessed game physics, latency 30-60 ms)
  this style kept the square in the box about 60% of the time versus about 30% for the v2.0 style.
- Tune > Timing has "Press length" (longer = stronger push, slower to correct) and "Check again after".

### What changed in v2.0 (square did not move with v1.9)
- Back to the method that worked: **plain presses** are the default again (react every 75 ms, hover 45, response 40, damping 12,
  with the target-aware damping). "Smooth hold" is now an opt-in experiment (Tune > Steering).
- New **press response check**: if the bot presses hard for ~0.7 s twice and the square does not rise, it first switches smooth hold off
  by itself; if plain presses do not move it either, Home and the floating button show "NO RESPONSE" so you know the game is ignoring
  the Hold point (move it with Tune > Pick).

### What changed in v1.9 (fixes "it doesn't catch up with the box")
- A longer reaction time is SLOWER, not faster (0.25 s = 4 decisions a second). v1.9 goes the other way: it decides every 50 ms.
- **Smooth hold**: the finger used to be lifted and re-placed on every press (a gap each time), so the square could not climb at full speed.
  Now one touch stays down between presses (chained 40 ms strokes) and is lifted only when the square needs to drop.
  Tune > Steering > "Smooth hold". If the phone rejects chained strokes, the bot automatically falls back to plain presses
  (the floating button then says "pulses").
- New defaults for this mode: hover 40, response 40, damping 18, react every 50 ms.
- In the author's simulation (fast-moving box, guessed physics) time-in-box went from about 58% (old style, 90 ms) and 39% (250 ms) to about 70-73%.

### What changed in v1.8 (superseded)
- The bot now decides **every 250 ms** (Tune > "React every"). Each decision is delivered as short 50 ms presses
  (Tune > "Press pulses") so the square moves smoothly. Trade-off: in the author's simulation a 250 ms cycle keeps the square in
  the box roughly 54% of the time versus about 84% at 75 ms. If your progress bar fills slowly, set "React every" back to 75
  and raise Damping to about 12.

### What changed in v1.7
- Cast uses the hand-icon button (Tune > Cast button) and Collect holds the white finger circle for 2 s (adjustable).
  Default positions come from a 2400x1080 screenshot; the buttons sit next to your character, so use Tune > Pick if yours differ.
- Box detection now handles BOTH colours (yellow while outside, green while the square is inside).
- Faster steering: reacts every 75 ms (was 90) and damps against the target's own movement. In the author's simulation this raised
  the share of time the square stayed inside the box from about 71% to 84% (simulated physics, not the real game).
- Shorter idle delays between rounds. Tune > Reaction cycle lets you go faster or slower.

## Updating the app
Each GitHub build is signed with a fresh debug key, so **uninstall the old version first**, then install the new APK.

## Reading the floating button (v1.5)
The button shows a second line: `ACCESS OFF` (Accessibility service isn't connected), `no bar yet` (waiting for a bite),
`bar ok hold 80% g 12/3` (bar found; "g ok/cancelled" = gestures the phone accepted / dropped).
If the bar is found and gestures are accepted but the square doesn't move, the game isn't reacting to the injected hold:
move the Hold X/Y point. **Long-press START** (idle, bar on screen) sends a 2-second test hold at the hold point.

## Test checklist (do this in order)
1. Build succeeds (green check in GitHub Actions). If red, screenshot the failing step.
2. App opens, all 4 setup buttons work, "Capture: ready" shows after granting screen capture.
3. Go to a fishing bar in the game, open the app (or watch the floating button): the app's status line must say
   "Bar detected: square y=..., target y=...". If not, fix the scan region first - nothing else matters until it does.
4. Tap START. Watch the first catches: does the square rise when it's below the box? If it goes the wrong way, tick Invert.
5. Wobbles: lower P or raise D. Sinks/floats away: change Hover %. Slow to correct: raise P.

## Build the APK from your phone only (GitHub, free)
1. Make a free account at github.com and create a new repository (private is fine).
2. In the repo choose "uploading an existing file" (or Add file > Upload files) and upload THIS ZIP as one file. Commit.
3. Add file > Create new file. Name it `.github/workflows/build.yml` (typing the slashes makes the folders) and paste:

```
name: Build APK
on: workflow_dispatch
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: for z in *.zip; do unzip -q -o "$z"; done
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'
      - run: cd slayers2_mobile_macro && gradle assembleDebug --no-daemon
      - uses: actions/upload-artifact@v4
        with:
          name: fishing-bot-apk
          path: slayers2_mobile_macro/app/build/outputs/apk/debug/app-debug.apk
```
4. Commit, open the Actions tab > "Build APK" > Run workflow. Wait a few minutes for the green check.
5. Open the finished run, download the `fishing-bot-apk` artifact (a .zip), extract it in My Files, install app-debug.apk.
If the run fails, open it and screenshot the red error step.

## Install on a Galaxy S21
- Settings > Security and privacy > Auto Blocker: turn it OFF (it blocks installing APKs).
- Allow "Install unknown apps" for the app you opened the APK with (Chrome / My Files).
- Open the bot > "1. Enable Accessibility service". If the switch is greyed out: back out, open Settings > Apps >
  Slayers 2 Fishing Bot > menu (top right) > Allow restricted settings, then try again.
- "2. Grant screen capture": choose ENTIRE screen (not "one app"), then Start now.
- "3. Allow background use": set the app's battery to Unrestricted so One UI does not kill it mid-run.
- "4. Allow floating START/STOP button": turn on "Allow display over other apps" for the bot.
- The S21 screen is 2400x1080, which is what the defaults were tuned on. Keep the phone in landscape.

## Use while playing Roblox
- A round **START** button floats over the game (drag it anywhere; it remembers the spot). Tap it: a short countdown
  runs, then the bot fishes. The button turns red and says **STOP**.
- **Stop:** tap the red button, or press **Volume Down** (works instantly; volume only acts as a stop key while the bot runs),
  or use the notification.
- While the bot runs it sends its own touches, so you can't play manually at the same time.

## First-time calibration
1. In the app, check the live line "Bar detected: ..." while a fishing bar is on screen. If "not detected", adjust the
   scan region so it covers the inside of the bar (not the outline).
2. Open Slayers 2, stand at the fishing spot with the rod ready, tap the floating START button.

## What you probably need to adjust
- **Hold point** (Hold X/Y): an empty spot where a press controls the minigame. Never the Exit button or joystick.
- **Invert**: tick it if holding moves the square DOWN (default assumes holding moves it UP).
- **Cast / collect**: the bot taps the hold point to cast and the "collect tap" point after a catch. These are guesses.
- **Wobbling**: lower P, raise D. **Reacts late / drifts**: raise P. **Sinks while "level"**: raise Hover % (I auto-balances slowly).

## Risk
Automating gameplay may violate the game's or Roblox's rules and can get an account suspended. Use at your own risk.
