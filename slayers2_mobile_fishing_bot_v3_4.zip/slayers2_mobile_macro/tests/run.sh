#!/bin/sh
# Offline tests of the plain-Java bot logic (needs only a JDK, no Android SDK, no libraries).
set -e
cd "$(dirname "$0")/.."
SRC=app/src/main/java/com/slayers2/fishingbot
OUT=${TMPDIR:-/tmp}/s2bot-tests
rm -rf "$OUT" && mkdir -p "$OUT"
# only the classes that do not touch Android
PURE="BotState Config Trace Fmt Clock RealClock Pressor Frame KnownButtons BarDetector DiscFinder FrameProcessor Controller BotEngine"
FILES=""
for n in $PURE; do FILES="$FILES $SRC/$n.java"; done
javac -Xlint:all -d "$OUT" $FILES tests/com/slayers2/fishingbot/*.java
java -Xmx1g -cp "$OUT" com.slayers2.fishingbot.AllTests
