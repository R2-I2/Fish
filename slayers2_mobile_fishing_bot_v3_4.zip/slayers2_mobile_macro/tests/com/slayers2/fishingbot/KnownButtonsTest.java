package com.slayers2.fishingbot;

final class KnownButtonsTest {
    static void run() throws Exception {
        T.section("KnownButtons");
        T.resetBotState();
        KnownButtons k = new KnownButtons();
        final String[] saved = {null};
        k.setStore(s -> saved[0] = s);
        T.check("add taught", k.addTaught(100, 100, 60));
        T.check("duplicate within 40 px is ignored", !k.addTaught(120, 130, 60));
        T.check("taughtN published", BotState.taughtN == 1 && k.taughtCount() == 1);
        T.check("saved text", "100,100,60;".equals(saved[0]));
        for (int i = 0; i < 20; i++) k.addTaught(500 + i * 100, 100, 60);
        T.check("at most 8 taught buttons", k.taughtCount() == 8);
        String ser = k.serializeTaught();
        KnownButtons k2 = new KnownButtons();
        k2.loadTaught(ser);
        T.check("save/load roundtrip", k2.taughtCount() == 8 && k2.serializeTaught().equals(ser));
        k2.loadTaught("garbage;1,2;a,b,c;5,6,7;");
        T.check("bad entries skipped", k2.taughtCount() == 1);
        k2.clearTaught();
        T.check("clear", k2.taughtCount() == 0 && BotState.taughtN == 0);

        KnownButtons b = new KnownButtons();
        b.addBaseline(300, 300, 90, 1000);
        T.check("big button matched by size alone, anywhere", b.isKnown(1800, 900, 95, 2000));
        T.check("big button, other size", !b.isKnown(300, 300, 60, 2000));
        b.addBaseline(700, 400, 44, 1000);
        T.check("small button near the same place", b.isKnown(720, 410, 46, 2000));
        T.check("small button far away", !b.isKnown(1500, 400, 44, 2000));
        T.check("baseline expires after 10 minutes", !b.isKnown(720, 410, 46, 1000 + 600001));
        KnownButtons f = new KnownButtons();
        for (int i = 0; i < 16; i++) f.addBaseline(100 + i * 100, 200 + i * 50, 30, 1000 + i);
        T.check("16 baseline entries", f.baselineCount() == 16);
        f.addBaseline(2300, 900, 30, 5000);
        T.check("full list replaces the oldest", f.baselineCount() == 16 && !f.isKnown(100, 200, 30, 5001) && f.isKnown(2300, 900, 30, 5001));

        // the capture thread adds/queries while the main thread forgets: must not throw or corrupt
        final KnownButtons s = new KnownButtons();
        final Throwable[] err = {null};
        Thread[] th = new Thread[4];
        final long end = System.currentTimeMillis() + 400;
        for (int t = 0; t < th.length; t++) {
            final int id = t;
            th[t] = new Thread(() -> {
                try {
                    int i = 0;
                    while (System.currentTimeMillis() < end) {
                        i++;
                        if (id == 0) s.addTaught((i * 97) % 2000, (i * 53) % 900, 40 + i % 50);
                        else if (id == 1) s.clearTaught();
                        else if (id == 2) s.addBaseline((i * 31) % 2000, (i * 17) % 900, 40 + i % 50, i);
                        else s.isKnown((i * 13) % 2000, (i * 7) % 900, 44, i);
                        if (s.taughtCount() > 8 || s.baselineCount() > 16) throw new IllegalStateException("overflow");
                    }
                } catch (Throwable e) { err[0] = e; }
            });
            th[t].start();
        }
        for (Thread t : th) t.join();
        T.check("concurrent use is safe" + (err[0] == null ? "" : " " + err[0]), err[0] == null);
    }
}
