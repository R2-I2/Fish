package com.slayers2.fishingbot;

import java.util.function.Consumer;

/** Runs the whole bot (state machine + controller) against the fake game in virtual time. */
final class EngineTest {
    static final class Run {
        World w; Config c; BotEngine eng;
        long presses(long len) {
            long n = 0;
            for (String line : w.log.toString().split("\n")) if (line.contains("PRESS_WAIT") && line.endsWith(" " + len)) n++;
            return n;
        }
        boolean logHas(String s) { return w.log.indexOf(s) >= 0; }
    }

    static Run run(Consumer<World> world, Consumer<Config> cfg) {
        T.resetBotState();
        VClock.reseed();
        Run r = new Run();
        r.w = new World();
        VClock.w = r.w;
        final World w = r.w;
        Clock clock = new T.SimClock();
        Pressor pr = new Pressor() {
            public boolean pressAndWait(int x, int y, long ms) { return w.pressAndWait(x, y, ms); }
            public boolean hold(int x, int y, long ms) { return w.hold(x, y, ms); }
            public void setHold(int x, int y, boolean d) { w.setHold(x, y, d); }
            public void release() { w.release(); }
        };
        final boolean[] scan = {false};
        BotEngine.Vision vision = new BotEngine.Vision() {
            public void setScanCollect(boolean on) { scan[0] = on; }
            public void setScanBaseline(boolean on) {}
        };
        Controller ctl = new Controller(clock, new Controller.ArmStore() {
            public void load(double[] s, int[] t) { for (int i = 0; i < 3; i++) { s[i] = -1; t[i] = 0; } }
            public void save(double[] s, int[] t) {}
        }, VClock::rnd);
        r.c = T.s21();
        final Config c = r.c;
        r.eng = new BotEngine(clock, () -> pr, () -> c, vision, ctl, null);
        world.accept(r.w);
        cfg.accept(c);
        r.w.cfg = c;
        r.w.scanFlag = () -> scan[0];
        r.w.onLimit = r.eng::shutdown;
        BotState.startedAt = clock.now();
        r.eng.reset(clock.now() + c.startDelay * 1000L);
        BotState.running = true;
        r.eng.run();
        return r;
    }

    static void run() {
        T.section("BotEngine + Controller (fake game, virtual time)");

        Run n = run(w -> w.limit = 120000, c -> c.style = 1);
        T.check("normal: several fish collected (" + n.w.collectsDone + ")", n.w.collectsDone >= 4);
        T.check("normal: it casts again after each catch (" + n.w.casts + " casts)", n.w.casts >= n.w.collectsDone);
        double share = n.w.insideMs / (double) Math.max(1, n.w.barMs);
        // Regression guards: these are the values v3.3 reaches in this fake game (which only follows your measured numbers), not goals.
        T.check("normal: square inside the box " + Math.round(share * 100) + "% of the time (v3.3: 16%, guard >= 12%)", share >= 0.12);
        T.check("normal: collect holds are 2400 ms", n.presses(2400) == n.w.collectsDone);

        Run sm = run(w -> w.limit = 80000, c -> c.style = 2);
        T.check("smooth hold: used and collects", sm.logHas("HOLD_DOWN") && sm.w.collectsDone >= 2);
        double shs = sm.w.insideMs / (double) Math.max(1, sm.w.barMs);
        T.check("smooth hold: inside the box " + Math.round(shs * 100) + "% of the time (v3.3: 97%, guard >= 90%)", shs >= 0.90);

        Run nb = run(w -> { w.biteDelay = 10_000_000; w.limit = 120000; }, c -> { c.style = 1; c.failWait = 2000; });
        T.check("no bite: stops after 6 casts", !BotState.running && BotState.status.contains("no bite after 6 casts") && BotState.casts == 6);

        Run nc = run(w -> { w.collectAppears = false; w.limit = 70000; }, c -> c.style = 1);
        T.check("no collect button: never presses blindly", nc.presses(2400) == 0);
        T.check("no collect button: gives up after about 10 s and recasts (" + nc.w.casts + " casts)", nc.w.casts >= 2);

        Run br = run(w -> { w.secondBarGap = 3000; w.limit = 90000; }, c -> c.style = 1);
        T.check("bar returns while collecting: keeps playing, collects after the second bar", br.w.collectsDone >= 1 && br.presses(2400) == br.w.collectsDone);

        Run as = run(w -> w.limit = 150000, c -> { c.style = 1; c.autoStopMin = 1; });
        T.check("auto-stop after the set time", !BotState.running && BotState.status.startsWith("Auto-stop"));

        Run co = run(w -> w.limit = 60000, c -> { c.style = 1; c.collectOn = false; });
        T.check("collect off: no collect presses, still recasts", co.presses(2400) == 0 && co.w.casts >= 2);

        Run ms = run(w -> { w.barDur = 1200; w.limit = 50000; }, c -> c.style = 1);
        T.check("a 1.2 s 'minigame' is a misread: no collect, no round counted", ms.presses(2400) == 0 && BotState.rounds == 0);

        Run un = run(w -> { w.responsive = false; w.limit = 60000; }, c -> c.style = 0);
        T.check("game ignores smooth hold: falls back to plain presses (driverFails " + BotState.driverFails + ")", BotState.driverFails >= 100 || BotState.response < 0 || un.logHas("PRESS_WAIT"));

        Run inv = run(w -> w.limit = 60000, c -> { c.style = 1; c.invert = true; });
        double ish = inv.w.insideMs / (double) Math.max(1, inv.w.barMs);
        T.check("inverted game: inside the box " + Math.round(ish * 100) + "% (v3.3: 28%, guard >= 20%)", ish >= 0.20);
    }
}
