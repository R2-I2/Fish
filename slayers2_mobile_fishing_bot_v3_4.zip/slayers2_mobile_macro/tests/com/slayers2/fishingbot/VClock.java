package com.slayers2.fishingbot;

/** Virtual time + deterministic random numbers, shared by the legacy (v3.3) run and the new run. */
public final class VClock {
    public static World w;
    private static long seed = 12345;
    public static long now() { return w.t; }
    public static void sleep(long ms) { w.advance(ms); }
    public static double rnd() { seed = (seed * 6364136223846793005L + 1442695040888963407L); return ((seed >>> 11) & ((1L << 53) - 1)) / (double) (1L << 53); }
    public static void reseed() { seed = 12345; }
}
