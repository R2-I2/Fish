package com.slayers2.fishingbot;

import java.util.function.BooleanSupplier;

/** A scripted fake game: bite after a cast, a minigame bar that reacts to presses, a collect button, with virtual time. */
public final class World {
    // ---- scenario
    public boolean responsive = true;
    public long biteDelay = 3000, barDur = 15000, collectDelay = 1000, secondBarGap = -1, secondBarDur = 5000;
    public boolean collectAppears = true;
    public long limit = 60000;
    public Config cfg;
    public BooleanSupplier scanFlag = () -> false;
    public Runnable onLimit = () -> {};

    // ---- state
    public long t = 1_000_000;
    private final long t0 = t;
    public final StringBuilder log = new StringBuilder();
    private double pos = 0.5;                 // square position, 0 top .. 1 bottom
    private boolean down, hold;               // finger down (press in progress / smooth hold)
    private long cycleStart = -1;             // when the bite is due
    private long b1s = -1, b1e = -1, b2s = -1, b2e = -1, buttonAt = -1;
    private boolean collected = false, armed = false;
    private String lastSnap = "";
    public int collectsDone = 0, casts = 0;
    public long barMs = 0, insideMs = 0;   // time the bar was on screen / the square was inside the box

    private void p(String s) { log.append(t - t0).append(' ').append(s).append('\n'); }

    // ---------------------------------------------------------------- time
    public void advance(long ms) {
        long end = t + ms;
        while (t < end) {
            long step = Math.min(16, end - t);
            physics(step);
            t += step;
            publish();
            snap();
            if (t - t0 >= limit) onLimit.run();
        }
    }

    private boolean inBar() { return (t >= b1s && t < b1e) || (b2s >= 0 && t >= b2s && t < b2e); }
    private boolean button() { return collectAppears && buttonAt >= 0 && t >= buttonAt && !collected; }

    private void physics(long step) {
        if (!inBar()) return;
        double dt = step / 1000.0;
        boolean lift = responsive && (down || hold);
        if (cfg.invert) lift = !lift;
        if (lift) pos -= 0.40 * dt; else pos += 0.80 * dt;
        if (!responsive) pos = 0.5 + 0.2 * Math.sin((t - t0) / 700.0);
        pos = Math.max(0, Math.min(1, pos));
    }

    private void publish() {
        if (inBar()) {
            double tp = 0.5 + 0.22 * Math.sin((t - t0) / 1500.0);
            BotState.indicatorY = cfg.y + pos * cfg.h;
            BotState.targetY = cfg.y + tp * cfg.h;
            BotState.targetH = 62;
            BotState.lastSeen = t;
            barMs += 16;
            if (Math.abs(BotState.indicatorY - BotState.targetY) < BotState.targetH / 2) insideMs += 16;
        }
        if (button() && scanFlag.getAsBoolean()) {
            BotState.collectX = 1560 + (int) ((t / 500) % 3) * 4;
            BotState.collectY = 640;
            BotState.collectD = 40;
            BotState.collectTime = t;
        }
    }

    private void snap() {
        String s = BotState.status + "|" + BotState.note + "|r" + BotState.rounds + "|c" + BotState.casts + "|resp" + BotState.response
                + "|df" + BotState.driverFails + "|" + BotState.styleInfo + "|run" + BotState.running;
        if (!s.equals(lastSnap)) { lastSnap = s; p("STATE " + s); }
    }

    // ---------------------------------------------------------------- the phone's touch injector
    private void mark(String what, int x, int y, long ms) { p(what + " " + x + " " + y + " " + ms); }

    public boolean pressAndWait(int x, int y, long ms) {
        mark("PRESS_WAIT", x, y, ms);
        final long len = Math.max(20, ms);
        hold = false;
        down = true;
        advance(len + 15);
        down = false;
        BotState.gOk++;
        BotState.pressLagMs = (int) (BotState.pressLagMs * 0.7 + 15 * 0.3);
        if (button() && Math.abs(x - BotState.collectX) <= 40 && Math.abs(y - BotState.collectY) <= 40 && len >= 2000) {
            collected = true; collectsDone++;
            p("COLLECTED");
        }
        return true;
    }

    public boolean hold(int x, int y, long ms) {
        mark("HOLD", x, y, ms);
        casts++;
        if (cfg != null && Math.abs(x - cfg.castX) <= 40 && Math.abs(y - cfg.castY) <= 40 && (b1s < 0 || collected || t >= b1e && buttonAt < 0)) {
            // a cast starts a new round
            long bite = t + biteDelay;
            b1s = bite; b1e = bite + barDur;
            if (secondBarGap >= 0) { b2s = b1e + secondBarGap; b2e = b2s + secondBarDur; } else { b2s = -1; b2e = -1; }
            long last = b2s >= 0 ? b2e : b1e;
            buttonAt = collectAppears ? last + collectDelay : -1;
            collected = false;
            p("BITE_DUE " + (bite - t0));
        }
        return true;
    }

    public void setHold(int x, int y, boolean want) {
        if (hold != want) mark(want ? "HOLD_DOWN" : "HOLD_UP", x, y, 0);
        hold = want;
    }

    public void release() { if (hold) p("RELEASE"); hold = false; }
}
