package com.slayers2.fishingbot;

/** A scripted sequence of synthetic 2400x1080 frames that exercises the bar detector and the round-button logic. */
public final class VisionScript {
    public interface Driver {
        void frame(byte[] rgba);
        void scanCollect(boolean on);
        void scanBaseline(boolean on);
        void phase(int state);       // 1 = waiting for a bite (before), 2 = playing / finishing (after)
        void teach(long ms);
        void dump(String tag);
    }

    static final int W = 2400, H = 1080;
    static byte[] bg;
    static long seed = 99;
    static int rnd(int n) { seed = seed * 6364136223846793005L + 1442695040888963407L; return (int) ((seed >>> 33) % n); }

    static byte[] background() {
        if (bg != null) return bg;
        bg = new byte[W * H * 4];
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
            int o = (y * W + x) * 4;
            bg[o] = (byte) (20 + (x * 7 + y * 13) % 25); bg[o + 1] = (byte) (60 + (x * 3 + y * 5) % 30); bg[o + 2] = (byte) (90 + (x + y) % 40); bg[o + 3] = (byte) 255;
        }
        rect(bg, 1760, 150, 80, 620, 12, 27, 46);      // bar track
        return bg;
    }

    static void rect(byte[] d, int x, int y, int w, int h, int r, int g, int b) {
        for (int yy = Math.max(0, y); yy < Math.min(H, y + h); yy++) for (int xx = Math.max(0, x); xx < Math.min(W, x + w); xx++) {
            int o = (yy * W + xx) * 4; d[o] = (byte) r; d[o + 1] = (byte) g; d[o + 2] = (byte) b; d[o + 3] = (byte) 255;
        }
    }

    static void ellipse(byte[] d, double cx, double cy, double rx, double ry, int r, int g, int b) {
        for (int yy = (int) (cy - ry) - 1; yy <= cy + ry + 1; yy++) for (int xx = (int) (cx - rx) - 1; xx <= cx + rx + 1; xx++) {
            if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
            double dx = (xx - cx) / rx, dy = (yy - cy) / ry;
            if (dx * dx + dy * dy <= 1) { int o = (yy * W + xx) * 4; d[o] = (byte) r; d[o + 1] = (byte) g; d[o + 2] = (byte) b; d[o + 3] = (byte) 255; }
        }
    }

    /** kind: 0 = letters only (collect), 1 = tall icon (climb) */
    static void button(byte[] d, int cx, int cy, int dia, int kind) {
        ellipse(d, cx, cy, dia / 2.0, dia / 2.0, 245, 245, 245);
        ellipse(d, cx, cy, dia * 0.15, dia * 0.28, 10, 10, 10);                         // the black finger
        rect(d, (int) (cx + 0.75 * dia), (int) (cy - 0.4 * dia), (int) (1.7 * dia), (int) (0.8 * dia), 8, 8, 12);   // dark label pill
        for (int i = 0; i < 5; i++) rect(d, (int) (cx + 1.0 * dia + i * 0.22 * dia), (int) (cy - 0.17 * dia), Math.max(2, (int) (0.09 * dia)), (int) (0.35 * dia), 240, 240, 240);
        if (kind == 1) rect(d, (int) (cx + 1.0 * dia), (int) (cy - 0.34 * dia), Math.max(3, (int) (0.13 * dia)), (int) (0.68 * dia), 240, 240, 240);
    }

    static void bar(byte[] d, double sq, double box, boolean withSq, boolean topEdge, boolean bottomEdge, boolean glare) {
        int bc = (int) box, h = 62;
        if (topEdge) rect(d, 1770, bc - h / 2, 60, 3, 235, 205, 25);
        if (bottomEdge) rect(d, 1770, bc + h / 2 - 3, 60, 3, 235, 205, 25);
        rect(d, 1770, bc - h / 2, 3, h, 235, 205, 25);
        rect(d, 1827, bc - h / 2, 3, h, 235, 205, 25);
        if (withSq) rect(d, 1782, (int) sq - 20, 36, 40, 196, 197, 199);
        if (glare) rect(d, 1775, 300, 50, 150, 230, 230, 235);
    }

    static void noise(byte[] d, int n) {
        for (int i = 0; i < n; i++) {
            int x = rnd(W - 4), y = 170 + rnd(780);
            rect(d, x, y, 2, 2, 250, 250, 250);
            int x2 = rnd(W), y2 = rnd(H);
            rect(d, x2, y2, 1, 1, 255, 255, 255);
        }
    }

    public static void run(Driver dr, World clock) {
        seed = 99;
        double t = 0;
        // ---- A: waiting for a bite, the climb button (90 px) and a small disc (44 px) are on screen
        dr.phase(1); dr.scanBaseline(true); dr.scanCollect(false);
        for (int i = 0; i < 60; i++) {
            byte[] f = background().clone();
            button(f, 1500 + (i % 7) * 6, 500, 90, 1);
            button(f, 700, 400, 44, 0);
            noise(f, 30);
            rect(f, 1000, 600, 60, 3, 250, 250, 250);   // a thin name-tag stroke
            clock.t += 16; dr.frame(f); dr.dump("A" + i);
        }
        // ---- B: the minigame
        dr.phase(2);
        double sq = 500, box = 450;
        for (int i = 0; i < 220; i++) {
            t = i * 0.016;
            sq = 450 + 160 * Math.sin(t * 1.9);
            box = 440 + 120 * Math.sin(t * 0.8);
            byte[] f = background().clone();
            boolean withSq = !(i % 37 == 5), top = !(i % 29 == 7), bot = !(i % 31 == 3);
            double sqUse = sq;
            if (i == 90 || i == 91) sqUse = sq + 200;      // a misread jump
            bar(f, sqUse, box, withSq, top, bot, i % 53 == 11);
            if (i < 40) button(f, 1500, 500, 90, 1);       // the climb button still there
            if (i >= 20 && i < 60) button(f, 1100, 650, 44, 0);   // a small disc right after the bar appeared
            noise(f, 20);
            clock.t += 16; dr.frame(f); dr.dump("B" + i);
            if (i == 150) clock.t += 380;                  // a short gap in time
        }
        // ---- bar gone: a 1.2 s gap, then the collect scan
        clock.t += 1200;
        dr.scanBaseline(false); dr.scanCollect(true);
        for (int i = 0; i < 80; i++) {
            byte[] f = background().clone();
            button(f, 1450 + (i % 9) * 10, 520 + (i % 5) * 4, 90, 1);          // climb (too big)
            button(f, 1150 + (i / 10) * 12, 640 - (i / 8) * 5, 44, 0);          // the collect button, drifting
            if (i >= 20) button(f, 720, 410, 46, 0);                             // looks like the small baseline disc (known)
            if (i >= 30) button(f, 400, 800, 60, 1);                             // tall climb icon in the label
            if (i >= 50 && i < 54) button(f, 1900, 300, 70, 0);                  // something else, bigger than the smallest
            noise(f, 25);
            clock.t += 16; dr.frame(f); dr.dump("C" + i);
        }
        dr.scanCollect(false);
        // ---- D: teach the climb button
        dr.phase(1);
        dr.teach(1500);
        for (int i = 0; i < 110; i++) {
            byte[] f = background().clone();
            button(f, 1200 + (i % 3) * 5, 300, 60, 1);
            if (i > 30) button(f, 2000, 800, 40, 1);
            noise(f, 10);
            clock.t += 16; dr.frame(f); dr.dump("D" + i);
        }
        dr.scanCollect(true);
        for (int i = 0; i < 40; i++) {
            byte[] f = background().clone();
            button(f, 1230, 340, 62, 0);      // matches the taught 60 px button by place and size -> ignored
            button(f, 900, 700, 42, 0);       // the real one
            clock.t += 16; dr.frame(f); dr.dump("E" + i);
        }
        dr.scanCollect(false);
        // ---- F: region tiny / nothing on screen
        for (int i = 0; i < 10; i++) { clock.t += 16; dr.frame(background().clone()); dr.dump("F" + i); }
    }

    public static String snap() {
        return String.format(java.util.Locale.US, "ind=%.2f tgt=%.2f h=%.2f seen=%d col=(%d,%d,%d,%d) taught=%d",
                BotState.indicatorY, BotState.targetY, BotState.targetH, BotState.lastSeen,
                BotState.collectX, BotState.collectY, BotState.collectD, BotState.collectTime, BotState.taughtN);
    }
}
