package com.slayers2.fishingbot;

/** Tiny test helper (no libraries). */
final class T {
    static int checks = 0, fails = 0;
    static void check(String name, boolean ok) {
        checks++;
        if (!ok) { fails++; System.out.println("  FAIL: " + name); }
    }
    static void near(String name, double got, double want, double tol) {
        check(name + " (got " + got + ", want " + want + " +-" + tol + ")", Math.abs(got - want) <= tol);
    }
    static void section(String s) { System.out.println(s); }

    /** The default settings on a 2400x1080 screen (what ConfigStore.load gives without saved settings). */
    static Config s21() {
        Config k = new Config();
        k.x = (int) (2400 * 0.7375); k.y = (int) (1080 * 0.148); k.w = (int) (2400 * 0.025); k.h = (int) (1080 * 0.556);
        k.cx = (int) (2400 * 0.45); k.cy = (int) (1080 * 0.50);
        k.castX = (int) (2400 * 0.557); k.castY = (int) (1080 * 0.581);
        k.collectOn = true; k.castPress = 600; k.collectHold = 2400; k.cycle = 30; k.pressMs = 70; k.pressMax = 250;
        k.collectMaxD = 76; k.style = 1; k.castWait = 700; k.failWait = 30000; k.startDelay = 3;
        k.hoverPct = 60; k.kp10 = 80; k.kd10 = 8; k.ki10 = 4;
        return k;
    }

    static void resetBotState() {
        BotState.running = false; BotState.status = "Stopped"; BotState.note = ""; BotState.driverFails = 0; BotState.styleInfo = "";
        BotState.collectX = -1; BotState.collectY = -1; BotState.collectD = 0; BotState.collectTime = 0; BotState.pressLagMs = 0;
        BotState.response = 0; BotState.rounds = 0; BotState.casts = 0; BotState.lastSeen = 0; BotState.indicatorY = -1; BotState.targetY = -1;
        BotState.targetH = 0; BotState.taughtN = 0; BotState.gOk = 0; BotState.gCancel = 0; BotState.gFail = 0;
    }

    static final class SimClock implements Clock {
        public long now() { return VClock.now(); }
        public void sleep(long ms) { VClock.sleep(ms); }
    }
}
