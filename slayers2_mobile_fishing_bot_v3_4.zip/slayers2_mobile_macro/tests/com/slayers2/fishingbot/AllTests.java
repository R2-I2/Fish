package com.slayers2.fishingbot;

/** Offline tests of the plain-Java bot logic. No libraries: run tests/run.sh (needs only a JDK). */
public final class AllTests {
    public static void main(String[] a) throws Exception {
        long t0 = System.currentTimeMillis();
        FmtTest.run();
        KnownButtonsTest.run();
        BarDetectorTest.run();
        DiscFinderTest.run();
        FrameProcessorTest.run();
        EngineTest.run();
        System.out.println();
        System.out.println(T.checks + " checks, " + T.fails + " failed, " + (System.currentTimeMillis() - t0) + " ms");
        System.exit(T.fails == 0 ? 0 : 1);
    }
}
