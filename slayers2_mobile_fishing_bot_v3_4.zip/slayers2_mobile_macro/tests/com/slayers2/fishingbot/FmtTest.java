package com.slayers2.fishingbot;

import java.util.Locale;
import java.util.Random;

final class FmtTest {
    static void run() {
        T.section("Fmt");
        Random r = new Random(7);
        int n = 200000, mism2 = 0, mism0 = 0;
        for (int i = 0; i < n; i++) {
            double v = (r.nextDouble() - 0.5) * Math.pow(10, r.nextInt(6) - 1);
            String a = Fmt.fixed2(new StringBuilder(), v).toString(), b = String.format(Locale.US, "%.2f", v);
            if (!a.equals(b)) { mism2++; if (Math.abs(Double.parseDouble(a) - Double.parseDouble(b)) > 0.0101) T.check("fixed2 off by more than a tie: " + a + " vs " + b, false); }
            String c = Fmt.signedInt(new StringBuilder(), v).toString(), d = String.format(Locale.US, "%+.0f", v);
            if (!c.equals(d)) mism0++;
        }
        T.check("fixed2 equals String.format except rare decimal ties (" + mism2 + " of " + n + ")", mism2 < n / 1000);
        T.check("signedInt equals String.format (" + mism0 + " of " + n + " differ)", mism0 == 0);
        T.check("fixed2 -0.001", Fmt.fixed2(new StringBuilder(), -0.001).toString().equals(String.format(Locale.US, "%.2f", -0.001)));
        T.check("fixed2 NaN", Fmt.fixed2(new StringBuilder(), Double.NaN).toString().equals("NaN"));
        T.check("fixed2 huge", Fmt.fixed2(new StringBuilder(), 1e20).toString().equals(String.format(Locale.US, "%.2f", 1e20)));
        T.check("signedInt 0", Fmt.signedInt(new StringBuilder(), 0).toString().equals("+0"));
        T.check("signedInt 2.5 rounds half up", Fmt.signedInt(new StringBuilder(), 2.5).toString().equals("+3"));
        T.check("pad2", Fmt.pad2(new StringBuilder(), 5).toString().equals("05") && Fmt.pad2(new StringBuilder(), 61).toString().equals("61"));
    }
}
