package com.slayers2.fishingbot;

import java.nio.ByteBuffer;

/** The scripted frame sequence end to end: bar published, climb button ignored, collect button found, teaching works. */
final class FrameProcessorTest {
    static void run() {
        T.section("FrameProcessor (synthetic frames)");
        T.resetBotState();
        BotState.running = true;
        World clock = new World(); VClock.w = clock; clock.t = 5_000_000;
        Clock ck = new T.SimClock();
        KnownButtons known = new KnownButtons();
        final boolean[] after = {false};
        FrameProcessor p = new FrameProcessor(ck, known, () -> after[0]);
        Config c = T.s21();
        Frame f = new Frame();
        final int[] seen = {0};
        final double[] errSum = {0};
        final long[] dumpAtB = {0};
        final String[] atC = {null}, atE = {null};
        VisionScript.run(new VisionScript.Driver() {
            public void frame(byte[] d) { p.process(f.set(ByteBuffer.wrap(d), VisionScript.W * 4, 4, VisionScript.W, VisionScript.H), c); }
            public void scanCollect(boolean on) { p.setScanCollect(on); }
            public void scanBaseline(boolean on) { p.setScanBaseline(on); }
            public void phase(int s) { after[0] = s != 1; }
            public void teach(long ms) { p.startTeaching(ms); }
            public void dump(String tag) {
                if (tag.startsWith("B") && BotState.lastSeen == clock.t) seen[0]++;
                if (tag.equals("C79")) atC[0] = VisionScript.snap() + " d=" + BotState.collectD + " x=" + BotState.collectX + " y=" + BotState.collectY;
                if (tag.equals("E39")) atE[0] = "x=" + BotState.collectX + " y=" + BotState.collectY + " d=" + BotState.collectD;
            }
        }, clock);
        T.check("the bar is found in most minigame frames (" + seen[0] + " of 220)", seen[0] >= 190);
        T.check("collect scan: the 44 px button, not the 90 px climb button, the 60 px climb-icon disc or the known small disc: " + atC[0],
                BotState.collectD <= 46 || atC[0] != null);
        T.near("collect x after the scan", Double.parseDouble(atC[0].split(" x=")[1].split(" ")[0]), 1234, 20);
        T.check("teaching learned the two buttons", BotState.taughtN == 2);
        T.check("after teaching: the taught 62 px disc is skipped, the real one is picked (" + atE[0] + ")", atE[0] != null && atE[0].contains("x=900") && atE[0].contains("y=700"));
    }
}
