package com.slayers2.fishingbot;

final class DiscFinderTest {
    static void run() {
        T.section("DiscFinder");
        T.resetBotState();
        DiscFinder df = new DiscFinder();
        KnownButtons known = new KnownButtons();
        byte[] d = VisionScript.background().clone();
        VisionScript.button(d, 1150, 640, 44, 0);
        Frame f = BarDetectorTest.frame(d);
        T.check("finds one disc", df.scan(f) == 1);
        T.near("x", df.x[0], 1150, 4); T.near("y", df.y[0], 640, 4); T.near("diameter", df.d[0], 44, 5);
        T.check("picks it as the collect button", df.pickCollect(f, 76, known, 1000, false, -1, -1, false));
        T.near("pick x", df.pickX, 1150, 4);

        d = VisionScript.background().clone();
        VisionScript.button(d, 1500, 500, 90, 1);
        f = BarDetectorTest.frame(d);
        T.check("the 90 px climb button is a disc", df.scan(f) == 1);
        T.check("...but never the collect button (too big)", !df.pickCollect(f, 76, known, 1000, false, -1, -1, true));

        d = VisionScript.background().clone();
        VisionScript.button(d, 400, 800, 60, 1);
        f = BarDetectorTest.frame(d);
        T.check("a 60 px disc with a tall icon in the label", df.scan(f) == 1);
        T.check("...is the climb button (label icon)", !df.pickCollect(f, 76, known, 1000, false, -1, -1, false));
        d = VisionScript.background().clone();
        VisionScript.button(d, 400, 800, 60, 0);
        f = BarDetectorTest.frame(d);
        T.check("the same disc with a letters-only label is collect", df.scan(f) == 1 && df.pickCollect(f, 76, known, 1000, false, -1, -1, false));

        known.addBaseline(700, 400, 44, 1000);
        d = VisionScript.background().clone();
        VisionScript.button(d, 710, 405, 45, 0);
        f = BarDetectorTest.frame(d);
        T.check("a disc that was on screen before the catch is not collect", df.scan(f) == 1 && !df.pickCollect(f, 76, known, 2000, false, -1, -1, false));

        d = VisionScript.background().clone();
        VisionScript.button(d, 1150, 640, 44, 0);
        VisionScript.button(d, 1700, 300, 70, 0);
        f = BarDetectorTest.frame(d);
        df.scan(f);
        T.check("two candidates: the smallest first", df.pickCollect(f, 76, known, 3000, false, -1, -1, false) && df.pickD <= 46);
        T.check("a recent pick is followed", df.pickCollect(f, 76, known, 3000, true, 1700, 300, false) && df.pickX > 1600);

        d = VisionScript.background().clone();
        VisionScript.button(d, 1150, 100, 44, 0);       // in the menu row at the top
        VisionScript.button(d, 1150, 1000, 44, 0);      // in the hotbar row at the bottom
        T.check("menu and hotbar rows are not searched", df.scan(BarDetectorTest.frame(d)) == 0);
        d = VisionScript.background().clone();
        VisionScript.noise(d, 400);
        T.check("speckle noise is not a disc", df.scan(BarDetectorTest.frame(d)) == 0);
        d = VisionScript.background().clone();
        VisionScript.ellipse(d, 1000, 500, 25, 25, 245, 245, 245);     // a plain white disc: no finger, no label
        T.check("plain white disc without finger/label is not a disc", df.scan(BarDetectorTest.frame(d)) == 0);
    }
}
