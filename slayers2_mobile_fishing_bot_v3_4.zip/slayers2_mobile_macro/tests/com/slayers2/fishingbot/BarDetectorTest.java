package com.slayers2.fishingbot;

import java.nio.ByteBuffer;

final class BarDetectorTest {
    static Frame frame(byte[] d) { return new Frame().set(ByteBuffer.wrap(d), VisionScript.W * 4, 4, VisionScript.W, VisionScript.H); }

    static void run() {
        T.section("BarDetector");
        World w = new World(); VClock.w = w; w.t = 1000;
        Clock ck = new T.SimClock();
        Config c = T.s21();
        BarDetector det = new BarDetector();

        byte[] f = VisionScript.background().clone();
        VisionScript.bar(f, 500, 450, true, true, true, false);
        T.check("finds the bar", det.detect(frame(f), c, ck) == BarDetector.Status.FOUND);
        T.near("square y", det.indY, 500, 2);
        T.near("box y", det.tgtY, 450, 2);
        T.near("box height", det.boxH, 62, 3);

        w.t += 16;
        f = VisionScript.background().clone();
        VisionScript.bar(f, 520, 455, true, true, true, false);
        T.check("follows the bar", det.detect(frame(f), c, ck) == BarDetector.Status.FOUND);
        T.near("square moved", det.indY, 520, 2);

        w.t += 16;
        f = VisionScript.background().clone();
        VisionScript.bar(f, 720, 455, true, true, true, false);
        T.check("a sudden jump is rejected", det.detect(frame(f), c, ck) == BarDetector.Status.REJECTED);
        T.near("reading unchanged after the rejected frame", det.indY, 520, 2);
        int fo = 0;
        for (int i = 0; i < 4; i++) { w.t += 16; if (det.detect(frame(f), c, ck) == BarDetector.Status.FOUND) fo++; }
        T.check("accepted when it stays there (after 3 frames)", fo >= 1);

        w.t += 1000;     // the previous reading is stale: no jump check
        f = VisionScript.background().clone();
        VisionScript.bar(f, 500, 450, true, true, true, false);
        det.detect(frame(f), c, ck);                         // learns the box height
        w.t += 16;
        f = VisionScript.background().clone();
        VisionScript.bar(f, 505, 452, true, true, false, false);
        T.check("one box edge missing: the known height completes it", det.detect(frame(f), c, ck) == BarDetector.Status.FOUND);

        BarDetector d2 = new BarDetector();
        w.t += 5000;
        f = VisionScript.background().clone();
        VisionScript.bar(f, 450, 500, false, true, true, true);
        T.check("box without square: not found", d2.detect(frame(f), c, ck) == BarDetector.Status.NOT_FOUND);
        f = VisionScript.background().clone();
        VisionScript.bar(f, 450, 700, true, false, false, true);
        T.check("tall white glare is not a square", d2.detect(frame(f), c, ck) != BarDetector.Status.FOUND);
        T.check("empty screen: not found", d2.detect(frame(VisionScript.background().clone()), c, ck) == BarDetector.Status.NOT_FOUND);

        Config tiny = T.s21(); tiny.w = 2;
        T.check("tiny region is rejected", new BarDetector().detect(frame(VisionScript.background().clone()), tiny, ck) == BarDetector.Status.REJECTED);
        Config off = T.s21(); off.x = 5000;
        T.check("region off screen is rejected", new BarDetector().detect(frame(VisionScript.background().clone()), off, ck) == BarDetector.Status.REJECTED);
    }
}
