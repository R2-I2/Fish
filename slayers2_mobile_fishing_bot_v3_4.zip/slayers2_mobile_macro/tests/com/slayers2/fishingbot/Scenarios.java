package com.slayers2.fishingbot;

import java.util.*;
import java.util.function.Consumer;

public final class Scenarios {
    public static final class S {
        public final String name; public final Consumer<World> world; public final Consumer<Config> cfg;
        S(String n, Consumer<World> w, Consumer<Config> c) { name = n; world = w; cfg = c; }
    }
    public static List<S> all() {
        List<S> l = new ArrayList<>();
        l.add(new S("normal-presses", w -> w.limit = 90000, c -> c.style = 1));
        l.add(new S("auto-style", w -> w.limit = 150000, c -> c.style = 0));
        l.add(new S("smooth", w -> w.limit = 70000, c -> c.style = 2));
        l.add(new S("no-bite", w -> { w.biteDelay = 10_000_000; w.limit = 60000; }, c -> { c.style = 1; c.failWait = 2000; }));
        l.add(new S("no-collect-button", w -> { w.collectAppears = false; w.limit = 60000; }, c -> c.style = 1));
        l.add(new S("bar-returns-in-collect", w -> { w.secondBarGap = 3000; w.limit = 80000; }, c -> c.style = 1));
        l.add(new S("auto-stop", w -> w.limit = 140000, c -> { c.style = 1; c.autoStopMin = 1; }));
        l.add(new S("collect-off", w -> w.limit = 60000, c -> { c.style = 1; c.collectOn = false; }));
        l.add(new S("unresponsive-auto", w -> { w.responsive = false; w.limit = 60000; }, c -> c.style = 0));
        l.add(new S("unresponsive-presses", w -> { w.responsive = false; w.limit = 40000; }, c -> c.style = 1));
        l.add(new S("invert", w -> w.limit = 50000, c -> { c.style = 1; c.invert = true; }));
        l.add(new S("short-bar-misread", w -> { w.barDur = 1200; w.limit = 40000; }, c -> c.style = 1));
        return l;
    }
}
