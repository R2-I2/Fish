# Slayers 2 Fishing Bot (Android) - v3.4

Fishing helper for the Slayers 2 fishing minigame (keep the white square inside the yellow/green box). It reads your screen
(MediaProjection), finds the bar by colour and presses through an Accessibility service. No injection, no memory reading,
**no internet permission**: nothing leaves the phone. Made for a Galaxy S21 (2400x1080, landscape) but resolution-independent defaults.

> Automating gameplay may break the game's or Roblox's rules and can get an account suspended. Use at your own risk.

## The interface (since v3.3)
Deep-ocean theme: gradient cards with fine borders, aqua accent, drawn line icons (no emoji), press ripples, soft fades.
- **Rail + header:** fish logo, Home / Setup / Tune / Guide with line icons and a highlighted pill; the header shows the page title, the app
  version and a RUNNING / IDLE chip with a pulsing dot while the bot runs.
- **Home:** a big round START / STOP button with a glowing, pulsing ring; the state and status next to it; quick actions (Stop capture,
  Save trace). On the right a live, smoothly animated preview of what the bot sees (box + square, green when inside), six stat tiles
  and a rolling "time inside the box" chart for the last 30 seconds. A readiness strip with icons shows the five setup items.
- **Setup:** a checklist; every row has an icon tile that turns green, a status chip and its buttons on one line.
- **Tune:** four sections behind a segmented selector (Taps, Bar, Timing, Steering); settings sit in two columns; aqua gradient primary buttons.
- **Guide:** collapsible cards. In-app confirmations appear as a small pill at the bottom of the screen.

## 1. Build the APK from your phone (GitHub, free)
1. Make a free account at github.com and create a repository.
2. Upload THIS ZIP as one file (Add file > Upload files) and commit.
3. Add file > Create new file, name it `.github/workflows/build.yml`, paste this and commit:

```
name: Build APK
on: workflow_dispatch
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: for z in *.zip; do unzip -q -o "$z"; done
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'
      - run: cd slayers2_mobile_macro && gradle assembleDebug --no-daemon
      - uses: actions/upload-artifact@v4
        with:
          name: fishing-bot-apk
          path: slayers2_mobile_macro/app/build/outputs/apk/debug/app-debug.apk
```
4. Actions tab (under "More" on mobile) > Build APK > Run workflow. After a few minutes download the `fishing-bot-apk` artifact,
   extract it in My Files and install `app-debug.apk`.
5. **Updating:** every build is signed with a fresh debug key, so uninstall the old app first.

## 2. Install on a Galaxy S21
- Settings > Security and privacy > Auto Blocker: off while installing (it blocks APKs).
- Allow "Install unknown apps" for the app you opened the APK with. Play Protect / AVG may flag the app (Accessibility + screen capture +
  overlay is the combination malware uses). The source is in your repo; it declares no internet permission.
- If the Accessibility switch is greyed out: Settings > Apps > the bot > menu (top right) > Allow restricted settings.

## 3. First-time setup (Setup tab, each card turns green)
1. Accessibility service on. 2. Screen capture: choose **Entire screen**. 3. Floating button (display over other apps).
4. Background use: battery Unrestricted. 5. Notifications (optional).
Optional extra safety: at your fishing spot with the **Wall-Climb button showing** and no catch waiting, Tune > **Teach: climb button**, switch to the game
(the bot already ignores the climb button without it).

## 4. Using it
- Open Slayers 2 at your fishing spot with the rod equipped, tap the round **START** button (drag it anywhere). Tap again, press **Volume Down**,
  or use the notification to stop. Long-press START while a bar is on screen = 2 s test hold.
- **Stop screen capture** (Home/Setup/notification) really ends capture; grant it again next time.
- The bot sends its own touches, so you cannot play manually while it runs.

## 5. What a round looks like
cast (hand button) > wait for the bite > minigame (keep the square in the box: holding lifts, releasing lets gravity drop it; the box is yellow
outside, green inside) > scan the WHOLE screen for the white **Collect** circle (up to 10 s), hold ~2 s, check it vanished > cast again.
Collect search: whole screen (minus the menu row at the top and the hotbar row at the bottom), any size 24-100 px; the Wall-Climb button is ignored
completely (too big, remembered, or recognised by the tall climbing icon in its label) and the bot never presses a spot blindly.
Safety nets: a minigame only counts as finished after 1.5 s without the bar; the collect step stops the moment the bar returns; the
Wall-Climb button is never pressed (remembered/taught by size, tall climbing icon in its label, closed-rim + label tests); 6 casts without a bite
stop the bot; optional auto-stop timer.

## 6. Tune reference
Cast button / Hold point: use **Pick** (6 s to switch to the game, then tap). Bar area: Pick (tap top then bottom inside the bar) or steppers.
Timing: extra wait after cast, recast after, start delay, auto-stop, shortest/longest press, check interval.
Steering: hover (share of time the finger must be down just to stay level, measured ~60%), response, damping, auto-balance, invert.
Press style: Presses (default, consistent), Smooth (experimental, falls back by itself), Auto (learns).

## Code layout (v3.4) and offline tests
v3.4 is a cleanup: the bot is meant to behave exactly like v3.3, but the logic now lives in plain Java classes that do not touch Android:
`Frame` (one captured frame) > `FrameProcessor` (per frame: `BarDetector` finds square + box, `DiscFinder` finds the round buttons, `KnownButtons` remembers
the climb button, thread-safe) and `BotEngine` (cast / wait / minigame / collect state machine) with `Controller` (PD+I steering and press-style learning).
`Clock` and `Pressor` are the two seams: on the phone they are the system clock and `InputService`; in tests a virtual clock and a fake game.
Android-only files: `ProjectionService` (capture, worker thread, floating button, notification), `InputService`, `ConfigStore`, `TraceFile`, the UI classes.
`Fmt` replaces `String.format` in the hot paths; the UI only calls `setText` / `setTextColor` when the value changed.

Run the offline tests on any computer with a JDK (no Android SDK, no libraries): `sh tests/run.sh`. They cover the detectors on synthetic frames, the
climb/collect decisions, thread safety of the taught list, formatting, and the whole bot against a scripted fake game (cast, bite, minigame, collect,
no bite, no collect button, bar returning, auto-stop, smooth hold, unresponsive game). To run them on GitHub instead, add a second workflow file
`.github/workflows/tests.yml`: `on: workflow_dispatch`, steps: checkout, `for z in *.zip; do unzip -q -o "$z"; done`, setup-java 17, `sh slayers2_mobile_macro/tests/run.sh`.

## 7. Troubleshooting
- Home preview says "no bar": Tune > Bar area > Pick.
- "Press response: square does NOT react": move the Hold point (Tune > Pick) to another empty spot; keep it away from buttons (the climb button).
- Lots of "dropped" touches: something else is injecting gestures (another auto-clicker service?). Turn the other one off.
- Collect missed: Tune > collect hold longer; check the trace (K lines show every candidate and why it was rejected).
- It pressed the climb button: redo Teach at your spot and attach the trace.

## 8. Trace file (Home > Save last fishing trace -> Download/slayers_trace.csv)
`t_ms,type,a,b,c,d`  F = square y, box y, box height | P = press ms, duty, error, style | E = press ok, lag ms | S = smooth want, duty, error |
W = style window result | C = collect press x, y, disc diameter (0 = fixed spot), attempt | K = collect candidate x, y, diameter,
status (0 usable, 1 too big, 2 known, 3 climb icon in label) | B = remembered button x, y, diameter, count | T = taught button.

## Changelog (short)
v3.4 code cleanup, same behaviour: testable pure-Java core (BarDetector, DiscFinder, KnownButtons, Controller, BotEngine, FrameProcessor), no String.format in hot paths, thread-safe taught/baseline list, UI and floating button skip unchanged updates, offline tests. v3.3 premium interface (drawn icons, round pulsing start button, live chart, gradients, snackbar). v3.2 first interface rework. v3.1 whole-screen collect search, climb ignored, no blind presses. v3.0 final pass: type-checked all sources against Android API stubs; launcher icon; auto-stop timer; no-bite watchdog; cast counter; post-minigame
learning limited to big discs. v2.9 climb matching by size + label icon. v2.8 teach + ring/label tests. v2.7 baseline memory. v2.6 collect finder.
v2.5 detector fix, 1.5 s end rule, full-res capture. v2.4 measured physics. v2.1 press-and-wait. v2.0 response check. v1.x first versions.
