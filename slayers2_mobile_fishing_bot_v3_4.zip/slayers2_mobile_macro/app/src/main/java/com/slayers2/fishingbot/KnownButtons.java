package com.slayers2.fishingbot;

/**
 * Round buttons that are known NOT to be the collect button (the wall-climb button):
 *  - taught ones (kept in the settings, never expire), and
 *  - baseline ones (seen on screen before the bite / right after the minigame, expire after 10 minutes).
 * Thread-safe: the capture thread adds and queries, the main thread loads / forgets.
 */
final class KnownButtons {
    interface TaughtStore { void save(String serialized); }

    private static final int TAUGHT_MAX = 8, BASE_MAX = 16;
    private static final long BASE_TTL_MS = 600000;

    private final Object lock = new Object();
    private final int[] tx = new int[TAUGHT_MAX], ty = new int[TAUGHT_MAX], td = new int[TAUGHT_MAX];
    private int tn = 0;
    private final int[] bx = new int[BASE_MAX], by = new int[BASE_MAX], bd = new int[BASE_MAX];
    private final long[] bSeen = new long[BASE_MAX];
    private int bn = 0;
    private volatile TaughtStore store;

    void setStore(TaughtStore s) { store = s; }

    int taughtCount() { synchronized (lock) { return tn; } }

    int baselineCount() { synchronized (lock) { return bn; } }

    // ------------------------------------------------------------ taught

    /** Remembers a button as 'never press'. Returns true if it was new. */
    boolean addTaught(int x, int y, int d) {
        String saved;
        int n;
        synchronized (lock) {
            for (int i = 0; i < tn; i++) {
                if (Math.abs(x - tx[i]) <= 40 && Math.abs(y - ty[i]) <= 40) return false;
            }
            if (tn >= TAUGHT_MAX) return false;
            tx[tn] = x; ty[tn] = y; td[tn] = d; tn++;
            n = tn;
            saved = serializeLocked();
            BotState.taughtN = tn;
        }
        TaughtStore s = store;
        if (s != null) s.save(saved);
        Trace.add("T", x, y, d, n);
        return true;
    }

    /** Replaces the taught list with a saved one ("x,y,d;x,y,d;"). */
    void loadTaught(String v) {
        synchronized (lock) {
            tn = 0;
            if (v != null && !v.isEmpty()) {
                for (String part : v.split(";")) {
                    String[] q = part.split(",");
                    if (q.length == 3 && tn < TAUGHT_MAX) {
                        try { tx[tn] = Integer.parseInt(q[0]); ty[tn] = Integer.parseInt(q[1]); td[tn] = Integer.parseInt(q[2]); tn++; }
                        catch (NumberFormatException ignored) {}
                    }
                }
            }
            BotState.taughtN = tn;
        }
    }

    /** Forgets every taught button (does not touch the saved settings; the caller does that). */
    void clearTaught() {
        synchronized (lock) {
            tn = 0;
            BotState.taughtN = 0;
        }
    }

    String serializeTaught() { synchronized (lock) { return serializeLocked(); } }

    private String serializeLocked() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tn; i++) sb.append(tx[i]).append(',').append(ty[i]).append(',').append(td[i]).append(';');
        return sb.toString();
    }

    // ------------------------------------------------------------ baseline

    /** Adds (or refreshes) a button that is known NOT to be the collect button. When full, the oldest entry is replaced. */
    void addBaseline(int x, int y, int d, long now) {
        int n;
        synchronized (lock) {
            for (int i = 0; i < bn; i++) {
                if (Math.abs(x - bx[i]) <= 40 && Math.abs(y - by[i]) <= 40 && Math.abs(d - bd[i]) <= Math.max(16, bd[i] / 3)) {
                    bx[i] = x; by[i] = y; bd[i] = d; bSeen[i] = now;
                    return;
                }
            }
            int slot = bn;
            if (slot >= BASE_MAX) {
                slot = 0;
                for (int i = 1; i < bn; i++) if (bSeen[i] < bSeen[slot]) slot = i;
            } else {
                bn++;
            }
            bx[slot] = x; by[slot] = y; bd[slot] = d; bSeen[slot] = now;
            n = bn;
        }
        Trace.add("B", x, y, d, n);
    }

    /** True if a disc of this size/place was taught, or was on screen before the catch (so it is NOT the collect button). */
    boolean isKnown(int x, int y, int d, long now) {
        synchronized (lock) {
            for (int i = 0; i < tn; i++) if (matches(x, y, d, tx[i], ty[i], td[i])) return true;
            for (int i = 0; i < bn; i++) {
                if (now - bSeen[i] > BASE_TTL_MS) continue;
                if (matches(x, y, d, bx[i], by[i], bd[i])) return true;
            }
            return false;
        }
    }

    /**
     * The climb button does NOT stay in one place, so big ones (>= 70 px) are matched by SIZE ALONE (+-17%);
     * small ones must also be within 100 px.
     */
    static boolean matches(int x, int y, int d, int kx, int ky, int kd) {
        int tol = Math.max(14, (int) (kd * 0.17));
        if (kd >= 70) return Math.abs(d - kd) <= tol;
        return Math.abs(d - kd) <= tol * 3 / 2 && Math.hypot(x - kx, y - ky) <= 100;
    }
}
