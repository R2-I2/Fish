package com.slayers2.fishingbot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Crisp line icons drawn with Canvas (no image files, no emoji): consistent weight and colour everywhere. */
public class IconView extends View {
    public static final int HOME = 0, STEPS = 1, TUNE = 2, BOOK = 3, PLAY = 4, STOP = 5, CAPTURE = 6, SAVE = 7, PIN = 8,
            CHECK = 9, CROSS = 10, ACCESS = 11, OVERLAY = 12, BATTERY = 13, BELL = 14, FISH = 15;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private int icon, color;

    public IconView(Context c, int icon, int color) {
        super(c);
        this.icon = icon;
        this.color = color;
    }

    public void setIcon(int icon) {
        if (this.icon != icon) { this.icon = icon; invalidate(); }
    }

    public void setColor(int color) {
        if (this.color != color) { this.color = color; invalidate(); }
    }

    private void line(float x1, float y1, float x2, float y2) {
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
    }

    @Override protected void onDraw(Canvas cv) {
        float size = Math.min(getWidth(), getHeight());
        if (size <= 0) return;
        cv.save();
        cv.translate((getWidth() - size) / 2f, (getHeight() - size) / 2f);
        cv.scale(size / 24f, size / 24f);                     // draw on a 24 x 24 grid
        p.setColor(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        path.reset();
        boolean fill = false;
        switch (icon) {
            case HOME:
                path.moveTo(3, 11); path.lineTo(12, 3); path.lineTo(21, 11);
                path.moveTo(5.5f, 9.5f); path.lineTo(5.5f, 20); path.lineTo(18.5f, 20); path.lineTo(18.5f, 9.5f);
                path.moveTo(10, 20); path.lineTo(10, 14.5f); path.lineTo(14, 14.5f); path.lineTo(14, 20);
                break;
            case STEPS:
                for (int i = 0; i < 3; i++) {
                    float y = 6 + i * 6;
                    path.addRoundRect(3, y - 2.4f, 7.8f, y + 2.4f, 1.2f, 1.2f, Path.Direction.CW);
                    line(11, y, 21, y);
                }
                path.moveTo(4.3f, 6.1f); path.lineTo(5.3f, 7.1f); path.lineTo(6.7f, 5.1f);
                break;
            case TUNE:
                line(3, 6, 21, 6); line(3, 12, 21, 12); line(3, 18, 21, 18);
                path.addCircle(8, 6, 2.4f, Path.Direction.CW);
                path.addCircle(16, 12, 2.4f, Path.Direction.CW);
                path.addCircle(10, 18, 2.4f, Path.Direction.CW);
                break;
            case BOOK:
                path.moveTo(12, 6.5f);
                path.cubicTo(9.5f, 4.5f, 5.5f, 4.3f, 3, 5.3f);
                path.lineTo(3, 19);
                path.cubicTo(5.5f, 18, 9.5f, 18.3f, 12, 20.3f);
                path.cubicTo(14.5f, 18.3f, 18.5f, 18, 21, 19);
                path.lineTo(21, 5.3f);
                path.cubicTo(18.5f, 4.3f, 14.5f, 4.5f, 12, 6.5f);
                line(12, 6.5f, 12, 20.3f);
                break;
            case PLAY:
                fill = true;
                path.moveTo(8, 5); path.lineTo(19.5f, 12); path.lineTo(8, 19); path.close();
                break;
            case STOP:
                fill = true;
                path.addRoundRect(6, 6, 18, 18, 2.5f, 2.5f, Path.Direction.CW);
                break;
            case CAPTURE:
                path.addRoundRect(3, 4.5f, 21, 16.5f, 2.5f, 2.5f, Path.Direction.CW);
                line(8, 20.5f, 16, 20.5f); line(12, 16.5f, 12, 20.5f);
                break;
            case SAVE:
                line(12, 4, 12, 15); line(7, 10.5f, 12, 15.5f); line(17, 10.5f, 12, 15.5f); line(5, 20, 19, 20);
                break;
            case PIN:
                path.moveTo(12, 21);
                path.lineTo(6.5f, 13.5f);
                path.cubicTo(4, 10, 5, 5.5f, 9, 4);
                path.cubicTo(11, 3.2f, 13, 3.2f, 15, 4);
                path.cubicTo(19, 5.5f, 20, 10, 17.5f, 13.5f);
                path.close();
                path.addCircle(12, 9.5f, 2.5f, Path.Direction.CW);
                break;
            case CHECK:
                path.moveTo(5, 12.5f); path.lineTo(10, 17.5f); path.lineTo(19, 7);
                break;
            case CROSS:
                line(6, 6, 18, 18); line(18, 6, 6, 18);
                break;
            case ACCESS:
                path.addCircle(12, 5, 2, Path.Direction.CW);
                line(5, 9, 19, 9); line(12, 9, 12, 15); line(12, 15, 8.5f, 21); line(12, 15, 15.5f, 21);
                break;
            case OVERLAY:
                path.addRoundRect(3, 6, 15, 18, 2.5f, 2.5f, Path.Direction.CW);
                path.moveTo(9, 3.5f); path.lineTo(20.5f, 3.5f); path.lineTo(20.5f, 14.5f);
                break;
            case BATTERY:
                path.addRoundRect(2.5f, 7.5f, 19, 16.5f, 2.2f, 2.2f, Path.Direction.CW);
                line(21.5f, 10.5f, 21.5f, 13.5f);
                path.moveTo(11.5f, 9.5f); path.lineTo(8.5f, 12.3f); path.lineTo(13, 12.3f); path.lineTo(10, 15);
                break;
            case BELL:
                path.moveTo(5, 18); path.lineTo(7, 16); path.lineTo(7, 11);
                path.cubicTo(7, 8, 9, 6, 12, 6);
                path.cubicTo(15, 6, 17, 8, 17, 11);
                path.lineTo(17, 16); path.lineTo(19, 18); path.close();
                path.moveTo(10, 20.5f); path.cubicTo(10.6f, 21.7f, 13.4f, 21.7f, 14, 20.5f);
                break;
            case FISH:
                path.moveTo(2.5f, 12);
                path.cubicTo(6, 5.5f, 14, 5.5f, 18, 12);
                path.cubicTo(14, 18.5f, 6, 18.5f, 2.5f, 12);
                path.close();
                path.moveTo(18, 12); path.lineTo(22, 8); path.lineTo(22, 16); path.close();
                break;
            default:
                break;
        }
        if (fill) p.setStyle(Paint.Style.FILL);
        cv.drawPath(path, p);
        if (icon == FISH) {
            p.setStyle(Paint.Style.FILL);
            cv.drawCircle(7.4f, 11, 1.1f, p);
        }
        cv.restore();
    }
}
