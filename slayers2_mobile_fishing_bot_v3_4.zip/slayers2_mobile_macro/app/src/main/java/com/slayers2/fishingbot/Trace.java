package com.slayers2.fishingbot;

/**
 * Keeps a compact log of the last fishing run (square/box positions ~60 times a second, every press the bot sent) so it
 * can be saved as Download/slayers_trace.csv (see TraceFile). Stays on the phone unless you attach it somewhere yourself.
 */
final class Trace {
    private static final String HEADER = "t_ms,type,a,b,c,d\n";
    private static final StringBuilder sb = new StringBuilder(HEADER);
    private static long t0 = 0;

    private Trace() {}

    static synchronized void reset() {
        sb.setLength(0);
        sb.append(HEADER);
        t0 = 0;
    }

    /** F: a=square y, b=box y, c=box height | P: a=press ms, b=duty, c=error, d=style | E: a=ok, b=lag ms
     *  S: a=want down, b=duty, c=error | W: a=style, b=in-box share, c=style score
     *  K: a,b=disc x,y c=diameter d=verdict | B: baseline button | T: taught button | C: collect press */
    static synchronized void add(String type, double a, double b, double c, double d) {
        long now = System.currentTimeMillis();
        if (t0 == 0) t0 = now;
        if (sb.length() > 400000) sb.delete(HEADER.length(), HEADER.length() + 150000);
        sb.append(now - t0).append(',').append(type).append(',');
        Fmt.fixed2(sb, a).append(',');
        Fmt.fixed2(sb, b).append(',');
        Fmt.fixed2(sb, c).append(',');
        Fmt.fixed2(sb, d).append('\n');
    }

    /** The whole log as CSV text. */
    static synchronized String snapshot() { return sb.toString(); }
}
