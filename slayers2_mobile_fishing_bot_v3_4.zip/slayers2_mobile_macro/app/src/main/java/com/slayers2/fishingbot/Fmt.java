package com.slayers2.fishingbot;

import java.util.Locale;

/**
 * Allocation-free number formatting for the hot paths (String.format parses its pattern and creates garbage on every call).
 * The output matches String.format(Locale.US, ...); only exact decimal ties of %.2f can differ by 0.01.
 */
final class Fmt {
    private Fmt() {}

    private static boolean odd(double v) { return Double.isNaN(v) || Double.isInfinite(v) || Math.abs(v) >= 1e15; }
    private static boolean negative(double v) { return v < 0 || (v == 0 && 1.0 / v < 0); }

    /** Like "%.2f". */
    static StringBuilder fixed2(StringBuilder sb, double v) {
        if (odd(v)) return sb.append(String.format(Locale.US, "%.2f", v));
        long scaled = Math.round(Math.abs(v) * 100.0);
        if (negative(v)) sb.append('-');
        sb.append(scaled / 100).append('.');
        long frac = scaled % 100;
        if (frac < 10) sb.append('0');
        return sb.append(frac);
    }

    /** Like "%+.0f". */
    static StringBuilder signedInt(StringBuilder sb, double v) {
        if (odd(v)) return sb.append(String.format(Locale.US, "%+.0f", v));
        sb.append(negative(v) ? '-' : '+');
        return sb.append(Math.round(Math.abs(v)));
    }

    /** Like "%02d" for a non-negative value. */
    static StringBuilder pad2(StringBuilder sb, long v) {
        if (v >= 0 && v < 10) sb.append('0');
        return sb.append(v);
    }
}
