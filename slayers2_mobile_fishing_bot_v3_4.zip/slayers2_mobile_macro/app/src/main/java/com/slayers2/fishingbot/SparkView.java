package com.slayers2.fishingbot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Rolling "share of time the square was inside the box" chart (about the last 30 seconds). */
public class SparkView extends View {
    private static final int N = 120;
    private final float[] v = new float[N];
    private int count = 0;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path line = new Path(), area = new Path();

    public SparkView(Context c) {
        super(c);
        for (int i = 0; i < N; i++) v[i] = -1;
    }

    /** value 0..1 (share inside the box over the last second), or -1 when the bar was not on screen. */
    public void push(float value) {
        System.arraycopy(v, 1, v, 0, N - 1);
        v[N - 1] = value;
        if (count < N) count++;
        invalidate();
    }

    @Override protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float d = getResources().getDisplayMetrics().density;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF0E1531);
        cv.drawRect(0, 0, w, h, p);
        // guide lines at 25 / 50 / 75 %
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1f * d);
        p.setColor(0xFF1B2552);
        for (int i = 1; i < 4; i++) cv.drawLine(0, h * i / 4f, w, h * i / 4f, p);

        float pad = 3 * d, top = pad, bot = h - pad;
        float step = w / (N - 1f);
        // smooth over 5 samples; draw each continuous stretch as its own filled area
        int i = 0;
        while (i < N) {
            if (v[i] < 0) { i++; continue; }
            int j = i;
            while (j < N && v[j] >= 0) j++;
            line.reset();
            area.reset();
            for (int k = i; k < j; k++) {
                float s = 0; int c = 0;
                for (int q = Math.max(i, k - 2); q <= Math.min(j - 1, k + 2); q++) { s += v[q]; c++; }
                float val = s / c;
                float x = k * step, y = bot - (bot - top) * val;
                if (k == i) { line.moveTo(x, y); area.moveTo(x, bot); area.lineTo(x, y); }
                else { line.lineTo(x, y); area.lineTo(x, y); }
            }
            area.lineTo((j - 1) * step, bot);
            area.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x335EEAD4);
            cv.drawPath(area, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2f * d);
            p.setColor(0xFF5EEAD4);
            cv.drawPath(line, p);
            i = j;
        }
        if (count == 0) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF93A0CF);
            p.setTextSize(10 * d);
            p.setTextAlign(Paint.Align.CENTER);
            cv.drawText("fills while the minigame runs", w / 2, h / 2 + 3 * d, p);
        }
    }
}
