package com.slayers2.fishingbot;

import java.nio.ByteBuffer;

/** One captured RGBA frame: the raw buffer plus its strides. Reused for every frame (no allocation per frame). */
final class Frame {
    ByteBuffer buf;
    int rs, ps;      // row stride and pixel stride in bytes
    int w, h;        // size in pixels

    Frame set(ByteBuffer buf, int rowStride, int pixelStride, int w, int h) {
        this.buf = buf; this.rs = rowStride; this.ps = pixelStride; this.w = w; this.h = h;
        return this;
    }
}
