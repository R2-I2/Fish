package com.slayers2.fishingbot;

import java.util.function.DoubleSupplier;

/**
 * PD(+I) controller. The result is a "duty": the share of time the finger should be down.
 * Smooth mode turns it into press/release decisions every tick (sigma-delta) and lets the Pressor keep one touch
 * down between presses. If the phone rejects that, it falls back to one plain press per cycle.
 * Also learns which press style (presses / smooth hold) keeps the square in the box longest.
 */
final class Controller {
    /** Where the learned style scores are kept between runs. */
    interface ArmStore {
        void load(double[] score, int[] tries);
        void save(double[] score, int[] tries);
    }

    private final Clock clock;
    private final ArmStore store;
    private final DoubleSupplier rng;
    private final StringBuilder sb = new StringBuilder(64);

    // PD+I state
    private double lastInd = -1, lastTgt = -1, vel = 0, integ = 0, acc = 0, liftInd = 0;
    private long lastIndTime = 0, liftStart = 0, lastCtrlMs = 0;
    private int noResp = 0;

    // press styles: 0 = presses (length grows with how hard we need to push), 1 = smooth hold (one touch kept down)
    private int arm = 0;
    private boolean armInit = false;
    private double winIn = 0, winTot = 0;
    private final double[] armScore = {-1, -1, -1};
    private final int[] armTries = {0, 0, 0};

    Controller(Clock clock, ArmStore store, DoubleSupplier rng) {
        this.clock = clock;
        this.store = store;
        this.rng = rng;
    }

    /** Start of a run. */
    void reset() {
        lastInd = -1; vel = 0; integ = 0; acc = 0;
        BotState.driverFails = 0;
        BotState.response = 0; noResp = 0; liftStart = 0; lastCtrlMs = 0;
        loadArms();
        armInit = false;
    }

    /** The bar is not on screen right now. */
    void idle() {
        lastInd = -1; vel = 0; integ = 0; acc = 0; lastCtrlMs = 0;
    }

    void loadArms() { if (store != null) store.load(armScore, armTries); }

    /** One control step: reads the bar from BotState, then sends one press or sleeps one cycle. */
    void control(Pressor in, Config c) {
        double ind = BotState.indicatorY, tgt = BotState.targetY;
        long ft = BotState.lastSeen;
        if (lastInd >= 0 && ft > lastIndTime) {
            double dt = (ft - lastIndTime) / 1000.0;
            if (dt > 0.005 && dt < 0.8) vel = 0.6 * vel + 0.4 * (((ind - tgt) - (lastInd - lastTgt)) / dt);   // rate of change of the ERROR
            vel = Math.max(-1500, Math.min(1500, vel));
        }
        if (ft != lastIndTime) { lastInd = ind; lastTgt = tgt; lastIndTime = ft; }
        final int tick = Math.max(20, c.cycle);
        final long nowC = clock.now();
        final double dtc = lastCtrlMs == 0 ? tick / 1000.0 : Math.min(0.4, (nowC - lastCtrlMs) / 1000.0);
        lastCtrlMs = nowC;

        double bar = Math.max(100, c.h);
        double e = (ind - tgt) / bar;        // > 0 : square is below the target, needs to rise
        double v = vel / bar;                // > 0 : error is growing (square falling away / target rising)
        integ = Math.max(-0.6, Math.min(0.6, integ + e * dtc));
        double duty = c.hoverPct / 100.0 + (c.kp10 / 10.0) * e + (c.kd10 / 10.0) * v + (c.ki10 / 10.0) * integ;
        if (c.invert) duty = 1.0 - duty;     // for a game where holding moves the square DOWN
        duty = Math.max(0, Math.min(1, duty));

        // ---- which press style is active? (Auto learns from how long the square stays inside the box)
        trackStyle(in, c, dtc, Math.abs(ind - tgt) < BotState.targetH / 2);

        // ---- response check: does the game actually move the square when we press?
        final long nowMs = clock.now();
        final boolean room = c.invert ? ind < c.y + c.h - 60 : ind > c.y + 60;
        if (duty > 0.8 && room) {
            if (liftStart == 0) { liftStart = nowMs; liftInd = ind; }
            double moved = c.invert ? ind - liftInd : liftInd - ind;
            if (moved >= 6) {
                BotState.response = 1; noResp = 0; liftStart = nowMs; liftInd = ind;
            } else if (nowMs - liftStart > 700) {
                noResp++;
                liftStart = 0;
                if (noResp >= 2) onNoResponse();
            }
        } else {
            liftStart = 0;
        }

        final boolean smooth = arm == 1 && BotState.driverFails < 6;
        final String armName = arm == 1 ? "smooth" : "presses";
        final int pct = (int) (duty * 100);
        sb.setLength(0);
        sb.append("Tracking  err ");
        Fmt.signedInt(sb, ind - tgt).append(" px  hold ").append(pct).append('%');
        if (BotState.response < 0) sb.append("   [game not reacting]");
        BotState.status = sb.toString();
        if (BotState.response < 0) {
            BotState.note = "NO RESPONSE";
        } else {
            sb.setLength(0);
            sb.append(armName).append("  ").append(pct).append('%');
            if (smooth) sb.append("  g ").append(BotState.gOk).append('/').append(BotState.gCancel);
            else sb.append("  lag ").append(BotState.pressLagMs).append("ms");
            BotState.note = sb.toString();
        }

        if (smooth) {
            acc += duty;
            boolean wantDown = false;
            if (acc >= 1.0) { wantDown = true; acc -= 1.0; }
            Trace.add("S", wantDown ? 1 : 0, duty, e, 2);
            in.setHold(c.cx, c.cy, wantDown);
            clock.sleep(Math.max(40, tick));
            return;
        }

        // ---- safe presses: send one press, wait until the phone has finished it, then decide again.
        // (Sending the next press early cancelled the previous one - most presses were being lost.)
        acc = Math.min(acc + duty, 2.0);
        if (acc >= 1.0) {
            acc -= 1.0;
            // Long presses when we must push hard (the game's gravity needs the finger down ~2/3 of the time, and every
            // press has some dead time), short ones when only a small correction is needed.
            int len = (int) Math.round(c.pressMs + (c.pressMax - c.pressMs) * duty);
            Trace.add("P", len, duty, e, arm);
            boolean ok = in.pressAndWait(c.cx, c.cy, len);
            Trace.add("E", ok ? 1 : 0, BotState.pressLagMs, 0, 0);
        } else {
            clock.sleep(tick);
        }
    }

    // ---------------------------------------------------------------- style learning

    /** Time-weighted share of the window the square spent inside the box; picks the style for the next window. */
    private void trackStyle(Pressor in, Config c, double dtc, boolean inside) {
        if (!armInit) {
            armInit = true;
            arm = chooseArm(c);
            winIn = 0; winTot = 0;
            updateStyleInfo(c);
        }
        if (c.style != 0) {                  // a style was picked by hand: no learning
            if (arm != c.style - 1) { if (arm == 1) in.release(); arm = c.style - 1; updateStyleInfo(c); }
            return;
        }
        winTot += dtc;
        if (inside) winIn += dtc;
        if (winTot >= 6.0) {
            double frac = winIn / winTot;
            armScore[arm] = armTries[arm] == 0 ? frac : 0.6 * armScore[arm] + 0.4 * frac;
            armTries[arm]++;
            if (store != null) store.save(armScore, armTries);
            Trace.add("W", arm, frac, armScore[arm], 0);
            int next = chooseArm(c);
            if (arm == 1 && next != 1) in.release();
            arm = next;
            winIn = 0; winTot = 0;
            updateStyleInfo(c);
        }
    }

    private int chooseArm(Config c) {
        if (c.style != 0) return c.style - 1;
        final int n = BotState.driverFails < 6 ? 2 : 1;
        int least = 0;
        for (int i = 1; i < n; i++) if (armTries[i] < armTries[least]) least = i;
        if (armTries[least] < 2) return least;                    // try every style twice first
        int best = 0;
        for (int i = 1; i < n; i++) if (armScore[i] > armScore[best]) best = i;
        if (rng.getAsDouble() < 0.2) return (best + 1 + (int) (rng.getAsDouble() * (n - 1))) % n;   // now and then re-check another style
        return best;
    }

    private void updateStyleInfo(Config c) {
        final String[] nm = {"presses", "smooth"};
        StringBuilder s = new StringBuilder(c.style == 0 ? "auto" : "fixed");
        s.append(": ").append(nm[Math.max(0, Math.min(1, arm))]).append("   |   ");
        for (int i = 0; i < 2; i++) {
            s.append(nm[i]).append(' ');
            if (armTries[i] == 0) s.append('-');
            else s.append((int) Math.round(armScore[i] * 100)).append('%');
            if (i < 1) s.append("   ");
        }
        BotState.styleInfo = s.toString();
    }

    /** The square did not rise although we pressed hard for a while. */
    private void onNoResponse() {
        noResp = 0;
        if (arm == 1 && BotState.driverFails < 6) {
            BotState.driverFails += 100;     // smooth hold is not working on this phone -> plain presses
        } else {
            BotState.response = -1;          // plain presses do not work either: the Hold point is being ignored
        }
    }
}
