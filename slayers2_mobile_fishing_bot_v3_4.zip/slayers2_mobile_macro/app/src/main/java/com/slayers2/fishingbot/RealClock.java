package com.slayers2.fishingbot;

/** The system clock. An interrupt only ends the current sleep early (the worker checks its alive flag afterwards). */
final class RealClock implements Clock {
    @Override public long now() { return System.currentTimeMillis(); }

    @Override public void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}
