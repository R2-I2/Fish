package com.slayers2.fishingbot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Live mini-preview of what the bot sees: the box (yellow outside, green when the square is inside) and the white square, eased smoothly. */
public class BarView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private int regionY = 0, regionH = 1;
    private float dInd = -1, dTgt = -1, dBox = 0;      // displayed (eased) values, in region fractions

    public BarView(Context c) { super(c); }

    public void setRegion(int y, int h) {
        regionY = y;
        regionH = Math.max(1, h);
    }

    private float frac(double y) {
        return (float) Math.max(0, Math.min(1, (y - regionY) / (double) regionH));
    }

    @Override protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float d = getResources().getDisplayMetrics().density;
        float top = 4 * d, bottom = h - 4 * d, track = bottom - top;

        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF0A1028);
        r.set(w * 0.18f, top, w * 0.82f, bottom);
        cv.drawRoundRect(r, 14 * d, 14 * d, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.5f * d);
        p.setColor(0xFF2B3768);
        cv.drawRoundRect(r, 14 * d, 14 * d, p);
        p.setStrokeWidth(1f * d);
        p.setColor(0xFF1B2552);
        for (int i = 1; i < 10; i++) {
            float ty = top + track * i / 10f;
            cv.drawLine(w * 0.30f, ty, w * 0.70f, ty, p);
        }

        boolean seen = System.currentTimeMillis() - BotState.lastSeen < 500;
        if (!seen) {
            dInd = -1;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF93A0CF);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(11 * d);
            cv.drawText("no bar", w / 2, h / 2, p);
            return;
        }
        float tInd = frac(BotState.indicatorY), tTgt = frac(BotState.targetY), tBox = (float) (BotState.targetH / regionH);
        if (dInd < 0) { dInd = tInd; dTgt = tTgt; dBox = tBox; }
        dInd += (tInd - dInd) * 0.4f;
        dTgt += (tTgt - dTgt) * 0.4f;
        dBox += (tBox - dBox) * 0.4f;

        float boxH = dBox * track, cy = top + dTgt * track, iy = top + dInd * track;
        boolean inside = Math.abs(BotState.indicatorY - BotState.targetY) < BotState.targetH / 2;
        int col = inside ? 0xFF34D399 : 0xFFFACC15;       // green when the square is inside, like the game

        p.setStyle(Paint.Style.FILL);
        p.setColor((col & 0x00FFFFFF) | 0x33000000);
        r.set(w * 0.10f, cy - boxH / 2, w * 0.90f, cy + boxH / 2);
        cv.drawRoundRect(r, 6 * d, 6 * d, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.5f * d);
        p.setColor(col);
        cv.drawRoundRect(r, 6 * d, 6 * d, p);

        float sq = Math.max(9 * d, 40f / regionH * track);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x33FFFFFF);
        r.set(w * 0.25f, iy - sq / 2 - 3 * d, w * 0.75f, iy + sq / 2 + 3 * d);
        cv.drawRoundRect(r, 8 * d, 8 * d, p);
        p.setColor(0xFFF1F5F9);
        r.set(w * 0.30f, iy - sq / 2, w * 0.70f, iy + sq / 2);
        cv.drawRoundRect(r, 6 * d, 6 * d, p);

        if (Math.abs(tInd - dInd) > 0.002f || Math.abs(tTgt - dTgt) > 0.002f) postInvalidateOnAnimation();
    }
}
