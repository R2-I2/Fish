package com.slayers2.fishingbot;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.view.Display;

/** Loads and saves Config in the "bot" preferences. */
public final class ConfigStore {
    private ConfigStore() {}

    public static Point realSize(Context c) {
        Point p = new Point();
        DisplayManager dm = (DisplayManager) c.getSystemService(Context.DISPLAY_SERVICE);
        Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
        d.getRealSize(p);
        return p;
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("bot", Context.MODE_PRIVATE);
    }

    public static Config load(Context c) {
        Point s = realSize(c);
        SharedPreferences p = prefs(c);
        Config k = new Config();
        k.x = p.getInt("x", (int) (s.x * 0.7375));
        k.y = p.getInt("y", (int) (s.y * 0.148));
        k.w = p.getInt("w", (int) (s.x * 0.025));
        k.h = p.getInt("h", (int) (s.y * 0.556));
        k.cx = p.getInt("cx", (int) (s.x * 0.45));
        k.cy = p.getInt("cy", (int) (s.y * 0.50));
        // hand-icon cast button near the rod tip and the white "Collect" circle, as seen on a 2400x1080 screen
        k.castX = p.getInt("castX", (int) (s.x * 0.557));
        k.castY = p.getInt("castY", (int) (s.y * 0.581));
        k.colX = p.getInt("colX", (int) (s.x * 0.650));
        k.colY = p.getInt("colY", (int) (s.y * 0.585));
        k.collectOn = p.getBoolean("collectOn", true);
        k.castPress = p.getInt("castPress", 600);
        k.collectHold = p.getInt("colHold", 2400);
        k.cycle = p.getInt("cycle", 30);
        k.pressMs = p.getInt("pressMs", 70);
        k.pressMax = p.getInt("pressMax", 250);
        k.autoStopMin = p.getInt("autoStop", 0);   // 0 = never
        k.collectMaxD = p.getInt("colMaxD", 76);   // the wall-climb button is ~90 px, a collect button 30-68 px
        k.smooth = p.getBoolean("smooth", false);
        k.style = p.getInt("style", 1);   // 1 = presses (consistent); 0 = auto-learn
        k.castWait = p.getInt("cast", 700);
        k.failWait = p.getInt("fail", 30000);
        k.startDelay = p.getInt("delay", 3);
        k.hoverPct = p.getInt("hover", 60);
        k.kp10 = p.getInt("kp", 80);
        k.kd10 = p.getInt("kd", 8);
        k.ki10 = p.getInt("ki", 4);
        k.invert = p.getBoolean("invert", false);
        return k;
    }

    public static void reset(Context c) {
        SharedPreferences p = prefs(c);
        int ox = p.getInt("ox", -1), oy = p.getInt("oy", -1);
        SharedPreferences.Editor e = p.edit().clear();
        if (ox >= 0) e.putInt("ox", ox);
        if (oy >= 0) e.putInt("oy", oy);
        e.apply();
    }

    public static void save(Context c, Config k) {
        prefs(c).edit()
            .putInt("x", k.x).putInt("y", k.y).putInt("w", k.w).putInt("h", k.h)
            .putInt("cx", k.cx).putInt("cy", k.cy).putInt("castX", k.castX).putInt("castY", k.castY).putInt("colX", k.colX).putInt("colY", k.colY)
            .putBoolean("collectOn", k.collectOn)
            .putInt("castPress", k.castPress).putInt("colHold", k.collectHold).putInt("cycle", k.cycle).putInt("pressMs", k.pressMs).putInt("pressMax", k.pressMax).putInt("colMaxD", k.collectMaxD).putInt("autoStop", k.autoStopMin).putBoolean("smooth", k.smooth).putInt("style", k.style)
            .putInt("cast", k.castWait).putInt("fail", k.failWait).putInt("delay", k.startDelay)
            .putInt("hover", k.hoverPct).putInt("kp", k.kp10).putInt("kd", k.kd10).putInt("ki", k.ki10)
            .putBoolean("invert", k.invert).apply();
    }
}
