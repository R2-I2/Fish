package com.slayers2.fishingbot;

import java.util.function.BooleanSupplier;

/**
 * Everything that happens to one captured frame: find the bar (BarDetector), publish it in BotState, and - depending on what
 * the bot is doing - look for round buttons (DiscFinder): learn the climb button, find the collect button, or remember
 * what is on screen before the bite (baseline).
 */
final class FrameProcessor implements BotEngine.Vision {
    private final Clock clock;
    private final KnownButtons known;
    private final BooleanSupplier afterMinigame;     // true once the minigame has started (PLAYING / FINISHING)
    private final BarDetector bar = new BarDetector();
    private final DiscFinder discs = new DiscFinder();

    private volatile boolean scanCollect = false;    // true while the worker waits for the collect button
    private volatile boolean scanBaseline = false;
    private volatile long teachUntil = 0;
    private long lastTeachScan = 0, lastBaseScan = 0, lastCandLog = 0;

    FrameProcessor(Clock clock, KnownButtons known, BooleanSupplier afterMinigame) {
        this.clock = clock;
        this.known = known;
        this.afterMinigame = afterMinigame;
    }

    @Override public void setScanCollect(boolean on) { scanCollect = on; }
    @Override public void setScanBaseline(boolean on) { scanBaseline = on; }

    /** For the next ms milliseconds every button with a finger on screen is learned as 'not the collect button'. */
    void startTeaching(long ms) { teachUntil = clock.now() + ms; }

    void process(Frame f, Config c) {
        BarDetector.Status s = bar.detect(f, c, clock);
        if (s == BarDetector.Status.REJECTED) return;
        final long now = bar.frameTime;
        if (s == BarDetector.Status.FOUND) {
            BotState.indicatorY = bar.indY;
            BotState.targetY = bar.tgtY;
            BotState.targetH = bar.boxH;
            BotState.lastSeen = bar.seenAt;
            if (BotState.running) Trace.add("F", BotState.indicatorY, BotState.targetY, BotState.targetH, 0);
        }
        discWork(f, c, now);
    }

    /** Called for every captured frame: teach scan, collect scan after a catch, or baseline scan (what is on screen before / just after the minigame). */
    private void discWork(Frame f, Config c, long now) {
        if (now < teachUntil) {                       // the user is teaching: everything with a finger on screen is NOT the collect button
            if (now - lastTeachScan > 250) {
                lastTeachScan = now;
                discs.scan(f);
                for (int i = 0; i < discs.n; i++) known.addTaught(discs.x[i], discs.y[i], discs.d[i]);
            }
        } else if (scanCollect) {
            findCollectButton(f, c, now);
        } else if (scanBaseline && now - lastBaseScan > 300) {
            lastBaseScan = now;
            discs.scan(f);
            final boolean after = afterMinigame.getAsBoolean();
            for (int i = 0; i < discs.n; i++) {
                if (after && discs.d[i] < 70) continue;     // right after the minigame a small disc could already be the collect button
                known.addBaseline(discs.x[i], discs.y[i], discs.d[i], now);
            }
        }
    }

    /** The collect button: a disc with a finger that was NOT on screen before the catch and is smaller than the climb button. */
    private void findCollectButton(Frame f, Config c, long now) {
        discs.scan(f);
        final boolean haveLast = now - BotState.collectTime < 1500 && BotState.collectX >= 0;
        final boolean log = now - lastCandLog > 400;
        if (log) lastCandLog = now;
        if (discs.pickCollect(f, c.collectMaxD, known, now, haveLast, BotState.collectX, BotState.collectY, log)) {
            BotState.collectX = discs.pickX;
            BotState.collectY = discs.pickY;
            BotState.collectD = discs.pickD;
            BotState.collectTime = now;
        }
    }
}
