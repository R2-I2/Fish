package com.slayers2.fishingbot;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;

/** Static in-app guide. Written from community guides (Sept 2026); details can change with game updates. */
final class Guide {
    private Guide() {}

    static View build(Context c) {
        LinearLayout p = Ui.vbox(c);
        p.setPadding(Ui.dp(c, 12), Ui.dp(c, 4), Ui.dp(c, 12), Ui.dp(c, 12));
        p.addView(Ui.text(c, "Tap a card to open it. From community guides, Sept 2026; patches may change details.", 11, Ui.MUTED, false),
                Ui.lp(c, Ui.WRAP, Ui.WRAP, 2, 0, 0, 8));

        Ui.collapsible(c, p, "How a catch works", new String[]{
            "Get a Fishing Permit from the Dock Master at Mistfall Harbor (a short quest, fee about 5,000 Wen), then buy the Basic Fishing Rod (about 3,500 Wen).",
            "Put the rod in your hotbar and equip it. If you hold a katana, you swing it instead of casting.",
            "Stand at the pier edge or on crates by the water and press the hand-icon button near the rod to cast.",
            "Wait a while for a bite. The minigame starts on its own.",
            "Keep the white square inside the box with short presses: holding lifts the square, releasing lets it drop. The box is yellow while the square is outside it and turns green while the square is inside. Fill the meter to 100%.",
            "To collect, hold the white finger circle next to the catch name for 1 to 2 seconds (PC: press T). That button follows the fish in the water, so it is not always in the same place, and it can lag for a few seconds."
        }, true);

        Ui.collapsible(c, p, "What the bot does", new String[]{
            "Presses the Cast button (the hand icon), then waits for a bite.",
            "Reads the bar (yellow OR green box, white square) about 20 times a second and keeps one finger on the Hold point: held down while the square is below the box, released when it is above, and quick taps to hover.",
            "When the minigame ends it scans the WHOLE screen (except the menu/hotbar rows) for the white Collect circle (a bright disc with a black finger; 30 px far away, 66 px close) for up to 10 s. It never presses a spot blindly: no button, no press. The Wall-Climb button looks the same but is bigger (~90 px) and has a tall climbing icon in its label, so it is ignored completely.",
            "Holds the Collect button for the Collect hold time, checks that it vanished (retries up to 3 times), then casts again.",
            "Safety nets: it stops by itself after 6 casts without a bite (out of bait? wrong spot?) and has an optional auto-stop timer (Tune > Timing).",
            "Everything happens on your phone. The app has no internet permission."
        }, false);

        Ui.collapsible(c, p, "Best setup", new String[]{
            "Rod equipped, standing still at the pier edge, phone in landscape.",
            "Run Setup until all items are green, then use the floating button over the game.",
            "Check the Home preview: a yellow box and a white square must appear while a bar is on screen. 'no bar' means the scan region needs adjusting (Tune > Bar > Pick).",
            "Square runs the wrong way? Turn on Invert. It wobbles? Lower Response or raise Damping. It sinks while 'level'? Raise Hover.",
            "Long-press the floating START (idle) to test-hold the Hold point for 2 seconds. STOP with a tap or Volume Down."
        }, false);

        Ui.collapsible(c, p, "Rods, bait & loot", new String[]{
            "Three rods: Basic, Rare and Legendary. Basic comes from the shop after the permit quest.",
            "The Legendary route reportedly starts with the Drowned Lure from a hidden fishing spot (one guide says the fifth catch there), then a ghost fisherman's clue, then luck.",
            "Fishing pays out crafting materials (for example Mythical Ores, Metal Scraps, Silk Threads) and fish used in quests such as the Soryu chain. It is also listed as a source of a shotgun schematic."
        }, false);

        Ui.collapsible(c, p, "If it does not work", new String[]{
            "Home shows 'Press response'. 'square does NOT react' means the game ignores the Hold point: use Tune > Taps > Hold point > Pick and tap another empty spot, or long-press the floating START to test-hold.",
            "The floating button shows 'press NN% lag NNms': lag is the phone's dead time per press. Home shows touches ok / dropped: lots of 'dropped' means presses are being cancelled.",
            "'no bar' on the Home preview means the bar is not being found: use Tune > Bar > Pick.",
            "Home > Save trace writes Download/slayers_trace.csv (square and box positions plus every press and collect candidate). Attach it in the chat if you want the settings tuned."
        }, false);

        Ui.collapsible(c, p, "Auto style", new String[]{
            "Tune > Steering > Press style: Presses is the consistent default. Smooth keeps one finger down between presses (experimental, falls back by itself). Auto tries both in 6-second windows and keeps whichever holds the square inside the box longest.",
            "Home shows the scores, for example 'presses 71%  smooth -'."
        }, false);

        Ui.collapsible(c, p, "Safety & rules", new String[]{
            "This app only looks at the screen and sends touches. It never stores or sends anything off your phone.",
            "Automating gameplay may break the game's or Roblox's rules and can get an account suspended. Use at your own risk."
        }, false);
        return p;
    }
}
