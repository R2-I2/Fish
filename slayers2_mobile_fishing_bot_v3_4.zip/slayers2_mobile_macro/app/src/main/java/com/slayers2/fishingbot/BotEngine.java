package com.slayers2.fishingbot;

import java.util.function.Supplier;

/**
 * The bot's state machine: cast -> wait for the bite -> minigame (Controller) -> scan for the collect button and hold it -> cast again.
 * Pure Java: touches come out through a Pressor, time goes through a Clock, so it can run against a fake world offline.
 * Runs on the worker thread: run() loops, step() is one iteration.
 */
final class BotEngine {
    static final int CASTING = 0, WAITING = 1, PLAYING = 2, FINISHING = 3;

    /** What the engine tells the frame processor to look for. */
    interface Vision {
        void setScanCollect(boolean on);
        void setScanBaseline(boolean on);
    }

    interface Listener {
        /** The engine stopped the bot by itself (auto-stop timer, no bites). Called on the worker thread. */
        void onStopped();
    }

    private final Clock clock;
    private final Supplier<Pressor> pressors;
    private final Supplier<Config> config;
    private final Vision vision;
    private final Controller controller;
    private final Listener listener;

    private volatile boolean alive = true;
    private volatile int state = CASTING;
    private volatile long startAt = 0;
    private long lastCast = 0, lastActive = 0, playBegan = 0;
    private int noBite = 0;

    BotEngine(Clock clock, Supplier<Pressor> pressors, Supplier<Config> config, Vision vision, Controller controller, Listener listener) {
        this.clock = clock;
        this.pressors = pressors;
        this.config = config;
        this.vision = vision;
        this.controller = controller;
        this.listener = listener;
    }

    /** Time (clock) at which the start delay ends; the overlay shows the countdown. */
    long startAtMs() { return startAt; }

    /** True from the minigame on (PLAYING / FINISHING), false while casting or waiting for the bite. */
    boolean afterMinigame() { return !(state == WAITING || state == CASTING); }

    int state() { return state; }

    void shutdown() { alive = false; }

    /** Prepares a new run (before BotState.running becomes true). */
    void reset(long startAtMs) {
        state = CASTING; lastCast = 0;
        controller.reset();
        Trace.reset();
        noBite = 0; BotState.casts = 0;
        startAt = startAtMs;
    }

    void run() {
        while (alive) {
            try {
                step();
            } catch (Throwable t) {
                BotState.status = "Error: " + t.getClass().getSimpleName();
                clock.sleep(500);
            }
        }
    }

    /** One iteration of the bot loop. */
    void step() {
        if (!BotState.running) {
            vision.setScanCollect(false);
            Pressor rin = pressors.get();
            if (rin != null) rin.release();
            clock.sleep(100);
            return;
        }
        Pressor in = pressors.get();
        if (in == null) { BotState.status = "Enable the Accessibility service"; BotState.note = "ACCESS OFF"; clock.sleep(500); return; }
        long now = clock.now();
        if (now < startAt) {
            BotState.status = "Starting in " + ((startAt - now) / 1000 + 1) + "s - switch to the game";
            BotState.note = "get ready";
            clock.sleep(150);
            return;
        }
        Config c = config.get();
        if (c.autoStopMin > 0 && now - BotState.startedAt > c.autoStopMin * 60000L) {
            stopBot("Auto-stop: " + c.autoStopMin + " min reached");
            return;
        }
        // remember the buttons that are there BEFORE the bite and in the first 0.8 s after the bar vanishes (climb button);
        // the collect button only shows up about a second later
        vision.setScanBaseline((state == WAITING || state == CASTING) || (state == PLAYING && now - BotState.lastSeen < 800));

        if (now - BotState.lastSeen < 300) {           // minigame on screen
            if (state != PLAYING) { playBegan = now; noBite = 0; }
            state = PLAYING;
            lastActive = now;
            controller.control(in, c);
            return;
        }
        controller.idle();
        in.release();

        switch (state) {
            case PLAYING:
                if (now - lastActive > 1500) {
                    // the bar must be gone for 1.5 s (short dropouts happen); a very short 'minigame' was just a misread
                    if (lastActive - playBegan > 1500) { state = FINISHING; BotState.rounds++; }
                    else { state = WAITING; lastCast = clock.now(); }
                } else clock.sleep(25);
                break;
            case FINISHING:
                finishRound(in, c);
                break;
            case CASTING:
                BotState.status = "Casting";
                BotState.note = "casting";
                BotState.casts++;
                in.hold(c.castX, c.castY, c.castPress);   // press the hand-icon cast button
                sleepWatch(c.castPress + c.castWait);
                lastCast = clock.now();
                state = WAITING;
                break;
            default: // WAITING
                BotState.status = "Waiting for a bite";
                BotState.note = "no bar yet";
                if (now - lastCast > c.failWait) {
                    if (++noBite >= 6) stopBot("Stopped: no bite after 6 casts (bait? fishing spot?)");
                    else state = CASTING;
                } else clock.sleep(30);
        }
    }

    /** After the minigame: find the collect button anywhere on screen, hold it, then recast (or go back to playing if the bar returns). */
    private void finishRound(Pressor in, Config c) {
        BotState.status = "Collecting";
        BotState.note = "collecting";
        boolean resumed = false;
        if (c.collectOn) {
            // Scan the WHOLE screen for the collect button (it follows the fish). Anything that looks like the
            // wall-climb button is ignored completely. The bot never presses a spot blindly: no button, no press.
            vision.setScanCollect(true);
            long w0 = clock.now();
            while (alive && BotState.running && clock.now() - w0 < 10000
                    && clock.now() - BotState.collectTime > 400) {
                if (barBack()) { resumed = true; break; }
                clock.sleep(50);
            }
            boolean pressedAny = false;
            for (int attempt = 0; attempt < 3 && !resumed && alive && BotState.running; attempt++) {
                if (barBack()) { resumed = true; break; }
                boolean found = clock.now() - BotState.collectTime < 400;
                if (!found) break;                                                  // nothing to collect (yet)
                if (sleepWatch(120)) { resumed = true; break; }                     // let a moving button settle
                found = clock.now() - BotState.collectTime < 400;
                if (!found) break;
                int hx = BotState.collectX, hy = BotState.collectY;
                BotState.note = "collect found";
                Trace.add("C", hx, hy, BotState.collectD, attempt);
                in.pressAndWait(hx, hy, c.collectHold);
                pressedAny = true;
                if (sleepWatch(500)) { resumed = true; break; }
                if (clock.now() - BotState.collectTime >= 700) break;   // button gone -> collected
            }
            if (!pressedAny && !resumed) BotState.note = "no collect button";
            vision.setScanCollect(false);
        } else {
            resumed = sleepWatch(500);
        }
        if (resumed) { state = PLAYING; BotState.rounds = Math.max(0, BotState.rounds - 1); playBegan = clock.now(); lastActive = playBegan; }
        else state = CASTING;
    }

    /** Stops the bot from the worker thread (time limit, no bites...). */
    private void stopBot(String why) {
        BotState.running = false;
        BotState.status = why;
        BotState.note = "";
        Pressor rin = pressors.get();
        if (rin != null) rin.release();
        if (listener != null) listener.onStopped();
    }

    /** True when the fishing bar is on screen right now. */
    private boolean barBack() {
        return clock.now() - BotState.lastSeen < 400;
    }

    /** Sleeps in small steps and stops early (returning true) as soon as the bar shows up. */
    private boolean sleepWatch(long ms) {
        long end = clock.now() + ms;
        while (alive && BotState.running && clock.now() < end) {
            if (barBack()) return true;
            clock.sleep(30);
        }
        return false;
    }
}
