package com.slayers2.fishingbot;

import java.nio.ByteBuffer;

/**
 * Finds the white square (indicator) and the yellow-green box (target) inside the scan region.
 * Reads the raw frame buffer directly; no bitmap allocation.
 * Colours were checked against a real screenshot: white square ~ (196,197,199),
 * green box edge ~ (143,171,11), track background ~ (12,27,46).
 */
final class BarDetector {
    enum Status {
        FOUND,       // square and box found, the fields below are updated
        NOT_FOUND,   // no bar in this frame
        REJECTED     // something was seen but it is not trusted (region too small, box too tall, sudden jump): skip this frame
    }

    // last accepted reading
    double indY = -1, tgtY = -1, boxH = 0;
    long seenAt = 0;
    /** The time (clock) at which the last frame was evaluated. */
    long frameTime = 0;

    private boolean[] rowW, rowB;
    private int glitch = 0;
    private double knownBoxH = 0;

    Status detect(Frame f, Config c, Clock clock) {
        final ByteBuffer buf = f.buf;
        final int rs = f.rs, ps = f.ps;

        final int x0 = Math.max(0, c.x), x1 = Math.min(f.w, c.x + c.w);
        final int y0 = Math.max(0, c.y), y1 = Math.min(f.h, c.y + c.h);
        if (x1 - x0 < 4 || y1 - y0 < 4) return Status.REJECTED;
        final int rw = x1 - x0, rh = y1 - y0;
        final int needW = Math.max(3, rw * 35 / 100), needB = Math.max(3, rw * 3 / 10);
        if (rowW == null || rowW.length < rh) { rowW = new boolean[rh]; rowB = new boolean[rh]; }

        for (int yy = 0; yy < rh; yy++) {
            int wc = 0, gc = 0, base = (y0 + yy) * rs;
            for (int xx = x0; xx < x1; xx++) {
                int o = base + xx * ps;
                int r = buf.get(o) & 0xFF, g = buf.get(o + 1) & 0xFF, b = buf.get(o + 2) & 0xFF;
                int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
                boolean neutral = mn > 150 && mx - mn < 35;                                     // the white square
                boolean greenish = mn >= 140 && g >= r && g >= b && g - mn <= 75 && g - b >= 15;   // ...light green inside the green box
                if (neutral || greenish) wc++;
                else if (mx >= 140 && g * 5 >= r * 4 && g * 5 > b * 8 && (mx - mn) * 2 > mx) gc++;   // bright yellow OR green outline
            }
            rowW[yy] = wc >= needW;
            rowB[yy] = gc >= needB;
        }

        final long nowMs = clock.now();
        frameTime = nowMs;
        final boolean fresh = nowMs - seenAt < 250 && indY > 0;
        final double refRow = fresh ? indY - y0 : -1;
        final double refBox = (nowMs - seenAt < 400 && tgtY > 0) ? tgtY - y0 : -1;

        // ---- the square: a white run about 40 px tall (the top cap is 1-2 rows, water glare is much taller); when
        // several candidates exist take the one closest to where the square just was
        final int minSq = 14, maxSq = 62;
        int bestS = -1, bestE = -1;
        double bestCost = Double.MAX_VALUE;
        int s0 = -1, last = -1;
        for (int yy = 0; yy <= rh; yy++) {
            boolean on = yy < rh && rowW[yy];
            if (on) {
                if (s0 < 0) s0 = yy;
                last = yy;
            } else if (s0 >= 0 && (yy >= rh || yy - last > 8)) {   // gap of up to 8 px: the box outline can cut the square in two
                int hgt = last - s0 + 1;
                if (hgt >= minSq && hgt <= maxSq) {
                    double cen = (s0 + last) / 2.0;
                    double cost = refRow >= 0 ? Math.abs(cen - refRow) : Math.abs(hgt - 40.0);
                    if (cost < bestCost) { bestCost = cost; bestS = s0; bestE = last; }
                }
                s0 = -1;
            }
        }

        // ---- the box: yellow/green outline rows (top and bottom edge); partial detections are completed with the known height
        int gMin = -1, gMax = -1;
        double bestG = Double.MAX_VALUE;
        int gs = -1, gl = -1, cnt = 0;
        for (int yy = 0; yy <= rh; yy++) {
            boolean on = yy < rh && rowB[yy];
            if (on) {
                if (gs < 0) { gs = yy; cnt = 0; }
                gl = yy;
                cnt++;
            } else if (gs >= 0 && (yy >= rh || yy - gl > 90)) {
                double cen = (gs + gl) / 2.0;
                double cost = refBox >= 0 ? Math.abs(cen - refBox) : -cnt;
                if (cost < bestG) { bestG = cost; gMin = gs; gMax = gl; }
                gs = -1;
            }
        }
        if (bestS < 0 || gMin < 0) return Status.NOT_FOUND;

        final double span = gMax - gMin + 1;
        double boxCenter = (gMin + gMax) / 2.0;
        if (span > 85.0) return Status.REJECTED;                                // far too tall to be the box
        if (span >= 50.0) {
            knownBoxH = knownBoxH == 0 ? span : 0.8 * knownBoxH + 0.2 * span;
        } else if (knownBoxH > 0) {                                             // only one edge was seen
            double prev = refBox >= 0 ? refBox : boxCenter;
            double below = boxCenter + knownBoxH / 2, above = boxCenter - knownBoxH / 2;
            boxCenter = Math.abs(below - prev) <= Math.abs(above - prev) ? below : above;
        }

        final double newInd = y0 + (bestS + bestE) / 2.0;
        final double newTgt = y0 + boxCenter;
        // a sudden jump of the square or the box between two frames is a misread: ignore it (but accept after 3 in a row)
        if (fresh && (Math.abs(newInd - indY) > 120 || Math.abs(newTgt - tgtY) > 150) && glitch < 3) {
            glitch++;
            return Status.REJECTED;
        }
        glitch = 0;
        indY = newInd;
        tgtY = newTgt;
        boxH = knownBoxH > 0 ? knownBoxH : span;
        seenAt = nowMs;
        return Status.FOUND;
    }
}
