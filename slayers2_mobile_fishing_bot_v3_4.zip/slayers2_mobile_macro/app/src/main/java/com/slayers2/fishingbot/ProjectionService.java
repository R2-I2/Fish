package com.slayers2.fishingbot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spannable;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

/**
 * Android side of the bot: screen capture, the worker thread, the floating START/STOP bubble and the notification.
 * The logic lives in plain classes: FrameProcessor (what is on screen), BotEngine (the state machine), Controller (steering).
 */
public class ProjectionService extends Service {
    public static final String ACTION_TOGGLE = "com.slayers2.fishingbot.TOGGLE";
    public static final String ACTION_QUIT = "com.slayers2.fishingbot.QUIT";
    public static final String ACTION_TEACH = "com.slayers2.fishingbot.TEACH";
    public static final String ACTION_FORGET = "com.slayers2.fishingbot.FORGET";
    private static final String CHANNEL = "s2bot";
    private static final int NOTIF_ID = 9;
    private static final String PREFS = "bot";

    private final Clock clock = new RealClock();
    private final Frame frame = new Frame();
    private final KnownButtons known = new KnownButtons();
    private FrameProcessor processor;
    private BotEngine engine;
    private Controller controller;

    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay vdisplay;
    private HandlerThread captureThread;
    private Thread worker;
    private volatile boolean alive = true;
    private MediaProjection.Callback projectionCallback;

    // floating START/STOP button
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView overlay;
    private boolean lastShownRunning = false;
    private String shownLabel, shownNote;     // what the bubble currently shows (setText / background only when it changes)
    private boolean shownOn;

    private int cw, ch;
    private volatile Config cfg;

    @Override public void onCreate() {
        super.onCreate();
        cfg = ConfigStore.load(this);
        final SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        controller = new Controller(clock, new Controller.ArmStore() {
            @Override public void load(double[] score, int[] tries) {
                SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
                for (int i = 0; i < 3; i++) { score[i] = p.getFloat("as" + i, -1f); tries[i] = p.getInt("at" + i, 0); }
            }
            @Override public void save(double[] score, int[] tries) {
                SharedPreferences.Editor ed = getSharedPreferences(PREFS, MODE_PRIVATE).edit();
                for (int i = 0; i < 3; i++) ed.putFloat("as" + i, (float) score[i]).putInt("at" + i, tries[i]);
                ed.apply();
            }
        }, Math::random);
        processor = new FrameProcessor(clock, known, () -> engine != null && engine.afterMinigame());
        engine = new BotEngine(clock, () -> InputService.instance, () -> cfg, processor, controller,
                () -> ui.post(this::updateNotification));
        controller.loadArms();
        known.setStore(s -> getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("taught", s).apply());
        known.loadTaught(sp.getString("taught", ""));
    }

    @Override public int onStartCommand(Intent in, int flags, int id) {
        if (in != null && ACTION_TEACH.equals(in.getAction())) {      // 'Teach the climb button'
            processor.startTeaching(3500);
            BotState.status = "Learning the buttons on screen (climb)...";
            return START_NOT_STICKY;
        }
        if (in != null && ACTION_FORGET.equals(in.getAction())) {
            known.clearTaught();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove("taught").apply();
            BotState.status = "Forgot the taught buttons";
            if (!BotState.projectionReady) stopSelf();      // started only for this: do not leave an idle service behind
            return START_NOT_STICKY;
        }
        if (in != null && ACTION_QUIT.equals(in.getAction())) {   // 'Stop capture' from the notification
            BotState.running = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        if (in != null && ACTION_TOGGLE.equals(in.getAction())) {
            toggle();
            return START_NOT_STICKY;
        }
        startForegroundCompat();
        if (in != null && in.hasExtra("data")) {
            int rc = in.getIntExtra("resultCode", 0);
            Intent data = getData(in);
            startCapture(rc, data);
        }
        return START_NOT_STICKY;
    }

    @SuppressWarnings("deprecation")
    private Intent getData(Intent in) {
        if (Build.VERSION.SDK_INT >= 33) return in.getParcelableExtra("data", Intent.class);
        return in.getParcelableExtra("data");
    }

    // ---------------------------------------------------------------- capture

    private void startCapture(int rc, Intent data) {
        releaseCapture();
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = m.getMediaProjection(rc, data);
        if (projection == null) { BotState.status = "Screen capture was denied"; return; }

        // capture at full resolution: thin outlines survive, coordinates map 1:1 to the screen
        Point real = ConfigStore.realSize(this);
        cw = Math.max(2, real.x);
        ch = Math.max(2, real.y);
        cfg = ConfigStore.load(this);

        captureThread = new HandlerThread("s2-capture");
        captureThread.start();
        Handler handler = new Handler(captureThread.getLooper());

        // Android 14+ requires a callback to be registered BEFORE creating the virtual display.
        projectionCallback = new MediaProjection.Callback() {
            @Override public void onStop() {
                if (!alive) return;
                BotState.running = false;
                BotState.projectionReady = false;
                BotState.status = "Screen capture stopped";
                stopSelf();
            }
        };
        projection.registerCallback(projectionCallback, handler);

        reader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2);
        int dpi = getResources().getDisplayMetrics().densityDpi;
        vdisplay = projection.createVirtualDisplay("S2FishingCapture", cw, ch, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        reader.setOnImageAvailableListener(r -> {
            Image im = null;
            try {
                im = r.acquireLatestImage();
                if (im != null) process(im);
            } catch (Throwable t) {
                BotState.status = "Capture error: " + t.getClass().getSimpleName();
            } finally {
                if (im != null) im.close();
            }
        }, handler);

        BotState.projectionReady = true;
        BotState.status = "Ready";
        if (worker == null || !worker.isAlive()) {
            worker = new Thread(engine::run, "s2-bot");
            worker.start();
        }
        updateNotification();
        ui.removeCallbacks(tick);
        ui.post(tick);
    }

    private void releaseCapture() {
        BotState.projectionReady = false;
        try { if (reader != null) reader.close(); } catch (Throwable ignored) {}
        try { if (vdisplay != null) vdisplay.release(); } catch (Throwable ignored) {}
        try { if (projection != null && projectionCallback != null) projection.unregisterCallback(projectionCallback); } catch (Throwable ignored) {}
        try { if (projection != null) projection.stop(); } catch (Throwable ignored) {}
        try { if (captureThread != null) captureThread.quitSafely(); } catch (Throwable ignored) {}
        reader = null; vdisplay = null; projection = null; captureThread = null;
    }

    /** Runs on the capture thread for every frame. */
    private void process(Image im) {
        Image.Plane pl = im.getPlanes()[0];
        frame.set(pl.getBuffer(), pl.getRowStride(), pl.getPixelStride(), cw, ch);
        processor.process(frame, cfg);
    }

    // ---------------------------------------------------------------- start / stop

    private void toggle() {
        if (!BotState.projectionReady) {
            BotState.status = "Grant screen capture first";
            return;
        }
        if (BotState.running) {
            BotState.running = false;
            BotState.status = "Stopped";
            BotState.note = "";
        } else {
            if (InputService.instance == null) {
                BotState.status = "Enable the Accessibility service first";
                BotState.note = "ACCESS OFF";
                ui.postDelayed(() -> BotState.note = "", 3500);
                return;
            }
            BotState.gOk = 0; BotState.gCancel = 0; BotState.gFail = 0;
            BotState.rounds = 0; BotState.startedAt = System.currentTimeMillis();
            cfg = ConfigStore.load(this);
            engine.reset(clock.now() + cfg.startDelay * 1000L);
            BotState.running = true;
            BotState.status = "Starting...";
        }
        updateNotification();
    }

    // ---------------------------------------------------------------- floating button

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!alive) return;
            try {
                cfg = ConfigStore.load(ProjectionService.this);   // pick up Tune-tab changes live
                ensureOverlay();
                refreshOverlay();
                if (BotState.running != lastShownRunning) {
                    lastShownRunning = BotState.running;
                    updateNotification();
                }
            } catch (Throwable ignored) {}
            ui.postDelayed(this, 300);
        }
    };

    /**
     * Small draggable START/STOP bubble over the game. While the bot runs, its own gestures can cancel a
     * finger that is still down, so STOP fires on touch-DOWN (not on release).
     */
    private void ensureOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return;
        final WindowManager wm = getSystemService(WindowManager.class);
        final float d = getResources().getDisplayMetrics().density;
        final int size = (int) (58 * d);
        final TextView t = new TextView(this);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setMinWidth(size);
        t.setMinHeight(size);
        t.setPadding((int) (10 * d), (int) (6 * d), (int) (10 * d), (int) (6 * d));
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        final SharedPreferences sp = getSharedPreferences("bot", MODE_PRIVATE);
        Point real = ConfigStore.realSize(this);
        lp.x = sp.getInt("ox", (int) (8 * d));
        lp.y = sp.getInt("oy", real.y / 2 - size / 2);

        t.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean handled, dragging;
            final Runnable longPress = new Runnable() {
                @Override public void run() {
                    if (dragging || handled || BotState.running) return;
                    handled = true;
                    InputService in = InputService.instance;
                    Config c = cfg;
                    if (in == null) { BotState.note = "ACCESS OFF"; return; }
                    in.hold(c.cx, c.cy, 2000);            // test: does the game react to an injected hold?
                    BotState.note = "test hold 2s";
                    ui.postDelayed(() -> BotState.note = "", 2400);
                }
            };

            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = lp.x; startY = lp.y;
                        dragging = false; handled = false;
                        if (BotState.running) { handled = true; toggle(); refreshOverlay(); }
                        else ui.postDelayed(longPress, 700);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (handled) return true;
                        float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                        if (!dragging && Math.hypot(dx, dy) > 12 * d) { dragging = true; ui.removeCallbacks(longPress); }
                        if (dragging) {
                            lp.x = startX + (int) dx;
                            lp.y = startY + (int) dy;
                            wm.updateViewLayout(v, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ui.removeCallbacks(longPress);
                        if (handled) return true;
                        if (dragging) sp.edit().putInt("ox", lp.x).putInt("oy", lp.y).apply();
                        else { toggle(); refreshOverlay(); }
                        return true;
                    default:
                        ui.removeCallbacks(longPress);
                        return true;
                }
            }
        });

        try {
            wm.addView(t, lp);
            overlay = t;
            refreshOverlay();
        } catch (Throwable ex) {
            BotState.status = "Floating button error: " + ex.getClass().getSimpleName();
        }
    }

    /** Updates the bubble; the text and the background are only touched when something changed (this runs every 300 ms). */
    private void refreshOverlay() {
        if (overlay == null) return;
        final boolean on = BotState.running;
        final long now = clock.now();
        final long startAt = engine.startAtMs();
        final String label = !on ? "START" : (now < startAt ? String.valueOf((startAt - now) / 1000 + 1) : "STOP");
        final String note = BotState.note == null ? "" : BotState.note;
        if (shownLabel != null && on == shownOn && label.equals(shownLabel) && note.equals(shownNote)) return;
        if (note.isEmpty()) {
            overlay.setText(label);
        } else {
            SpannableString sp = new SpannableString(label + "\n" + note);
            sp.setSpan(new RelativeSizeSpan(0.7f), label.length() + 1, sp.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            overlay.setText(sp);
        }
        if (shownLabel == null || on != shownOn) {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(29 * getResources().getDisplayMetrics().density);
            bg.setColor(on ? 0xCCC62828 : 0xCC2E7D32);
            overlay.setBackground(bg);
        }
        shownLabel = label;
        shownNote = note;
        shownOn = on;
    }

    private void removeOverlay() {
        try {
            if (overlay != null) getSystemService(WindowManager.class).removeView(overlay);
        } catch (Throwable ignored) {}
        overlay = null;
        shownLabel = null;
    }

    // ---------------------------------------------------------------- notification

    private void startForegroundCompat() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Fishing Bot", NotificationManager.IMPORTANCE_LOW));
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private Notification buildNotification() {
        Intent t = new Intent(this, ProjectionService.class).setAction(ACTION_TOGGLE);
        PendingIntent toggle = PendingIntent.getService(this, 1, t,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this, 2, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean on = BotState.running;
        Notification.Action a = new Notification.Action.Builder(
                Icon.createWithResource(this, on ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play),
                on ? "STOP bot" : "START bot", toggle).build();
        Intent q = new Intent(this, ProjectionService.class).setAction(ACTION_QUIT);
        PendingIntent quit = PendingIntent.getService(this, 3, q,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Action stopCap = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "STOP capture", quit).build();
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Slayers 2 Fishing Bot")
                .setContentText(on ? "Running" : "Idle - tap START when the game is open")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .setContentIntent(open)
                .addAction(a)
                .addAction(stopCap)
                .build();
    }

    private void updateNotification() {
        getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification());
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onDestroy() {
        alive = false;
        engine.shutdown();
        BotState.running = false;
        BotState.status = "Screen capture stopped";
        BotState.note = "";
        InputService rin = InputService.instance;
        if (rin != null) rin.release();
        ui.removeCallbacks(tick);
        removeOverlay();
        releaseCapture();
        if (worker != null) worker.interrupt();
        super.onDestroy();
    }
}
