package com.slayers2.fishingbot;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/**
 * Styling toolkit: deep-ocean navy theme, gradient cards with fine borders, aqua accent, gradient buttons with ripples,
 * drawn line icons, segmented controls, stat tiles, collapsible cards.
 */
final class Ui {
    static final int BG = 0xFF060B1A, SURFACE = 0xFF0E1531, CARD = 0xFF161E44, CARD_T = 0xFF1B2552, CARD_B = 0xFF131A3E,
            CARD2 = 0xFF232C58, STROKE = 0xFF2B3768,
            ACCENT = 0xFF5EEAD4, ACCENT2 = 0xFF38BDF8, GOOD = 0xFF34D399, BAD = 0xFFFB7185, WARN = 0xFFFBBF24,
            TEXT = 0xFFEEF2FF, MUTED = 0xFF93A0CF, RED = 0xFFF43F5E, GREEN_BTN = 0xFF10B981,
            VIOLET = 0xFF6D5BE0;   // marker value: "primary" gradient button (aqua -> sky, dark text)
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    interface OnInt { void run(int v); }
    interface OnBool { void run(boolean b); }

    private Ui() {}

    static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    // ------------------------------------------------------------------ shapes

    static GradientDrawable round(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable shape(Context c, int fill, float radiusDp, int stroke, float strokeDp) {
        GradientDrawable g = round(c, fill, radiusDp);
        if (strokeDp > 0) g.setStroke(Math.max(1, dp(c, strokeDp)), stroke);
        return g;
    }

    static GradientDrawable gradient(Context c, int c1, int c2, GradientDrawable.Orientation o, float radiusDp, int stroke, float strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setOrientation(o);
        g.setColors(new int[]{c1, c2});
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeDp > 0) g.setStroke(Math.max(1, dp(c, strokeDp)), stroke);
        return g;
    }

    /** Filled circle (use with square views). */
    static GradientDrawable disc(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    static GradientDrawable discGradient(int c1, int c2) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        g.setColors(new int[]{c1, c2});
        return g;
    }

    static Drawable ripple(Drawable content) {
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, null);
    }

    // ------------------------------------------------------------------ layout helpers

    static LinearLayout.LayoutParams lp(Context c, int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    /** Width 0 + weight: shares a row between children. */
    static LinearLayout.LayoutParams lpw(Context c, float weight, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, WRAP, weight);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hrow(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private static void cardLook(Context c, LinearLayout l) {
        l.setBackground(gradient(c, CARD_T, CARD_B, GradientDrawable.Orientation.TOP_BOTTOM, 18, STROKE, 1));
        int p = dp(c, 12);
        l.setPadding(p, p, p, p);
        l.setElevation(dp(c, 2));
    }

    /** Gradient card with a fine border and a bottom margin (stack them in a page). */
    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        cardLook(c, l);
        l.setLayoutParams(lp(c, MATCH, WRAP, 0, 0, 0, 8));
        return l;
    }

    /** Same look without margins: for cells of a row. */
    static LinearLayout panel(Context c) {
        LinearLayout l = vbox(c);
        cardLook(c, l);
        return l;
    }

    static LinearLayout twoCols(Context c, View a, View b) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(a, lpw(c, 1f, 0, 0, 6, 0));
        row.addView(b, lpw(c, 1f, 6, 0, 0, 0));
        row.setLayoutParams(lp(c, MATCH, WRAP, 0, 0, 0, 8));
        return row;
    }

    static View dot(Context c, int color) {
        View v = new View(c);
        v.setBackground(disc(color));
        return v;
    }

    /** Fade + small slide up: used when a page or a section appears. */
    static void reveal(Context c, View v) {
        v.setAlpha(0f);
        v.setTranslationY(dp(c, 10));
        v.animate().alpha(1f).translationY(0f).setDuration(220).start();
    }

    // ------------------------------------------------------------------ text

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    /** Heavy display text (state, page titles). */
    static TextView title(Context c, String s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        return t;
    }

    /** Small spaced caps section label. */
    static TextView label(Context c, String s) {
        TextView t = text(c, s.toUpperCase(), 11, ACCENT, true);
        t.setLetterSpacing(0.14f);
        t.setPadding(0, 0, 0, dp(c, 6));
        return t;
    }

    // ------------------------------------------------------------------ buttons, chips

    /** bg == VIOLET gives the primary aqua gradient button; GREEN_BTN / RED give gradient green / coral; others are solid. */
    static Button button(Context c, String label, int bg, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        int fg = Color.WHITE;
        Drawable fill;
        if (bg == VIOLET) {
            fill = gradient(c, ACCENT, ACCENT2, GradientDrawable.Orientation.LEFT_RIGHT, 12, 0, 0);
            fg = 0xFF04201D;
        } else if (bg == GREEN_BTN) {
            fill = gradient(c, 0xFF22C55E, 0xFF059669, GradientDrawable.Orientation.TOP_BOTTOM, 12, 0, 0);
        } else if (bg == RED) {
            fill = gradient(c, 0xFFFB7185, 0xFFE11D48, GradientDrawable.Orientation.TOP_BOTTOM, 12, 0, 0);
        } else {
            fill = round(c, bg, 12);
        }
        b.setTextColor(fg);
        b.setBackground(ripple(fill));
        b.setStateListAnimator(null);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9));
        b.setOnClickListener(l);
        return b;
    }

    /** Transparent button with a thin border, for secondary actions. */
    static Button ghostButton(Context c, String label, View.OnClickListener l) {
        Button b = button(c, label, 0x00000000, l);
        b.setTextColor(ACCENT);
        b.setBackground(ripple(shape(c, 0x00000000, 12, STROKE, 1)));
        return b;
    }

    /** Button with a drawn icon + label. primary = aqua gradient with dark content, else a bordered ghost button. */
    static LinearLayout iconButton(Context c, int icon, String label, boolean primary, View.OnClickListener l) {
        LinearLayout b = hrow(c);
        b.setGravity(Gravity.CENTER);
        b.setClickable(true);
        b.setPadding(dp(c, 12), dp(c, 8), dp(c, 14), dp(c, 8));
        int fg = primary ? 0xFF04201D : ACCENT;
        b.setBackground(ripple(primary
                ? gradient(c, ACCENT, ACCENT2, GradientDrawable.Orientation.LEFT_RIGHT, 12, 0, 0)
                : shape(c, 0x00000000, 12, STROKE, 1)));
        b.addView(new IconView(c, icon, fg), new LinearLayout.LayoutParams(dp(c, 16), dp(c, 16)));
        TextView t = text(c, label, 12, fg, true);
        t.setPadding(dp(c, 7), 0, 0, 0);
        b.addView(t);
        b.setOnClickListener(l);
        return b;
    }

    static TextView chip(Context c) {
        TextView t = text(c, "", 12, Color.WHITE, true);
        t.setPadding(dp(c, 10), dp(c, 4), dp(c, 10), dp(c, 4));
        t.setGravity(Gravity.CENTER);
        return t;
    }

    /** Text, background and colour only depend on ok, so nothing is touched while ok stays the same (this runs 5 times a second). */
    static void setChip(Context c, TextView t, boolean ok, String yes, String no) {
        Boolean now = ok;
        if (now.equals(t.getTag())) return;
        t.setTag(now);
        t.setText(ok ? "✓ " + yes : "✗ " + no);
        t.setBackground(round(c, ok ? 0xFF0F3D2B : 0xFF4A1D2A, 10));
        t.setTextColor(ok ? GOOD : BAD);
    }

    /** setText only when the text really changed: every setText starts a measure/layout pass. */
    static void setText(TextView t, CharSequence s) {
        CharSequence cur = t.getText();
        if (cur != null && s != null && cur.length() == s.length() && cur.toString().contentEquals(s)) return;
        t.setText(s);
    }

    /** setTextColor only when the colour really changed. */
    static void setColor(TextView t, int color) {
        if (t.getCurrentTextColor() != color) t.setTextColor(color);
    }

    static void styleSwitch(Switch s) {
        int[][] states = {{android.R.attr.state_checked}, {}};
        s.setThumbTintList(new ColorStateList(states, new int[]{ACCENT, 0xFFB6C0E6}));
        s.setTrackTintList(new ColorStateList(states, new int[]{0x885EEAD4, 0x662B3768}));
    }

    // ------------------------------------------------------------------ segmented control

    static final class Segmented {
        final LinearLayout view;
        final TextView[] items;
        final Context ctx;
        final OnInt onSelect;

        Segmented(Context ctx, LinearLayout view, TextView[] items, OnInt onSelect) {
            this.ctx = ctx; this.view = view; this.items = items; this.onSelect = onSelect;
        }

        /** Only restyles (no callback). */
        void paint(int sel) {
            for (int i = 0; i < items.length; i++) {
                boolean on = i == sel;
                items[i].setBackground(on ? gradient(ctx, ACCENT, ACCENT2, GradientDrawable.Orientation.LEFT_RIGHT, 10, 0, 0) : null);
                items[i].setTextColor(on ? 0xFF04201D : MUTED);
            }
        }

        void select(int sel) {
            paint(sel);
            if (onSelect != null) onSelect.run(sel);
        }
    }

    static Segmented segmented(final Context c, String[] labels, int initial, OnInt onSelect) {
        LinearLayout row = hrow(c);
        row.setBackground(shape(c, SURFACE, 13, STROKE, 1));
        row.setPadding(dp(c, 3), dp(c, 3), dp(c, 3), dp(c, 3));
        final Segmented s = new Segmented(c, row, new TextView[labels.length], onSelect);
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView t = text(c, labels[i], 13, MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(c, 16), dp(c, 8), dp(c, 16), dp(c, 8));
            t.setOnClickListener(v -> s.select(idx));
            s.items[i] = t;
            row.addView(t, new LinearLayout.LayoutParams(0, WRAP, 1f));
        }
        s.paint(initial);
        return s;
    }

    // ------------------------------------------------------------------ stat tile, collapsible card

    static final class Tile {
        final LinearLayout view;
        final TextView value;

        Tile(LinearLayout view, TextView value) { this.view = view; this.value = value; }
    }

    static Tile tile(Context c, String label) {
        LinearLayout v = vbox(c);
        v.setBackground(shape(c, SURFACE, 12, STROKE, 1));
        v.setPadding(dp(c, 10), dp(c, 6), dp(c, 10), dp(c, 6));
        TextView val = new TextView(c);
        val.setText("-");
        val.setTextSize(17);
        val.setTextColor(TEXT);
        val.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        TextView lab = text(c, label, 9, MUTED, false);
        lab.setLetterSpacing(0.1f);
        v.addView(val);
        v.addView(lab);
        return new Tile(v, val);
    }

    static void collapsible(final Context c, LinearLayout parent, String title, String[] lines, boolean expanded) {
        LinearLayout card = card(c);
        LinearLayout head = hrow(c);
        final TextView chev = text(c, expanded ? "▾" : "▸", 16, ACCENT, true);
        head.addView(text(c, title, 15, TEXT, true), new LinearLayout.LayoutParams(0, WRAP, 1f));
        head.addView(chev);
        final LinearLayout body = vbox(c);
        for (int i = 0; i < lines.length; i++) {
            TextView t = text(c, "•  " + lines[i], 13, TEXT, false);
            t.setPadding(0, dp(c, 6), 0, 0);
            body.addView(t);
        }
        body.setVisibility(expanded ? View.VISIBLE : View.GONE);
        head.setOnClickListener(v -> {
            boolean show = body.getVisibility() != View.VISIBLE;
            body.setVisibility(show ? View.VISIBLE : View.GONE);
            chev.setText(show ? "▾" : "▸");
            if (show) reveal(c, body);
        });
        card.addView(head);
        card.addView(body);
        parent.addView(card);
    }

    // ------------------------------------------------------------------ steppers, sliders, switches

    static final class Stepper {
        final LinearLayout view;
        final TextView valueView;
        final int min, max, step;
        final String unit;
        int value;

        Stepper(LinearLayout view, TextView valueView, int min, int max, int step, String unit) {
            this.view = view; this.valueView = valueView;
            this.min = min; this.max = max; this.step = step; this.unit = unit;
        }

        void set(int v) {
            value = Math.max(min, Math.min(max, v));
            valueView.setText(value + unit);
        }
    }

    /** Label on the left, [-] value [+] on the right. Easier than typing numbers on a phone. */
    static Stepper stepper(final Context c, String label, int min, int max, int step, int initial,
                           String unit, final OnInt onChange) {
        LinearLayout row = hrow(c);
        row.setBackground(shape(c, SURFACE, 12, STROKE, 1));
        row.setPadding(dp(c, 10), dp(c, 4), dp(c, 6), dp(c, 4));
        TextView lab = text(c, label, 12, TEXT, false);
        row.addView(lab, new LinearLayout.LayoutParams(0, WRAP, 1f));
        final TextView val = new TextView(c);
        val.setTextSize(14);
        val.setTextColor(ACCENT);
        val.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        val.setGravity(Gravity.CENTER);
        final Stepper s = new Stepper(row, val, min, max, step, unit);
        Button minus = button(c, "−", CARD2, v -> { s.set(s.value - s.step); onChange.run(s.value); });
        Button plus = button(c, "+", CARD2, v -> { s.set(s.value + s.step); onChange.run(s.value); });
        row.addView(minus, new LinearLayout.LayoutParams(dp(c, 38), dp(c, 36)));
        row.addView(val, new LinearLayout.LayoutParams(dp(c, 74), WRAP));
        row.addView(plus, new LinearLayout.LayoutParams(dp(c, 38), dp(c, 36)));
        s.set(initial);
        return s;
    }

    static final class SeekRow {
        final LinearLayout view;
        final SeekBar bar;
        final TextView valueView;
        final int min;
        final String unit;

        SeekRow(LinearLayout view, SeekBar bar, TextView valueView, int min, String unit) {
            this.view = view; this.bar = bar; this.valueView = valueView; this.min = min; this.unit = unit;
        }

        void set(int v) {
            bar.setProgress(v - min);
            valueView.setText(v + unit);
        }
    }

    static SeekRow seek(Context c, String label, String hint, final int min, int max, int initial,
                        final String unit, final OnInt onChange) {
        LinearLayout box = vbox(c);
        box.setBackground(shape(c, SURFACE, 12, STROKE, 1));
        box.setPadding(dp(c, 10), dp(c, 8), dp(c, 10), dp(c, 2));
        LinearLayout top = hrow(c);
        top.addView(text(c, label, 13, TEXT, true), new LinearLayout.LayoutParams(0, WRAP, 1f));
        final TextView val = new TextView(c);
        val.setTextSize(14);
        val.setTextColor(ACCENT);
        val.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        top.addView(val);
        box.addView(top);
        if (hint != null && !hint.isEmpty()) box.addView(text(c, hint, 10, MUTED, false));
        SeekBar sb = new SeekBar(c);
        sb.setMax(max - min);
        sb.setProgressTintList(ColorStateList.valueOf(ACCENT));
        sb.setThumbTintList(ColorStateList.valueOf(ACCENT));
        box.addView(sb, new LinearLayout.LayoutParams(MATCH, WRAP));
        final SeekRow row = new SeekRow(box, sb, val, min, unit);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                val.setText((p + min) + unit);
                if (fromUser) onChange.run(p + min);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        row.set(initial);
        return row;
    }

    static Switch toggle(Context c, String label, boolean initial, final OnBool cb) {
        Switch s = new Switch(c);
        s.setText(label);
        s.setTextColor(TEXT);
        s.setTextSize(13);
        s.setChecked(initial);
        s.setPadding(0, dp(c, 6), 0, dp(c, 6));
        styleSwitch(s);
        s.setOnCheckedChangeListener((b, on) -> cb.run(on));
        return s;
    }
}
