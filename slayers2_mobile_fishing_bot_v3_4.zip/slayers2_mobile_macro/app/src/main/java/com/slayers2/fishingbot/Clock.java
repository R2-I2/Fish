package com.slayers2.fishingbot;

/** Time source of the bot logic. The real one uses the system clock; tests use a virtual clock that sleep() advances. */
interface Clock {
    long now();
    void sleep(long ms);
}
