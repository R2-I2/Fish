package com.slayers2.fishingbot;

/** Settings (plain data; ConfigStore loads and saves them). Defaults are fractions of the real screen, tuned on 2400x1080. */
public final class Config {
    public int x, y, w, h;          // scan region around the bar (screen px)
    public int cx, cy;              // where to press/hold during the minigame
    public int castX, castY;        // where to tap to cast (on the water)
    public boolean collectOn;       // hold the collect button after each catch
    public int colX, colY;          // (old fixed collect spot, no longer used: the button is searched on screen)
    public int castWait, failWait;  // ms
    public int castPress;           // ms: press length on the cast button
    public int collectHold;         // ms: hold length on the collect button
    public int cycle;               // ms: control cycle
    public int pressMs, pressMax;   // ms: shortest / longest press during the minigame
    public int collectMaxD;         // px: largest disc that may be the collect button (the climb button is bigger)
    public int autoStopMin;         // 0 = never
    public boolean smooth;          // unused since v2.3 (kept so saved settings stay compatible): see style
    public int style;               // 0 = auto (learns), 1 = presses, 2 = smooth hold
    public int startDelay;          // s
    public int hoverPct, kp10, kd10, ki10;
    public boolean invert;
}
