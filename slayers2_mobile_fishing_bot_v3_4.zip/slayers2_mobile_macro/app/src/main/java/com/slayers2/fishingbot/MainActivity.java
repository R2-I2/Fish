package com.slayers2.fishingbot;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int CAPTURE = 44;
    private static final String VERSION = "v3.4";
    private static final String[] TAB_NAME = {"Home", "Setup", "Tune", "Guide"};
    private static final int[] TAB_ICON = {IconView.HOME, IconView.STEPS, IconView.TUNE, IconView.BOOK};
    private static final int[] STEP_ICON = {IconView.ACCESS, IconView.CAPTURE, IconView.OVERLAY, IconView.BATTERY, IconView.BELL};
    private static final String[] STEP_SHORT = {"Accessibility", "Capture", "Floating", "Battery", "Notifications"};

    private Config cfg;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final View[] tabs = new View[4];
    private final LinearLayout[] railItem = new LinearLayout[4];
    private final IconView[] railIcon = new IconView[4];
    private final TextView[] railLabel = new TextView[4];
    private TextView headerTitle, headerChip, snack;
    private View headerDot;
    private LinearLayout headerChipBox;

    // Home
    private TextView stateText, statusText, readyText, infoText;
    private View stateDot, bigGlow, bigDisc, stopCapBtn;
    private FrameLayout bigWrap;
    private IconView bigIcon;
    private BarView barView;
    private SparkView spark;
    private Ui.Tile tRounds, tCasts, tTime, tLag, tTouch, tReact;
    private final IconView[] stripIcon = new IconView[5];
    private final TextView[] stripText = new TextView[5];
    private boolean shownRunning = false, shownInit = false;
    private long lastSpark = 0;
    private int sparkIn = 0, sparkSeen = 0;

    // Setup
    private TextView chipAcc, chipCap, chipOvl, chipBat, chipNotif;
    private final IconView[] stepIcon = new IconView[5];
    private final View[] stepTile = new View[5];
    private final int[] stepState = {-1, -1, -1, -1, -1};

    // Tune
    private TextView castVal, holdVal, regionVal;
    private Switch swCollect, swInvert;
    private Ui.Segmented segStyle;
    private final View[] tuneSection = new View[4];
    private Ui.Stepper stX, stY, stW, stH, stCast, stFail, stDelay, stCastPress, stColHold, stCycle, stPress, stPressMax, stColMax, stAutoStop;
    private Ui.SeekRow skHover, skP, skD, skI;

    private int dp(float v) { return Ui.dp(this, v); }
    /** System toast: still visible when this app has moved to the background (Pick / Teach flows). */
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private void save() { ConfigStore.save(this, cfg); }

    private final Runnable hideSnack = () -> snack.animate().alpha(0f).setDuration(200).start();

    /** In-app confirmation pill at the bottom of the screen. */
    private void snack(String msg) {
        snack.setText(msg);
        snack.setVisibility(View.VISIBLE);
        snack.setAlpha(0f);
        snack.setTranslationY(dp(12));
        snack.animate().alpha(1f).translationY(0f).setDuration(180).start();
        ui.removeCallbacks(hideSnack);
        ui.postDelayed(hideSnack, 2600);
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = ConfigStore.load(this);
        getWindow().setStatusBarColor(0xFF0C1433);
        getWindow().setNavigationBarColor(0xFF050918);

        FrameLayout host = new FrameLayout(this);
        host.setBackground(Ui.gradient(this, 0xFF0C1433, 0xFF050918, GradientDrawable.Orientation.TOP_BOTTOM, 0, 0, 0));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(buildRail(), new LinearLayout.LayoutParams(dp(78), Ui.MATCH));

        LinearLayout main = Ui.vbox(this);
        main.addView(buildHeader(), new LinearLayout.LayoutParams(Ui.MATCH, dp(50)));
        FrameLayout content = new FrameLayout(this);
        tabs[0] = scroll(buildHome());
        tabs[1] = scroll(buildSetup());
        tabs[2] = scroll(buildTune());
        tabs[3] = scroll(Guide.build(this));
        for (int i = 0; i < 4; i++) content.addView(tabs[i], new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        main.addView(content, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f));
        root.addView(main, new LinearLayout.LayoutParams(0, Ui.MATCH, 1f));
        host.addView(root, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        snack = Ui.text(this, "", 13, Ui.TEXT, true);
        snack.setPadding(dp(18), dp(10), dp(18), dp(10));
        snack.setBackground(Ui.gradient(this, 0xFF232C58, 0xFF1B2552, GradientDrawable.Orientation.TOP_BOTTOM, 20, Ui.ACCENT, 1));
        snack.setElevation(dp(6));
        snack.setVisibility(View.GONE);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        sp.setMargins(0, 0, 0, dp(18));
        host.addView(snack, sp);
        setContentView(host);

        syncTune();
        select(0);
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        cfg = ConfigStore.load(this);
        syncTune();
        ui.post(refresh);
        ui.post(anim);
    }

    @Override protected void onPause() {
        ui.removeCallbacks(refresh);
        ui.removeCallbacks(anim);
        super.onPause();
    }

    private ScrollView scroll(View inner) {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(inner);
        return sv;
    }

    private LinearLayout page() {
        LinearLayout l = Ui.vbox(this);
        l.setPadding(dp(12), dp(4), dp(12), dp(14));
        return l;
    }

    // ================================================================= chrome (rail + header)

    private View buildRail() {
        LinearLayout rail = Ui.vbox(this);
        rail.setBackgroundColor(0xFF0A1028);
        rail.setGravity(Gravity.CENTER_HORIZONTAL);
        rail.setPadding(dp(6), dp(10), dp(6), dp(10));

        FrameLayout logo = new FrameLayout(this);
        logo.setBackground(Ui.gradient(this, Ui.ACCENT, Ui.ACCENT2, GradientDrawable.Orientation.TL_BR, 14, 0, 0));
        logo.addView(new IconView(this, IconView.FISH, 0xFF04201D), new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER));
        rail.addView(logo, Ui.lp(this, dp(44), dp(44), 0, 0, 0, 14));

        for (int i = 0; i < 4; i++) {
            final int idx = i;
            LinearLayout item = Ui.vbox(this);
            item.setGravity(Gravity.CENTER_HORIZONTAL);
            item.setPadding(dp(2), dp(8), dp(2), dp(7));
            IconView icon = new IconView(this, TAB_ICON[i], Ui.MUTED);
            TextView lab = Ui.text(this, TAB_NAME[i], 10, Ui.MUTED, true);
            lab.setGravity(Gravity.CENTER);
            item.addView(icon, new LinearLayout.LayoutParams(dp(22), dp(22)));
            item.addView(lab, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 3, 0, 0));
            item.setOnClickListener(v -> select(idx));
            railItem[i] = item;
            railIcon[i] = icon;
            railLabel[i] = lab;
            rail.addView(item, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 4));
        }
        TextView ver = Ui.text(this, VERSION, 10, Ui.MUTED, false);
        ver.setGravity(Gravity.CENTER);
        rail.addView(ver, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 10, 0, 0));
        return rail;
    }

    private View buildHeader() {
        LinearLayout h = Ui.hrow(this);
        h.setPadding(dp(14), dp(4), dp(12), dp(4));
        LinearLayout left = Ui.vbox(this);
        headerTitle = Ui.title(this, "Home", 20, Ui.TEXT);
        left.addView(headerTitle);
        left.addView(Ui.text(this, "Slayers 2 fishing bot  ·  " + VERSION, 10, Ui.MUTED, false));
        h.addView(left, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));

        headerChipBox = Ui.hrow(this);
        headerChipBox.setPadding(dp(10), dp(5), dp(12), dp(5));
        headerDot = Ui.dot(this, Ui.MUTED);
        headerChipBox.addView(headerDot, Ui.lp(this, dp(8), dp(8), 0, 0, 7, 0));
        headerChip = Ui.text(this, "IDLE", 12, Ui.MUTED, true);
        headerChip.setLetterSpacing(0.08f);
        headerChipBox.addView(headerChip);
        headerChipBox.setBackground(Ui.shape(this, Ui.CARD2, 14, Ui.STROKE, 1));
        h.addView(headerChipBox);
        return h;
    }

    private void select(int idx) {
        for (int i = 0; i < 4; i++) {
            boolean on = i == idx;
            tabs[i].setVisibility(on ? View.VISIBLE : View.GONE);
            railItem[i].setBackground(on ? Ui.gradient(this, 0xFF232C58, 0xFF1B2552, GradientDrawable.Orientation.TOP_BOTTOM, 14, Ui.ACCENT & 0x66FFFFFF | 0x33000000, 1) : null);
            railLabel[i].setTextColor(on ? Ui.ACCENT : Ui.MUTED);
            railIcon[i].setColor(on ? Ui.ACCENT : Ui.MUTED);
        }
        headerTitle.setText(TAB_NAME[idx]);
        Ui.reveal(this, tabs[idx]);
    }

    // ================================================================= HOME

    private View buildHome() {
        LinearLayout p = page();
        LinearLayout cols = new LinearLayout(this);
        cols.setOrientation(LinearLayout.HORIZONTAL);

        // ---- hero: round start/stop button, state, quick actions
        LinearLayout hero = Ui.panel(this);
        hero.setMinimumHeight(dp(246));
        LinearLayout top = Ui.hrow(this);

        bigWrap = new FrameLayout(this);
        bigGlow = new View(this);
        bigGlow.setBackground(Ui.disc(0x5522C55E));
        bigDisc = new View(this);
        bigDisc.setBackground(Ui.discGradient(0xFF22C55E, 0xFF059669));
        bigIcon = new IconView(this, IconView.PLAY, 0xFFFFFFFF);
        bigWrap.addView(bigGlow, new FrameLayout.LayoutParams(dp(128), dp(128), Gravity.CENTER));
        bigWrap.addView(bigDisc, new FrameLayout.LayoutParams(dp(94), dp(94), Gravity.CENTER));
        bigWrap.addView(bigIcon, new FrameLayout.LayoutParams(dp(38), dp(38), Gravity.CENTER));
        bigWrap.setClickable(true);
        bigWrap.setOnClickListener(v -> {
            bigWrap.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            onBigButton();
        });
        top.addView(bigWrap, Ui.lp(this, dp(128), dp(128), 0, 0, 8, 0));

        LinearLayout txt = Ui.vbox(this);
        LinearLayout stateRow = Ui.hrow(this);
        stateDot = Ui.dot(this, Ui.MUTED);
        stateRow.addView(stateDot, Ui.lp(this, dp(9), dp(9), 0, 0, 7, 0));
        stateText = Ui.title(this, "IDLE", 22, Ui.MUTED);
        stateRow.addView(stateText);
        txt.addView(stateRow);
        statusText = Ui.text(this, "", 12, Ui.TEXT, false);
        statusText.setMaxLines(3);
        statusText.setPadding(0, dp(4), 0, 0);
        txt.addView(statusText);
        readyText = Ui.text(this, "", 11, Ui.MUTED, false);
        readyText.setPadding(0, dp(6), 0, 0);
        readyText.setOnClickListener(v -> select(1));
        txt.addView(readyText);
        top.addView(txt, Ui.lpw(this, 1f, 0, 0, 0, 0));
        hero.addView(top);

        LinearLayout links = Ui.hrow(this);
        stopCapBtn = Ui.iconButton(this, IconView.CAPTURE, "Stop capture", false, v -> stopCapture());
        links.addView(stopCapBtn);
        links.addView(Ui.iconButton(this, IconView.SAVE, "Save trace", false, v -> {
            String err = TraceFile.save(this);
            snack(err == null ? "Saved Download/slayers_trace.csv - attach it in the chat" : err);
        }), Ui.lp(this, Ui.WRAP, Ui.WRAP, 8, 0, 0, 0));
        hero.addView(links, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));

        // ---- live card: what the bot sees, stats, accuracy chart
        LinearLayout live = Ui.panel(this);
        live.setOrientation(LinearLayout.HORIZONTAL);
        live.setMinimumHeight(dp(246));
        barView = new BarView(this);
        live.addView(barView, Ui.lp(this, dp(60), dp(222), 0, 0, 10, 0));
        LinearLayout grid = Ui.vbox(this);
        tRounds = Ui.tile(this, "ROUNDS");
        tCasts = Ui.tile(this, "CASTS");
        tTime = Ui.tile(this, "TIME");
        tLag = Ui.tile(this, "PRESS LAG");
        tTouch = Ui.tile(this, "TOUCHES ok/drop/fail");
        tReact = Ui.tile(this, "SQUARE REACTS");
        grid.addView(tilesRow(tRounds, tCasts));
        grid.addView(tilesRow(tTime, tLag));
        grid.addView(tilesRow(tTouch, tReact));
        TextView sl = Ui.text(this, "TIME INSIDE THE BOX · last 30 s", 9, Ui.MUTED, false);
        sl.setLetterSpacing(0.1f);
        grid.addView(sl, Ui.lp(this, Ui.WRAP, Ui.WRAP, 2, 0, 0, 3));
        spark = new SparkView(this);
        grid.addView(spark, Ui.lp(this, Ui.MATCH, dp(42), 0, 0, 0, 4));
        infoText = Ui.text(this, "", 9, Ui.MUTED, false);
        grid.addView(infoText, Ui.lp(this, Ui.MATCH, Ui.WRAP, 2, 0, 0, 0));
        live.addView(grid, Ui.lpw(this, 1f, 0, 0, 0, 0));

        cols.addView(hero, Ui.lpw(this, 1f, 0, 0, 8, 0));
        cols.addView(live, Ui.lpw(this, 1.3f, 0, 0, 0, 0));
        p.addView(cols);

        // ---- readiness strip
        LinearLayout strip = Ui.hrow(this);
        for (int i = 0; i < 5; i++) {
            LinearLayout item = Ui.hrow(this);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(4), dp(7), dp(4), dp(7));
            item.setBackground(Ui.shape(this, Ui.SURFACE, 12, Ui.STROKE, 1));
            IconView ic = new IconView(this, STEP_ICON[i], Ui.MUTED);
            TextView t = Ui.text(this, STEP_SHORT[i], 10, Ui.MUTED, false);
            item.addView(ic, new LinearLayout.LayoutParams(dp(14), dp(14)));
            item.addView(t, Ui.lp(this, Ui.WRAP, Ui.WRAP, 5, 0, 0, 0));
            item.setOnClickListener(v -> select(1));
            stripIcon[i] = ic;
            stripText[i] = t;
            strip.addView(item, Ui.lpw(this, 1f, i == 0 ? 0 : 6, 0, 0, 0));
        }
        p.addView(strip, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 8, 0, 0));
        p.addView(Ui.text(this, "In the game use the round floating button  ·  Volume Down stops the bot instantly.", 10, Ui.MUTED, false),
                Ui.lp(this, Ui.WRAP, Ui.WRAP, 2, 8, 0, 0));
        return p;
    }

    private LinearLayout tilesRow(Ui.Tile a, Ui.Tile b) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(a.view, Ui.lpw(this, 1f, 0, 0, 4, 5));
        row.addView(b.view, Ui.lpw(this, 1f, 4, 0, 0, 5));
        return row;
    }

    private void onBigButton() {
        if (InputService.instance == null) { snack("Turn on the Accessibility service first (Setup)"); select(1); return; }
        if (!BotState.projectionReady) { snack("Grant screen capture first (Setup)"); select(1); return; }
        boolean wasRunning = BotState.running;
        startService(new Intent(this, ProjectionService.class).setAction(ProjectionService.ACTION_TOGGLE));
        if (!wasRunning) toast("Starting in " + cfg.startDelay + "s - switch to Slayers 2 now");
    }

    // ================================================================= SETUP

    /** One checklist row: icon tile, title + hint, then status chip and action buttons on one line. */
    private LinearLayout stepRow(int idx, String title, String desc, TextView chip, View... actions) {
        LinearLayout row = Ui.card(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout tile = new FrameLayout(this);
        tile.setBackground(Ui.shape(this, Ui.SURFACE, 12, Ui.STROKE, 1));
        IconView ic = new IconView(this, STEP_ICON[idx], Ui.MUTED);
        tile.addView(ic, new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
        stepTile[idx] = tile;
        stepIcon[idx] = ic;
        row.addView(tile, Ui.lp(this, dp(36), dp(36), 0, 0, 12, 0));
        LinearLayout txt = Ui.vbox(this);
        txt.addView(Ui.text(this, title, 14, Ui.TEXT, true));
        TextView d = Ui.text(this, desc, 11, Ui.MUTED, false);
        d.setPadding(0, dp(2), 0, 0);
        txt.addView(d);
        row.addView(txt, Ui.lpw(this, 1f, 0, 0, 12, 0));
        LinearLayout right = Ui.hrow(this);
        right.addView(chip, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 0, 8, 0));
        for (int i = 0; i < actions.length; i++) right.addView(actions[i], Ui.lp(this, Ui.WRAP, Ui.WRAP, i == 0 ? 0 : 6, 0, 0, 0));
        row.addView(right);
        return row;
    }

    private View buildSetup() {
        LinearLayout p = page();
        p.addView(Ui.text(this, "Do these once. Each step turns green when it is done.", 11, Ui.MUTED, false),
                Ui.lp(this, Ui.WRAP, Ui.WRAP, 2, 0, 0, 8));

        chipAcc = Ui.chip(this); chipCap = Ui.chip(this); chipOvl = Ui.chip(this);
        chipBat = Ui.chip(this); chipNotif = Ui.chip(this);

        p.addView(stepRow(0, "Accessibility service",
                "Lets the bot press and hold for you. Greyed out? App info > ⋮ menu > Allow restricted settings.", chipAcc,
                Ui.button(this, "Open", Ui.VIOLET, v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))),
                Ui.ghostButton(this, "App info", v -> startActivity(new Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))))));
        p.addView(stepRow(1, "Screen capture",
                "Lets the bot see the fishing bar. Choose ENTIRE screen. Stop it when done: the recording indicator goes away.", chipCap,
                Ui.button(this, "Grant", Ui.VIOLET, v -> requestCapture()),
                Ui.ghostButton(this, "Stop", v -> stopCapture())));
        p.addView(stepRow(2, "Floating button",
                "The round START/STOP button over the game: allow 'display over other apps'.", chipOvl,
                Ui.button(this, "Allow", Ui.VIOLET, v -> startActivity(new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))))));
        p.addView(stepRow(3, "Background use",
                "Stops Samsung from putting the bot to sleep mid-run: set the app to Unrestricted.", chipBat,
                Ui.button(this, "Allow", Ui.VIOLET, v -> startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)))));
        p.addView(stepRow(4, "Notifications (optional)",
                "Shows STOP buttons in the notification shade too.", chipNotif,
                Ui.ghostButton(this, "Allow", v -> {
                    if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                })));
        return p;
    }

    /** Really ends screen capture: stops the bot, the projection, the floating button and the notification. */
    private void stopCapture() {
        BotState.running = false;
        stopService(new Intent(this, ProjectionService.class));
        BotState.projectionReady = false;
        BotState.status = "Screen capture stopped";
        snack("Screen capture stopped. Grant it again to fish.");
    }

    private void requestCapture() {
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent i;
        if (Build.VERSION.SDK_INT >= 34) {
            // Android 14+ lets users share "one app" only; force the entire screen so touches/coords line up.
            i = m.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay());
        } else {
            i = m.createScreenCaptureIntent();
        }
        startActivityForResult(i, CAPTURE);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == CAPTURE && res == RESULT_OK && data != null) {
            Intent s = new Intent(this, ProjectionService.class);
            s.putExtra("resultCode", res);
            s.putExtra("data", data);
            startForegroundService(s);
            snack("Screen capture starting...");
        } else if (req == CAPTURE) {
            snack("Screen capture was not granted");
        }
    }

    // ================================================================= TUNE

    private TextView muted(String s) {
        TextView t = Ui.text(this, s, 11, Ui.MUTED, false);
        t.setPadding(0, dp(2), 0, dp(6));
        return t;
    }

    /** A small card: title, hint, current value and a Pick button. */
    private LinearLayout pointPanel(String title, String hint, TextView valueView, View.OnClickListener pickListener) {
        LinearLayout p = Ui.panel(this);
        p.addView(Ui.text(this, title, 14, Ui.TEXT, true));
        p.addView(muted(hint));
        valueView.setTextColor(Ui.ACCENT);
        valueView.setTextSize(12);
        p.addView(valueView, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 0, 0, 8));
        p.addView(Ui.iconButton(this, IconView.PIN, "Pick on screen", true, pickListener), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 0));
        return p;
    }

    private View buildTune() {
        LinearLayout p = page();
        Ui.Segmented segTune = Ui.segmented(this, new String[]{"Taps", "Bar", "Timing", "Steering"}, 0, i -> showTune(i));
        p.addView(segTune.view, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        tuneSection[0] = buildTapsSection();
        tuneSection[1] = buildBarSection();
        tuneSection[2] = buildTimingSection();
        tuneSection[3] = buildSteeringSection();
        for (int i = 0; i < 4; i++) p.addView(tuneSection[i]);
        for (int i = 0; i < 4; i++) tuneSection[i].setVisibility(i == 0 ? View.VISIBLE : View.GONE);
        return p;
    }

    private void showTune(int idx) {
        for (int i = 0; i < 4; i++) if (tuneSection[i] != null) tuneSection[i].setVisibility(i == idx ? View.VISIBLE : View.GONE);
        if (tuneSection[idx] != null) Ui.reveal(this, tuneSection[idx]);
    }

    private View buildTapsSection() {
        LinearLayout s = Ui.vbox(this);
        s.addView(muted("'Pick' hides this app for 6 seconds so you can switch to the game (with the button showing), then you tap the spot."));
        castVal = Ui.text(this, "", 12, Ui.ACCENT, false);
        holdVal = Ui.text(this, "", 12, Ui.ACCENT, false);
        LinearLayout a = pointPanel("Cast button", "The hand icon near the rod.", castVal, v -> pick(
                new String[]{"Tap the hand button you press to CAST"}, (xs, ys) -> {
                    cfg.castX = (int) xs[0]; cfg.castY = (int) ys[0]; save(); syncTune();
                    toast("Cast button saved");
                }));
        LinearLayout b = pointPanel("Hold point", "An empty spot pressed in the minigame. Keep it away from buttons.", holdVal, v -> pick(
                new String[]{"Tap an EMPTY spot (not a button) where the bot will hold"}, (xs, ys) -> {
                    cfg.cx = (int) xs[0]; cfg.cy = (int) ys[0]; save(); syncTune();
                    toast("Hold point saved");
                }));
        s.addView(Ui.twoCols(this, a, b));

        LinearLayout c = Ui.card(this);
        c.addView(Ui.label(this, "Collect"));
        swCollect = Ui.toggle(this, "Collect the catch automatically", cfg.collectOn, on -> { cfg.collectOn = on; save(); });
        c.addView(swCollect);
        c.addView(muted("The Collect button is searched on the WHOLE screen (it follows the fish). The Wall-Climb button is ignored completely, and the bot never presses a spot blindly."));
        stCastPress = Ui.stepper(this, "Cast press length", 100, 3000, 100, cfg.castPress, " ms", v -> { cfg.castPress = v; save(); });
        stColHold = Ui.stepper(this, "Collect hold length", 500, 4000, 250, cfg.collectHold, " ms", v -> { cfg.collectHold = v; save(); });
        stColMax = Ui.stepper(this, "Largest collect button", 40, 100, 4, cfg.collectMaxD, " px", v -> { cfg.collectMaxD = v; save(); });
        c.addView(Ui.twoCols(this, stCastPress.view, stColHold.view));
        c.addView(Ui.twoCols(this, stColMax.view, new View(this)));
        LinearLayout teach = Ui.hrow(this);
        teach.addView(Ui.button(this, "Teach: climb button", Ui.VIOLET, v -> {
            if (!BotState.projectionReady) { snack("Grant screen capture first (Setup)"); select(1); return; }
            toast("Switch to Slayers 2 now. Learning starts in 6 seconds and takes 4 seconds.");
            moveTaskToBack(true);
            final android.content.Context app = getApplicationContext();
            ui.postDelayed(() -> app.startService(new Intent(app, ProjectionService.class).setAction(ProjectionService.ACTION_TEACH)), 6000);
        }));
        teach.addView(Ui.ghostButton(this, "Forget taught", v -> {
            startService(new Intent(this, ProjectionService.class).setAction(ProjectionService.ACTION_FORGET));
            snack("Taught buttons forgotten");
        }), Ui.lp(this, Ui.WRAP, Ui.WRAP, 8, 0, 0, 0));
        teach.addView(Ui.text(this, "optional extra safety", 11, Ui.MUTED, false), Ui.lp(this, Ui.WRAP, Ui.WRAP, 10, 0, 0, 0));
        c.addView(teach);
        s.addView(c);
        return s;
    }

    private View buildBarSection() {
        LinearLayout s = Ui.vbox(this);
        LinearLayout c = Ui.card(this);
        c.addView(Ui.label(this, "Fishing bar scan area"));
        c.addView(muted("Should cover the inside of the bar (not its outline). Defaults fit a 2400x1080 screen. The Home preview shows whether it works."));
        regionVal = Ui.text(this, "", 12, Ui.ACCENT, false);
        LinearLayout row = Ui.hrow(this);
        row.addView(regionVal, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        row.addView(Ui.iconButton(this, IconView.PIN, "Pick: tap top, then bottom", true, v -> pick(
                new String[]{"Fishing bar on screen? Tap the TOP inside the bar", "Now tap the BOTTOM inside the bar"}, (xs, ys) -> {
                    float top = Math.min(ys[0], ys[1]), bot = Math.max(ys[0], ys[1]);
                    cfg.x = (int) ((xs[0] + xs[1]) / 2f) - 30; cfg.w = 60;
                    cfg.y = (int) top - 8; cfg.h = (int) (bot - top) + 16;
                    save(); syncTune();
                    toast("Bar area saved");
                })));
        c.addView(row, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 0, 0, 8));
        stX = Ui.stepper(this, "Left edge (X)", 0, 4000, 10, cfg.x, " px", v -> { cfg.x = v; save(); });
        stY = Ui.stepper(this, "Top edge (Y)", 0, 3000, 10, cfg.y, " px", v -> { cfg.y = v; save(); });
        stW = Ui.stepper(this, "Width", 20, 400, 10, cfg.w, " px", v -> { cfg.w = v; save(); });
        stH = Ui.stepper(this, "Height", 100, 2000, 10, cfg.h, " px", v -> { cfg.h = v; save(); });
        c.addView(Ui.twoCols(this, stX.view, stY.view));
        c.addView(Ui.twoCols(this, stW.view, stH.view));
        s.addView(c);
        return s;
    }

    private View buildTimingSection() {
        LinearLayout s = Ui.vbox(this);
        LinearLayout c = Ui.card(this);
        c.addView(Ui.label(this, "Round timing"));
        stCast = Ui.stepper(this, "Extra wait after casting", 200, 3000, 100, cfg.castWait, " ms", v -> { cfg.castWait = v; save(); });
        stFail = Ui.stepper(this, "Recast if no bite after", 5, 120, 5, cfg.failWait / 1000, " s", v -> { cfg.failWait = v * 1000; save(); });
        stDelay = Ui.stepper(this, "Start delay", 0, 10, 1, cfg.startDelay, " s", v -> { cfg.startDelay = v; save(); });
        stAutoStop = Ui.stepper(this, "Auto-stop (0 = never)", 0, 240, 10, cfg.autoStopMin, " min", v -> { cfg.autoStopMin = v; save(); });
        c.addView(Ui.twoCols(this, stCast.view, stFail.view));
        c.addView(Ui.twoCols(this, stDelay.view, stAutoStop.view));
        s.addView(c);

        LinearLayout d = Ui.card(this);
        d.addView(Ui.label(this, "Presses"));
        stPress = Ui.stepper(this, "Shortest press", 30, 150, 10, cfg.pressMs, " ms", v -> { cfg.pressMs = v; save(); });
        stPressMax = Ui.stepper(this, "Longest press (hard push)", 100, 400, 10, cfg.pressMax, " ms", v -> { cfg.pressMax = v; save(); });
        stCycle = Ui.stepper(this, "Check again after", 20, 100, 5, cfg.cycle, " ms", v -> { cfg.cycle = v; save(); });
        d.addView(Ui.twoCols(this, stPress.view, stPressMax.view));
        d.addView(Ui.twoCols(this, stCycle.view, new View(this)));
        s.addView(d);
        return s;
    }

    private View buildSteeringSection() {
        LinearLayout s = Ui.vbox(this);
        LinearLayout c = Ui.card(this);
        c.addView(Ui.label(this, "Steering the square"));
        skHover = Ui.seek(this, "Hover", "Share of time pressed just to stay level", 10, 90, cfg.hoverPct, " %", v -> { cfg.hoverPct = v; save(); });
        skP = Ui.seek(this, "Response", "Higher = corrects harder when off target", 10, 100, cfg.kp10, "", v -> { cfg.kp10 = v; save(); });
        skD = Ui.seek(this, "Damping", "Higher = calms wobbling", 0, 20, cfg.kd10, "", v -> { cfg.kd10 = v; save(); });
        skI = Ui.seek(this, "Auto-balance", "Slowly learns the right hover", 0, 20, cfg.ki10, "", v -> { cfg.ki10 = v; save(); });
        c.addView(Ui.twoCols(this, skHover.view, skP.view));
        c.addView(Ui.twoCols(this, skD.view, skI.view));
        swInvert = Ui.toggle(this, "Invert: holding moves the square DOWN", cfg.invert, on -> { cfg.invert = on; save(); });
        c.addView(swInvert);
        s.addView(c);

        LinearLayout d = Ui.card(this);
        d.addView(Ui.label(this, "Press style"));
        d.addView(muted("Presses is the consistent default. Smooth keeps one finger down (experimental, falls back by itself). Auto tries both and keeps the better one."));
        segStyle = Ui.segmented(this, new String[]{"Auto", "Presses", "Smooth"}, cfg.style, i -> { cfg.style = i; save(); });
        d.addView(segStyle.view, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0, 0, 0, 8));
        LinearLayout row = Ui.hrow(this);
        row.addView(Ui.ghostButton(this, "Forget what Auto learned", v -> {
            android.content.SharedPreferences.Editor ed = getSharedPreferences("bot", MODE_PRIVATE).edit();
            for (int i = 0; i < 3; i++) ed.remove("as" + i).remove("at" + i);
            ed.apply();
            snack("Learning reset. It restarts on the next run.");
        }));
        row.addView(Ui.button(this, "Reset everything to defaults", Ui.RED, v -> {
            ConfigStore.reset(this);
            cfg = ConfigStore.load(this);
            syncTune();
            snack("Defaults restored");
        }), Ui.lp(this, Ui.WRAP, Ui.WRAP, 8, 0, 0, 0));
        d.addView(row);
        s.addView(d);
        return s;
    }

    private void syncTune() {
        if (castVal == null || stX == null || skI == null || stCycle == null || stPress == null || stPressMax == null || stColMax == null
                || stAutoStop == null || segStyle == null || stCastPress == null || stColHold == null) return;
        castVal.setText("x " + cfg.castX + "    y " + cfg.castY);
        holdVal.setText("x " + cfg.cx + "    y " + cfg.cy);
        regionVal.setText("x " + cfg.x + "   y " + cfg.y + "   w " + cfg.w + "   h " + cfg.h);
        swCollect.setChecked(cfg.collectOn);
        stX.set(cfg.x); stY.set(cfg.y); stW.set(cfg.w); stH.set(cfg.h);
        stCast.set(cfg.castWait); stFail.set(cfg.failWait / 1000); stDelay.set(cfg.startDelay);
        stCastPress.set(cfg.castPress); stColHold.set(cfg.collectHold); stCycle.set(cfg.cycle); stPress.set(cfg.pressMs);
        stPressMax.set(cfg.pressMax); stColMax.set(cfg.collectMaxD); stAutoStop.set(cfg.autoStopMin);
        segStyle.paint(cfg.style);
        skHover.set(cfg.hoverPct); skP.set(cfg.kp10); skD.set(cfg.kd10); skI.set(cfg.ki10);
        swInvert.setChecked(cfg.invert);
    }

    private void pick(final String[] prompts, final Picker.Done done) {
        if (!Settings.canDrawOverlays(this)) {
            snack("Allow the floating button first (Setup, step 3)");
            select(1);
            return;
        }
        toast("Switch to Slayers 2 now. The picker opens in 6 seconds.");
        moveTaskToBack(true);
        final android.content.Context app = getApplicationContext();
        ui.postDelayed(() -> Picker.start(app, prompts, done), 6000);
    }

    // ================================================================= live refresh + animation

    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            updateUi();
            ui.postDelayed(this, 200);
        }
    };

    /** 20 fps: pulsing glow while running, and the rolling accuracy chart. */
    private final Runnable anim = new Runnable() {
        @Override public void run() {
            long t = System.currentTimeMillis();
            boolean run = BotState.running;
            float pulse = (float) (0.5 + 0.5 * Math.sin(t / 420.0));
            if (bigGlow != null) {
                bigGlow.setAlpha(run ? 0.55f + 0.45f * pulse : 0.5f);
                float sc = run ? 1f + 0.07f * pulse : 1f;
                bigGlow.setScaleX(sc);
                bigGlow.setScaleY(sc);
            }
            if (stateDot != null) stateDot.setAlpha(run ? 0.45f + 0.55f * pulse : 1f);
            if (headerDot != null) headerDot.setAlpha(run ? 0.45f + 0.55f * pulse : 1f);
            boolean seen = t - BotState.lastSeen < 400;
            if (seen) {
                sparkSeen++;
                if (Math.abs(BotState.indicatorY - BotState.targetY) < BotState.targetH / 2) sparkIn++;
            }
            if (spark != null && t - lastSpark >= 250) {
                lastSpark = t;
                spark.push(sparkSeen == 0 ? -1f : sparkIn / (float) sparkSeen);
                sparkIn = 0;
                sparkSeen = 0;
            }
            ui.postDelayed(this, 50);
        }
    };

    private void setStep(int i, boolean ok) {
        if (stepState[i] == (ok ? 1 : 0)) return;
        stepState[i] = ok ? 1 : 0;
        stepIcon[i].setColor(ok ? Ui.GOOD : Ui.MUTED);
        stepTile[i].setBackground(Ui.shape(this, ok ? 0xFF0F3D2B : Ui.SURFACE, 12, ok ? Ui.GOOD : Ui.STROKE, 1));
    }

    private void updateUi() {
        boolean acc = InputService.instance != null;
        boolean cap = BotState.projectionReady;
        boolean ovl = Settings.canDrawOverlays(this);
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        boolean bat = pm.isIgnoringBatteryOptimizations(getPackageName());
        boolean notif = Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;

        Ui.setChip(this, chipAcc, acc, "Connected", "Off");
        Ui.setChip(this, chipCap, cap, "Ready", "Off");
        Ui.setChip(this, chipOvl, ovl, "Allowed", "Not allowed");
        Ui.setChip(this, chipBat, bat, "Unrestricted", "Restricted");
        Ui.setChip(this, chipNotif, notif, "Allowed", "Off");
        final boolean[] oks = {acc, cap, ovl, bat, notif};
        for (int i = 0; i < 5; i++) {
            setStep(i, oks[i]);
            int col = oks[i] ? Ui.GOOD : (i == 4 ? Ui.MUTED : Ui.BAD);
            stripIcon[i].setColor(col);
            Ui.setColor(stripText[i], col);
        }

        boolean run = BotState.running;
        Ui.setText(stateText, run ? "RUNNING" : "IDLE");
        Ui.setColor(stateText, run ? Ui.GOOD : Ui.MUTED);
        Ui.setText(statusText, BotState.status);
        if (!shownInit || run != shownRunning) {
            shownInit = true;
            shownRunning = run;
            stateDot.setBackground(Ui.disc(run ? Ui.GOOD : Ui.MUTED));
            headerDot.setBackground(Ui.disc(run ? Ui.GOOD : Ui.MUTED));
            headerChip.setText(run ? "RUNNING" : "IDLE");
            headerChip.setTextColor(run ? Ui.GOOD : Ui.MUTED);
            headerChipBox.setBackground(Ui.shape(this, run ? 0xFF0F3D2B : Ui.CARD2, 14, run ? Ui.GOOD : Ui.STROKE, 1));
            bigDisc.setBackground(run ? Ui.discGradient(0xFFFB7185, 0xFFE11D48) : Ui.discGradient(0xFF22C55E, 0xFF059669));
            bigGlow.setBackground(Ui.disc(run ? 0x55FB7185 : 0x5522C55E));
            bigIcon.setIcon(run ? IconView.STOP : IconView.PLAY);
        }
        long secs = run ? Math.max(0, (System.currentTimeMillis() - BotState.startedAt) / 1000) : 0;
        Ui.setText(tRounds.value, String.valueOf(BotState.rounds));
        Ui.setText(tCasts.value, String.valueOf(BotState.casts));
        Ui.setText(tTime.value, Fmt.pad2(Fmt.pad2(new StringBuilder(5), secs / 60).append(':'), secs % 60));
        Ui.setText(tLag.value, "~" + BotState.pressLagMs + " ms");
        Ui.setText(tTouch.value, BotState.gOk + " / " + BotState.gCancel + " / " + BotState.gFail);
        Ui.setText(tReact.value, BotState.response > 0 ? "✓ yes" : (BotState.response < 0 ? "✗ NO" : "-"));
        Ui.setColor(tReact.value, BotState.response > 0 ? Ui.GOOD : (BotState.response < 0 ? Ui.BAD : Ui.TEXT));
        Ui.setText(infoText, "Style " + BotState.styleInfo + "  ·  taught climb buttons: " + BotState.taughtN);

        stopCapBtn.setVisibility(cap ? View.VISIBLE : View.GONE);
        boolean ready = acc && cap && ovl;
        Ui.setText(readyText, ready ? "✓ Ready - open Slayers 2 and tap the floating button, or press the big button."
                : "Setup not finished - tap here ▶");
        Ui.setColor(readyText, ready ? Ui.GOOD : Ui.WARN);
        barView.setRegion(cfg.y, cfg.h);
        barView.invalidate();
    }
}
