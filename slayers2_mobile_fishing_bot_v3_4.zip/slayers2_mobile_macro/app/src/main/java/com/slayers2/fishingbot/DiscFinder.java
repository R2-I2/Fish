package com.slayers2.fishingbot;

import java.nio.ByteBuffer;

/**
 * Finds the round "prompt" buttons: a bright disc with a black finger. The COLLECT button and the WALL-CLIMB button both
 * look like this; they differ in size (collect 30-68 px, climb ~90 px), in the label (the climb label has a tall icon)
 * and the climb button is already there BEFORE the bite.
 */
final class DiscFinder {
    /** Rows (screen px, tuned on 2400x1080) that are searched: the menu/compass row at the top and the hotbar at the bottom are skipped. */
    static final int HUD_TOP = 170, HUD_BOTTOM = 950;
    private static final int STEP = 2;          // the search runs on every 2nd pixel
    private static final int MAX_DISCS = 16;

    // result of the last scan()
    final int[] x = new int[MAX_DISCS], y = new int[MAX_DISCS], d = new int[MAX_DISCS];
    int n = 0;

    private byte[] cmask, ctmp;
    private int[] cstack;
    private byte[] lmask;
    private int[] lstack;

    // result of the last pickCollect()
    int pickX, pickY, pickD;

    /** 3x3 opening (erode then dilate): removes thin strokes such as the letters of a name tag that touch the disc. */
    private void open3(byte[] m, int w, int h) {
        if (ctmp == null || ctmp.length != m.length) ctmp = new byte[m.length];
        for (int yy = 0; yy < h; yy++) for (int xx = 0; xx < w; xx++) {
            int i = yy * w + xx;
            ctmp[i] = (byte) ((xx > 0 && xx < w - 1 && m[i - 1] == 1 && m[i] == 1 && m[i + 1] == 1) ? 1 : 0);
        }
        for (int yy = 0; yy < h; yy++) for (int xx = 0; xx < w; xx++) {
            int i = yy * w + xx;
            m[i] = (byte) ((yy > 0 && yy < h - 1 && ctmp[i - w] == 1 && ctmp[i] == 1 && ctmp[i + w] == 1) ? 1 : 0);
        }
        for (int yy = 0; yy < h; yy++) for (int xx = 0; xx < w; xx++) {
            int i = yy * w + xx;
            ctmp[i] = (byte) ((m[i] == 1 || (xx > 0 && m[i - 1] == 1) || (xx < w - 1 && m[i + 1] == 1)) ? 1 : 0);
        }
        for (int yy = 0; yy < h; yy++) for (int xx = 0; xx < w; xx++) {
            int i = yy * w + xx;
            m[i] = (byte) ((ctmp[i] == 1 || (yy > 0 && ctmp[i - w] == 1) || (yy < h - 1 && ctmp[i + w] == 1)) ? 1 : 0);
        }
    }

    /** Fills x/y/d/n with every bright disc that has a black finger inside (diameter 24-100 px) anywhere on the screen. */
    int scan(Frame f) {
        final ByteBuffer buf = f.buf;
        final int rs = f.rs, ps = f.ps;
        n = 0;
        final int x0 = 0, x1 = f.w;
        final int y0 = HUD_TOP, y1 = Math.min(f.h, HUD_BOTTOM);
        final int w = (x1 - x0) / STEP, h = (y1 - y0) / STEP;
        if (w <= 2 || h <= 2) return 0;
        if (cmask == null || cmask.length != w * h) { cmask = new byte[w * h]; cstack = new int[w * h]; }
        for (int yy = 0; yy < h; yy++) {
            int base = (y0 + yy * STEP) * rs;
            for (int xx = 0; xx < w; xx++) {
                int o = base + (x0 + xx * STEP) * ps;
                boolean white = (buf.get(o) & 0xFF) > 215 && (buf.get(o + 1) & 0xFF) > 215 && (buf.get(o + 2) & 0xFF) > 215;
                cmask[yy * w + xx] = (byte) (white ? 1 : 0);
            }
        }
        open3(cmask, w, h);
        final int minD = Math.max(8, 24 / STEP), maxD = 100 / STEP;
        for (int start = 0; start < w * h; start++) {
            if (cmask[start] != 1) continue;
            int sp = 0, area = 0;
            int minX = w, maxX = 0, minY = h, maxY = 0;
            cstack[sp++] = start;
            cmask[start] = 2;
            while (sp > 0) {
                int p = cstack[--sp];
                int px = p % w, py = p / w;
                area++;
                if (px < minX) minX = px;
                if (px > maxX) maxX = px;
                if (py < minY) minY = py;
                if (py > maxY) maxY = py;
                if (px > 0 && cmask[p - 1] == 1) { cmask[p - 1] = 2; cstack[sp++] = p - 1; }
                if (px < w - 1 && cmask[p + 1] == 1) { cmask[p + 1] = 2; cstack[sp++] = p + 1; }
                if (py > 0 && cmask[p - w] == 1) { cmask[p - w] = 2; cstack[sp++] = p - w; }
                if (py < h - 1 && cmask[p + w] == 1) { cmask[p + w] = 2; cstack[sp++] = p + w; }
            }
            int bw = maxX - minX + 1, bh = maxY - minY + 1;
            if (bw < minD || bw > maxD || bh < minD || bh > maxD) continue;
            double ratio = bw / (double) bh;
            if (ratio < 0.82 || ratio > 1.22) continue;
            double fill = area / (double) (bw * bh);
            if (fill < 0.40 || fill > 0.90) continue;                              // a disc with a hole (the finger)
            int dark = 0, tot = 0;                                                  // the black finger in the middle
            for (int yy = minY + bh / 4; yy <= maxY - bh / 4; yy++) {
                int base = (y0 + yy * STEP) * rs;
                for (int xx = minX + bw / 4; xx <= maxX - bw / 4; xx++) {
                    int o = base + (x0 + xx * STEP) * ps;
                    int mxv = Math.max(buf.get(o) & 0xFF, Math.max(buf.get(o + 1) & 0xFF, buf.get(o + 2) & 0xFF));
                    tot++;
                    if (mxv < 110) dark++;
                }
            }
            if (tot == 0 || dark / (double) tot < 0.15) continue;                   // the cast hand has ~9%, a finger 20-40%
            // a real prompt disc has a closed white rim all the way round (clothing flowers, letters and glare do not)
            final double ccx = (minX + maxX) / 2.0, ccy = (minY + maxY) / 2.0, rad = Math.min(bw, bh) / 2.0;
            int ringOk = 0;
            for (int q = 0; q < 16; q++) {
                double ang = q * Math.PI / 8;
                int sx = (int) Math.round(ccx + Math.cos(ang) * rad * 0.78), sy = (int) Math.round(ccy + Math.sin(ang) * rad * 0.78);
                sx = Math.max(0, Math.min(w - 1, sx));
                sy = Math.max(0, Math.min(h - 1, sy));
                int o = (y0 + sy * STEP) * rs + (x0 + sx * STEP) * ps;
                if ((buf.get(o) & 0xFF) > 205 && (buf.get(o + 1) & 0xFF) > 205 && (buf.get(o + 2) & 0xFF) > 205) ringOk++;
            }
            if (ringOk < 13) continue;
            // ...and a dark label pill right next to it (both the collect and the climb prompt have one)
            final int fxp = x0 + (int) ccx * STEP, fyp = y0 + (int) ccy * STEP, dpx = Math.max(bw, bh) * STEP;
            int pd = 0, pt = 0;
            for (int yy = fyp - (int) (0.3 * dpx); yy <= fyp + (int) (0.3 * dpx); yy += 3) {
                if (yy < 0 || yy >= f.h) continue;
                for (int xx = fxp + (int) (0.9 * dpx); xx <= fxp + (int) (2.0 * dpx); xx += 3) {
                    if (xx < 0 || xx >= f.w) continue;
                    int o = yy * rs + xx * ps;
                    int mxv = Math.max(buf.get(o) & 0xFF, Math.max(buf.get(o + 1) & 0xFF, buf.get(o + 2) & 0xFF));
                    pt++;
                    if (mxv < 100) pd++;
                }
            }
            if (pt == 0 || pd / (double) pt < 0.30) continue;
            if (n < MAX_DISCS) {
                x[n] = x0 + ((minX + maxX) / 2) * STEP;
                y[n] = y0 + ((minY + maxY) / 2) * STEP;
                d[n] = Math.max(bw, bh) * STEP;
                n++;
            }
        }
        return n;
    }

    /**
     * Height of the tallest white shape in the label next to the disc, as a multiple of the disc diameter.
     * The climb label has a tall rope/figure icon (0.67-0.70), collect labels only letters (0.34-0.41).
     */
    double tallestBlobRatio(Frame f, int fx, int fy, int dia) {
        final ByteBuffer buf = f.buf;
        final int rs = f.rs, ps = f.ps;
        final int xa = Math.max(0, fx + (int) (0.95 * dia)), xb = Math.min(f.w, fx + (int) (3.3 * dia));
        final int ya = Math.max(0, fy - (int) (0.62 * dia)), yb = Math.min(f.h, fy + (int) (0.62 * dia));
        final int w = xb - xa, h = yb - ya;
        if (w < 8 || h < 8 || w * h > 40000) return 0;
        if (lmask == null) { lmask = new byte[40000]; lstack = new int[40000]; }
        for (int yy = 0; yy < h; yy++) {
            int base = (ya + yy) * rs;
            for (int xx = 0; xx < w; xx++) {
                int o = base + (xa + xx) * ps;
                boolean white = (buf.get(o) & 0xFF) > 200 && (buf.get(o + 1) & 0xFF) > 200 && (buf.get(o + 2) & 0xFF) > 200;
                lmask[yy * w + xx] = (byte) (white ? 1 : 0);
            }
        }
        int bestH = 0;
        final int minArea = Math.max(4, (int) (0.02 * dia * dia));
        for (int start = 0; start < w * h; start++) {
            if (lmask[start] != 1) continue;
            int sp = 0, area = 0, minY = h, maxY = 0;
            lstack[sp++] = start;
            lmask[start] = 2;
            while (sp > 0) {
                int p = lstack[--sp];
                int px = p % w, py = p / w;
                area++;
                if (py < minY) minY = py;
                if (py > maxY) maxY = py;
                if (px > 0 && lmask[p - 1] == 1) { lmask[p - 1] = 2; lstack[sp++] = p - 1; }
                if (px < w - 1 && lmask[p + 1] == 1) { lmask[p + 1] = 2; lstack[sp++] = p + 1; }
                if (py > 0 && lmask[p - w] == 1) { lmask[p - w] = 2; lstack[sp++] = p - w; }
                if (py < h - 1 && lmask[p + w] == 1) { lmask[p + w] = 2; lstack[sp++] = p + w; }
            }
            if (area >= minArea) bestH = Math.max(bestH, maxY - minY + 1);
        }
        return bestH / (double) dia;
    }

    /**
     * Picks the collect button among the discs of the last scan(): not bigger than maxD, not a known button (climb etc.),
     * no climb icon in the label. When the previous pick (refX, refY) is recent the closest disc to it is followed,
     * otherwise the smallest one. Returns false when nothing qualifies; otherwise pickX/pickY/pickD are set.
     * With log = true every candidate and its verdict goes to the Trace (K lines).
     */
    boolean pickCollect(Frame f, int maxD, KnownButtons known, long now, boolean haveLast, int refX, int refY, boolean log) {
        int bestX = -1, bestY = -1, bestD = 0;
        double bestScore = Double.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            int status = 0;                                          // 0 usable, 1 too big, 2 known earlier (climb etc.), 3 label has the climb icon
            if (d[i] > maxD) status = 1;
            else if (known.isKnown(x[i], y[i], d[i], now)) status = 2;
            else if (tallestBlobRatio(f, x[i], y[i], d[i]) >= 0.60) status = 3;
            if (log) Trace.add("K", x[i], y[i], d[i], status);
            if (status != 0) continue;
            double score = haveLast ? Math.hypot(x[i] - refX, y[i] - refY) : d[i];   // follow the same button; first time the smallest
            if (score < bestScore) { bestScore = score; bestX = x[i]; bestY = y[i]; bestD = d[i]; }
        }
        if (bestX < 0) return false;
        pickX = bestX; pickY = bestY; pickD = bestD;
        return true;
    }
}
