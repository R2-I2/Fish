package com.slayers2.fishingbot;

/** What the bot needs from the touch injector (InputService on the phone, a fake in tests). */
interface Pressor {
    /** One press of ms milliseconds; returns when the phone has finished it. True if it completed. */
    boolean pressAndWait(int x, int y, long ms);

    /** Fire-and-forget press (cast button). */
    boolean hold(int x, int y, long ms);

    /** Smooth-hold driver: keep one touch down while wantDown is true. */
    void setHold(int x, int y, boolean wantDown);

    /** Lift the finger if it is down. */
    void release();
}
