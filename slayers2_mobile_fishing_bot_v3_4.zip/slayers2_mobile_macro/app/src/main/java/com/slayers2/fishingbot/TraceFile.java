package com.slayers2.fishingbot;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import java.io.OutputStream;

/** Saves the Trace log to Download/slayers_trace.csv. */
final class TraceFile {
    private TraceFile() {}

    /** Returns null when saved, otherwise a short error text. */
    static String save(Context ctx) {
        String text = Trace.snapshot();
        if (Build.VERSION.SDK_INT < 29) return "Saving needs Android 10 or newer";
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, "slayers_trace.csv");
            v.put(MediaStore.Downloads.MIME_TYPE, "text/csv");
            v.put(MediaStore.Downloads.RELATIVE_PATH, "Download");
            Uri uri = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return "Could not create the file";
            OutputStream os = ctx.getContentResolver().openOutputStream(uri);
            if (os == null) return "Could not open the file";
            try {
                os.write(text.getBytes("UTF-8"));
            } finally {
                os.close();
            }
            return null;
        } catch (Throwable t) {
            return "Save failed: " + t.getClass().getSimpleName();
        }
    }
}
