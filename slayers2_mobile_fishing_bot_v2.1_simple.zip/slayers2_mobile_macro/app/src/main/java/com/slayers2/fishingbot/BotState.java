package com.slayers2.fishingbot;

/** Shared live state (activity, capture service and worker all run in one process). */
public final class BotState {
    public static volatile boolean running = false;
    public static volatile boolean projectionReady = false;
    public static volatile double indicatorY = -1;   // white square, screen px
    public static volatile double targetY = -1;      // centre of green box, screen px
    public static volatile double targetH = 0;       // height of green box, screen px
    public static volatile long lastSeen = 0;        // last time both were detected
    public static volatile String status = "Stopped";
    public static volatile String note = "";        // short text shown on the floating button
    public static volatile int driverFails = 0;        // smooth-hold problems (>= 6 -> falls back to plain pulses)
    public static volatile int rounds = 0;             // minigames played this run
    public static volatile long startedAt = 0;
    public static volatile int gOk = 0, gCancel = 0, gFail = 0;   // gesture results (diagnostics)

    private BotState() {}
}
