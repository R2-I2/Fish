plugins {
    id("com.android.application")
}

android {
    namespace = "com.slayers2.fishingbot"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.slayers2.fishingbot"
        minSdk = 26
        targetSdk = 34
        versionCode = 14
        versionName = "2.3"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
// No third-party dependencies on purpose: fewer things to break the build.
