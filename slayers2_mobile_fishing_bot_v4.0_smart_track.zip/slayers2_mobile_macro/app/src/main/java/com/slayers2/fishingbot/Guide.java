package com.slayers2.fishingbot;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;

/** Static in-app guide. Written from community guides (Sept 2026); details can change with game updates. */
final class Guide {
    private Guide() {}

    static View build(Context c) {
        LinearLayout p = new LinearLayout(c);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(Ui.dp(c, 14), Ui.dp(c, 6), Ui.dp(c, 14), Ui.dp(c, 14));
        p.addView(Ui.text(c, "📖  Fishing guide", 22, Ui.TEXT, true));
        p.addView(Ui.text(c, "Slayers 2 - from community guides, Sept 2026. Patches may change details.", 12, Ui.MUTED, false));

        card(c, p, "🎣  How a catch works", new String[]{
            "Get a Fishing Permit from the Dock Master at Mistfall Harbor (a short quest, fee about 5,000 Wen), then buy the Basic Fishing Rod (about 3,500 Wen).",
            "Put the rod in your hotbar and equip it. If you hold a katana, you swing it instead of casting.",
            "Stand at the pier edge or on crates by the water and press the hand-icon button near the rod to cast.",
            "Wait a while for a bite. The minigame starts on its own.",
            "Keep the white square inside the box with short presses: holding lifts the square, releasing lets it drop. The box is yellow while the square is outside it and turns green while the square is inside. Fill the meter to 100%.",
            "To collect, hold the white finger circle next to the catch name for 1 to 2 seconds (PC: press T). A finished minigame can still end with no fish."
        });

        card(c, p, "🤖  What the bot does", new String[]{
            "Presses the Cast button (the hand icon), then waits for a bite.",
            "Reads the bar (yellow OR green box, white square) about 20 times a second and keeps one finger on the Hold point: held down while the square is below the box, released when it is above, and quick taps to hover.",
            "When the minigame ends it holds the Collect button for about 2 seconds, then casts again. If nothing bites for the 'Recast' time, it casts again.",
            "Everything happens on your phone. The app has no internet permission."
        });

        card(c, p, "✅  Best setup", new String[]{
            "Rod equipped, standing still at the pier edge, phone in landscape.",
            "Run Setup until all four items are green, then use the floating button over the game.",
            "Check the Home preview: a yellow box and a white square must appear while a bar is on screen. 'no bar' means the scan region needs adjusting (Tune > Pick bar).",
            "Square runs the wrong way? Turn on Invert. It wobbles? Lower Response or raise Damping. It sinks while 'level'? Raise Hover.",
            "Long-press the floating START (idle) to test-hold the Hold point for 2 seconds. STOP with a tap or Volume Down."
        });

        card(c, p, "🎒  Rods, bait & loot", new String[]{
            "Three rods: Basic, Rare and Legendary. Basic comes from the shop after the permit quest.",
            "The Legendary route reportedly starts with the Drowned Lure from a hidden fishing spot (one guide says the fifth catch there), then a ghost fisherman's clue, then luck.",
            "Fishing pays out crafting materials (for example Mythical Ores, Metal Scraps, Silk Threads) and fish used in quests such as the Soryu chain. It is also listed as a source of a shotgun schematic."
        });

        card(c, p, "⚠  Safety & rules", new String[]{
            "This app only looks at a small strip of your screen and sends touches. It never stores or sends anything.",
            "Automating gameplay may break the game's or Roblox's rules and can get an account suspended. Use at your own risk."
        });

        card(c, p, "🔗  Sources", new String[]{
            "roblox-slayers2.wiki fishing guide (updated Sept 20, 2026)",
            "allthings.how: Project Slayers 2 fishing rod & minigame guide",
            "nerdschalk.com: Fishing Permit quest guide",
            "games.gg and slayers2game.wiki fishing guides",
            "itemlevel.net: Legendary rod & infinite bait guide"
        });
        return p;
    }

    private static void card(Context c, LinearLayout parent, String title, String[] lines) {
        LinearLayout card = Ui.card(c);
        card.addView(Ui.text(c, title, 16, Ui.ACCENT, true));
        for (int i = 0; i < lines.length; i++) {
            android.widget.TextView t = Ui.text(c, "•  " + lines[i], 13, Ui.TEXT, false);
            t.setPadding(0, Ui.dp(c, 6), 0, 0);
            card.addView(t);
        }
        parent.addView(card);
    }
}
