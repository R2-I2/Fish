package com.slayers2.fishingbot;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int CAPTURE = 44;
    private static final String[] TAB_ICON = {"🏠", "🔧", "🎚", "📖"};
    private static final String[] TAB_NAME = {"Home", "Setup", "Advanced", "Guide"};

    private Config cfg;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final View[] tabs = new View[4];
    private final TextView[] rail = new TextView[4];

    // Home
    private TextView stateText, statusText, statsText, readyText;
    private Button bigBtn;
    private BarView barView;
    private boolean shownRunning = false;

    // Setup
    private TextView chipAcc, chipCap, chipOvl, chipBat, chipNotif;

    // Tune
    private TextView castVal, holdVal, colVal, regionVal;
    private Switch swCollect, swInvert, swSmooth;
    private Ui.Stepper stX, stY, stW, stH, stCast, stFail, stDelay, stCastPress, stColHold, stCycle, stLead, stDeadband;
    private Ui.SeekRow skHover, skP, skD, skI;

    private int dp(float v) { return Ui.dp(this, v); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private void save() { Config.save(this, cfg); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = Config.load(this);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(dp(6), dp(6), dp(6), dp(6));

        LinearLayout railBox = new LinearLayout(this);
        railBox.setOrientation(LinearLayout.VERTICAL);
        railBox.setGravity(Gravity.CENTER_HORIZONTAL);
        railBox.setPadding(dp(4), dp(8), dp(4), dp(8));
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView t = Ui.text(this, TAB_ICON[i] + "\n" + TAB_NAME[i], 12, Ui.MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(4), dp(10), dp(4), dp(10));
            t.setOnClickListener(v -> select(idx));
            rail[i] = t;
            railBox.addView(t, Ui.lp(this, dp(76), Ui.WRAP, 0, 0, 0, 6));
        }
        root.addView(railBox, new LinearLayout.LayoutParams(dp(88), Ui.MATCH));

        FrameLayout content = new FrameLayout(this);
        tabs[0] = scroll(buildHome());
        tabs[1] = scroll(buildSetup());
        tabs[2] = scroll(buildTune());
        tabs[3] = scroll(Guide.build(this));
        for (int i = 0; i < 4; i++) content.addView(tabs[i], new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        root.addView(content, new LinearLayout.LayoutParams(0, Ui.MATCH, 1f));
        setContentView(root);

        syncTune();
        select(0);
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        cfg = Config.load(this);
        syncTune();
        ui.post(refresh);
    }

    @Override protected void onPause() {
        ui.removeCallbacks(refresh);
        super.onPause();
    }

    private ScrollView scroll(View inner) {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(inner);
        return sv;
    }

    private LinearLayout page() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(6), dp(14), dp(14));
        return l;
    }

    private void select(int idx) {
        for (int i = 0; i < 4; i++) {
            tabs[i].setVisibility(i == idx ? View.VISIBLE : View.GONE);
            rail[i].setBackground(i == idx ? Ui.round(this, Ui.CARD2, 14) : null);
            rail[i].setTextColor(i == idx ? Ui.ACCENT : Ui.MUTED);
        }
    }

    // ================================================================= HOME

    private View buildHome() {
        LinearLayout p = page();
        p.addView(Ui.text(this, "🎣  Slayers 2 Fishing Bot", 22, Ui.TEXT, true));
        p.addView(Ui.text(this, "Simple mode • v2.1", 12, Ui.MUTED, false));

        LinearLayout card = Ui.card(this);
        LinearLayout row = Ui.hrow(this);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        stateText = Ui.text(this, "IDLE", 26, Ui.MUTED, true);
        statusText = Ui.text(this, "", 15, Ui.TEXT, false);
        statsText = Ui.text(this, "", 12, Ui.MUTED, false);
        statsText.setPadding(0, dp(6), 0, 0);
        left.addView(stateText);
        left.addView(statusText);
        left.addView(statsText);
        row.addView(left, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        barView = new BarView(this);
        row.addView(barView, new LinearLayout.LayoutParams(dp(64), dp(150)));
        card.addView(row);
        p.addView(card);

        bigBtn = Ui.button(this, "▶  START", Ui.GREEN_BTN, v -> onBigButton());
        bigBtn.setTextSize(18);
        p.addView(bigBtn, Ui.lp(this, Ui.MATCH, dp(58), 0, 12, 0, 0));

        Button quick = Ui.button(this, "⚡  Quick setup", Ui.VIOLET, v -> select(1));
        p.addView(quick, Ui.lp(this, Ui.MATCH, dp(48), 0, 8, 0, 0));

        readyText = Ui.text(this, "", 13, Ui.MUTED, false);
        readyText.setPadding(0, dp(10), 0, 0);
        readyText.setOnClickListener(v -> select(1));
        p.addView(readyText);
        p.addView(Ui.text(this, "In the game, use the round floating button. Volume Down stops the bot instantly.",
                12, Ui.MUTED, false));
        return p;
    }

    private void onBigButton() {
        if (BotState.running) {
            startService(new Intent(this, ProjectionService.class).setAction(ProjectionService.ACTION_TOGGLE));
            return;
        }
        if (InputService.instance == null) {
            toast("First turn on Accessibility in Setup. That's required for touch control.");
            select(1);
            return;
        }
        if (!BotState.projectionReady) {
            toast("One more step: allow screen capture.");
            requestCapture();
            return;
        }
        startService(new Intent(this, ProjectionService.class).setAction(ProjectionService.ACTION_TOGGLE));
        toast("Starting in " + cfg.startDelay + "s — switch to Slayers 2.");
    }

    // ================================================================= SETUP

    private LinearLayout header(String title, TextView chip) {
        LinearLayout h = Ui.hrow(this);
        h.addView(Ui.text(this, title, 16, Ui.TEXT, true), new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        h.addView(chip);
        return h;
    }

    private TextView muted(String s) {
        TextView t = Ui.text(this, s, 12, Ui.MUTED, false);
        t.setPadding(0, dp(4), 0, dp(8));
        return t;
    }

    private View buildSetup() {
        LinearLayout p = page();
        p.addView(Ui.text(this, "🔧  Setup", 22, Ui.TEXT, true));
        p.addView(Ui.text(this, "Only the first two are required. The rest are optional conveniences.", 12, Ui.MUTED, false));

        chipAcc = Ui.chip(this); chipCap = Ui.chip(this); chipOvl = Ui.chip(this);
        chipBat = Ui.chip(this); chipNotif = Ui.chip(this);

        LinearLayout quickCard = Ui.card(this);
        quickCard.addView(Ui.text(this, "Recommended settings", 16, Ui.ACCENT, true));
        quickCard.addView(muted("You normally do not need to tune anything. Restore the tested defaults with one tap."));
        quickCard.addView(Ui.button(this, "✓  Use recommended settings", Ui.CARD2, v -> {
            Config.reset(this);
            cfg = Config.load(this);
            syncTune();
            toast("Recommended settings restored");
        }));
        p.addView(quickCard);

        LinearLayout c1 = Ui.card(this);
        c1.addView(header("1  Accessibility service", chipAcc));
        c1.addView(muted("Lets the bot press and hold for you. If the switch is greyed out: App info > ⋮ menu > Allow restricted settings, then try again."));
        LinearLayout r1 = Ui.hrow(this);
        r1.addView(Ui.button(this, "Open Accessibility", Ui.VIOLET,
                v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        r1.addView(Ui.button(this, "App info", Ui.CARD2, v -> startActivity(new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())))),
                Ui.lp(this, Ui.WRAP, Ui.WRAP, 8, 0, 0, 0));
        c1.addView(r1);
        p.addView(c1);

        LinearLayout c2 = Ui.card(this);
        c2.addView(header("2  Screen capture", chipCap));
        c2.addView(muted("Lets the bot see the fishing bar. Choose ENTIRE screen when asked. Needs redoing after the bot is shut down."));
        c2.addView(Ui.button(this, "Grant screen capture", Ui.VIOLET, v -> requestCapture()));
        p.addView(c2);

        LinearLayout c3 = Ui.card(this);
        c3.addView(header("3  Floating button (optional)", chipOvl));
        c3.addView(muted("Useful if you want to start/stop the bot while Slayers 2 is open. You can also control it from this app or the notification."));
        c3.addView(Ui.button(this, "Allow floating button", Ui.VIOLET, v -> startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())))));
        p.addView(c3);

        LinearLayout c4 = Ui.card(this);
        c4.addView(header("4  Battery protection (optional)", chipBat));
        c4.addView(muted("Recommended for long sessions, but the bot can run without changing this."));
        c4.addView(Ui.button(this, "Allow background use", Ui.VIOLET,
                v -> startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))));
        p.addView(c4);

        LinearLayout c5 = Ui.card(this);
        c5.addView(header("5  Notifications (optional)", chipNotif));
        c5.addView(muted("Shows the STOP button in the notification shade too."));
        c5.addView(Ui.button(this, "Allow notifications", Ui.CARD2, v -> {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            }
        }));
        p.addView(c5);
        return p;
    }

    private void requestCapture() {
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent i;
        if (Build.VERSION.SDK_INT >= 34) {
            // Android 14+ lets users share "one app" only; force the entire screen so touches/coords line up.
            i = m.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay());
        } else {
            i = m.createScreenCaptureIntent();
        }
        startActivityForResult(i, CAPTURE);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == CAPTURE && res == RESULT_OK && data != null) {
            Intent s = new Intent(this, ProjectionService.class);
            s.putExtra("resultCode", res);
            s.putExtra("data", data);
            startForegroundService(s);
            toast("Screen capture starting...");
        } else if (req == CAPTURE) {
            toast("Screen capture was not granted");
        }
    }

    // ================================================================= TUNE

    private LinearLayout pointRow(String label, TextView valueView, View.OnClickListener pickListener) {
        LinearLayout r = Ui.hrow(this);
        r.setPadding(0, dp(6), 0, dp(6));
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.addView(Ui.text(this, label, 14, Ui.TEXT, false));
        t.addView(valueView);
        r.addView(t, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        r.addView(Ui.button(this, "📍 Pick", Ui.VIOLET, pickListener));
        return r;
    }

    private View buildTune() {
        LinearLayout p = page();
        p.addView(Ui.text(this, "🎯  Advanced", 22, Ui.TEXT, true));
        p.addView(Ui.text(this, "Most settings are automatic. Only change these if your screen layout differs.", 12, Ui.MUTED, false));

        // ---- taps
        LinearLayout c1 = Ui.card(this);
        c1.addView(Ui.text(this, "Where the bot taps", 16, Ui.ACCENT, true));
        c1.addView(muted("'Pick' hides this app for 6 seconds so you can switch to the game (with the hand button showing), then tap the spot."));
        castVal = Ui.text(this, "", 12, Ui.MUTED, false);
        holdVal = Ui.text(this, "", 12, Ui.MUTED, false);
        colVal = Ui.text(this, "", 12, Ui.MUTED, false);
        c1.addView(pointRow("Cast button - the hand icon near the rod", castVal, v -> pick(
                new String[]{"Tap the hand button you press to CAST"}, (xs, ys) -> {
                    cfg.castX = (int) xs[0]; cfg.castY = (int) ys[0]; save(); syncTune();
                    toast("Cast button saved");
                })));
        stCastPress = Ui.stepper(this, "Cast press length", 100, 3000, 100, cfg.castPress, " ms", v -> { cfg.castPress = v; save(); });
        c1.addView(stCastPress.view);
        c1.addView(pointRow("Hold point - press & hold here in the minigame", holdVal, v -> pick(
                new String[]{"Tap an EMPTY spot (not a button) where the bot will hold"}, (xs, ys) -> {
                    cfg.cx = (int) xs[0]; cfg.cy = (int) ys[0]; save(); syncTune();
                    toast("Hold point saved");
                })));
        swCollect = Ui.toggle(this, "Hold the Collect button after each catch", cfg.collectOn, on -> { cfg.collectOn = on; save(); });
        c1.addView(swCollect);
        c1.addView(pointRow("Collect button - the white circle with a finger", colVal, v -> pick(
                new String[]{"Tap the white hand circle that appears to COLLECT a catch"}, (xs, ys) -> {
                    cfg.colX = (int) xs[0]; cfg.colY = (int) ys[0]; cfg.collectOn = true; save(); syncTune();
                    toast("Collect button saved");
                })));
        stColHold = Ui.stepper(this, "Collect hold length", 500, 4000, 250, cfg.collectHold, " ms", v -> { cfg.collectHold = v; save(); });
        c1.addView(stColHold.view);
        p.addView(c1);

        // ---- bar region
        LinearLayout c2 = Ui.card(this);
        c2.addView(Ui.text(this, "Fishing bar scan area", 16, Ui.ACCENT, true));
        c2.addView(muted("Should cover the inside of the bar (not its outline). Defaults fit a 2400x1080 screen. The Home preview shows if it works."));
        regionVal = Ui.text(this, "", 12, Ui.MUTED, false);
        c2.addView(pointRow("Bar area - tap TOP then BOTTOM inside the bar", regionVal, v -> pick(
                new String[]{"Fishing bar on screen? Tap the TOP inside the bar", "Now tap the BOTTOM inside the bar"}, (xs, ys) -> {
                    float top = Math.min(ys[0], ys[1]), bot = Math.max(ys[0], ys[1]);
                    cfg.x = (int) ((xs[0] + xs[1]) / 2f) - 30; cfg.w = 60;
                    cfg.y = (int) top - 8; cfg.h = (int) (bot - top) + 16;
                    save(); syncTune();
                    toast("Bar area saved");
                })));
        stX = Ui.stepper(this, "Left edge (X)", 0, 4000, 10, cfg.x, " px", v -> { cfg.x = v; save(); });
        stY = Ui.stepper(this, "Top edge (Y)", 0, 3000, 10, cfg.y, " px", v -> { cfg.y = v; save(); });
        stW = Ui.stepper(this, "Width", 20, 400, 10, cfg.w, " px", v -> { cfg.w = v; save(); });
        stH = Ui.stepper(this, "Height", 100, 2000, 10, cfg.h, " px", v -> { cfg.h = v; save(); });
        c2.addView(stX.view); c2.addView(stY.view); c2.addView(stW.view); c2.addView(stH.view);
        p.addView(c2);

        // ---- timing
        LinearLayout c3 = Ui.card(this);
        c3.addView(Ui.text(this, "Timing", 16, Ui.ACCENT, true));
        stCast = Ui.stepper(this, "Extra wait after casting", 200, 3000, 100, cfg.castWait, " ms", v -> { cfg.castWait = v; save(); });
        stFail = Ui.stepper(this, "Recast if no bite after", 5, 120, 5, cfg.failWait / 1000, " s", v -> { cfg.failWait = v * 1000; save(); });
        stDelay = Ui.stepper(this, "Start delay", 0, 10, 1, cfg.startDelay, " s", v -> { cfg.startDelay = v; save(); });
        stCycle = Ui.stepper(this, "React every (lower = faster)", 30, 400, 10, cfg.cycle, " ms", v -> { cfg.cycle = v; save(); });
        c3.addView(stCast.view); c3.addView(stFail.view); c3.addView(stDelay.view); c3.addView(stCycle.view);
        p.addView(c3);

        // ---- steering
        LinearLayout c4 = Ui.card(this);
        c4.addView(Ui.text(this, "Smart Steering", 16, Ui.ACCENT, true));
        c4.addView(muted("Automatic edge-aware tracking. The bot uses the white square height, target edges, motion and a small prediction window; normal use does not require tuning these values."));
        skHover = Ui.seek(this, "Hover", "How long to press just to stay level", 10, 90, cfg.hoverPct, " %", v -> { cfg.hoverPct = v; save(); });
        skP = Ui.seek(this, "Response", "Higher = corrects harder when off target", 10, 100, cfg.kp10, "", v -> { cfg.kp10 = v; save(); });
        skD = Ui.seek(this, "Damping", "Higher = calms wobbling", 0, 20, cfg.kd10, "", v -> { cfg.kd10 = v; save(); });
        skI = Ui.seek(this, "Auto-balance", "Slowly learns the right hover", 0, 20, cfg.ki10, "", v -> { cfg.ki10 = v; save(); });
        // v4 deliberately hides the old PID-style controls. They belonged to the previous
        // controller and made setup look harder than it needs to be. The adaptive tracker
        // now chooses its response from geometry + velocity automatically.
        skHover.view.setVisibility(View.GONE);
        skP.view.setVisibility(View.GONE);
        skD.view.setVisibility(View.GONE);
        skI.view.setVisibility(View.GONE);
        stLead = Ui.stepper(this, "Prediction", 0, 30, 5, cfg.leadMs, " ms", v -> { cfg.leadMs = v; save(); });
        stDeadband = Ui.stepper(this, "Safety zone", 4, 18, 1, cfg.deadbandPct, " % of target", v -> { cfg.deadbandPct = v; save(); });
        c4.addView(stLead.view); c4.addView(stDeadband.view);
        swInvert = Ui.toggle(this, "Control direction (automatic)", false, on -> { cfg.invert = false; save(); });
        swInvert.setVisibility(View.GONE);
        swSmooth = Ui.toggle(this, "Smooth touch (recommended)", cfg.smooth, on -> { cfg.smooth = on; save(); });
        c4.addView(swSmooth);
        p.addView(c4);

        p.addView(Ui.button(this, "Reset everything to defaults", Ui.RED, v -> {
            Config.reset(this);
            cfg = Config.load(this);
            syncTune();
            toast("Defaults restored");
        }), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0, 12, 0, 0));
        return p;
    }

    private void syncTune() {
        if (castVal == null || stX == null || skI == null || stCycle == null || swSmooth == null || stCastPress == null || stColHold == null || stLead == null || stDeadband == null) return;
        castVal.setText("x " + cfg.castX + "    y " + cfg.castY);
        holdVal.setText("x " + cfg.cx + "    y " + cfg.cy);
        colVal.setText("x " + cfg.colX + "    y " + cfg.colY);
        regionVal.setText("x " + cfg.x + "  y " + cfg.y + "  w " + cfg.w + "  h " + cfg.h);
        swCollect.setChecked(cfg.collectOn);
        stX.set(cfg.x); stY.set(cfg.y); stW.set(cfg.w); stH.set(cfg.h);
        stCast.set(cfg.castWait); stFail.set(cfg.failWait / 1000); stDelay.set(cfg.startDelay);
        stCastPress.set(cfg.castPress); stColHold.set(cfg.collectHold); stCycle.set(cfg.cycle);
        stLead.set(cfg.leadMs); stDeadband.set(cfg.deadbandPct);
        swSmooth.setChecked(cfg.smooth);
        skHover.set(cfg.hoverPct); skP.set(cfg.kp10); skD.set(cfg.kd10); skI.set(cfg.ki10);
        swInvert.setChecked(cfg.invert);
    }

    private void pick(final String[] prompts, final Picker.Done done) {
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow the floating button first (Setup, step 3)");
            select(1);
            return;
        }
        toast("Switch to Slayers 2 now. The picker opens in 6 seconds.");
        moveTaskToBack(true);
        final android.content.Context app = getApplicationContext();
        ui.postDelayed(() -> Picker.start(app, prompts, done), 6000);
    }

    // ================================================================= live refresh

    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            updateUi();
            ui.postDelayed(this, 200);
        }
    };

    private void updateUi() {
        boolean acc = InputService.instance != null;
        boolean cap = BotState.projectionReady;
        boolean ovl = Settings.canDrawOverlays(this);
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        boolean bat = pm.isIgnoringBatteryOptimizations(getPackageName());
        boolean notif = Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;

        Ui.setChip(this, chipAcc, acc, "Connected", "Off");
        Ui.setChip(this, chipCap, cap, "Ready", "Not granted");
        Ui.setChip(this, chipOvl, ovl, "Allowed", "Not allowed");
        Ui.setChip(this, chipBat, bat, "Unrestricted", "Restricted");
        Ui.setChip(this, chipNotif, notif, "Allowed", "Off");

        boolean run = BotState.running;
        stateText.setText(run ? "RUNNING" : "IDLE");
        stateText.setTextColor(run ? Ui.GOOD : Ui.MUTED);
        statusText.setText(BotState.status);
        long secs = run ? Math.max(0, (System.currentTimeMillis() - BotState.startedAt) / 1000) : 0;
        statsText.setText(String.format(Locale.US, "Rounds %d   •   %02d:%02d",
                BotState.rounds, secs / 60, secs % 60));
        if (run != shownRunning || bigBtn.getText().length() == 0) {
            shownRunning = run;
            bigBtn.setText(run ? "■  STOP" : "▶  START");
            bigBtn.setBackground(Ui.round(this, run ? Ui.RED : Ui.GREEN_BTN, 14));
        }
        boolean ready = acc && cap;
        readyText.setText(ready ? "✓ Ready. Open Slayers 2 and press START. Floating button is optional."
                : (!acc ? "Setup needed: turn on Accessibility ▶" : "Setup needed: allow screen capture ▶"));
        readyText.setTextColor(ready ? Ui.GOOD : Ui.WARN);
        barView.setRegion(cfg.y, cfg.h);
        barView.invalidate();
    }
}
