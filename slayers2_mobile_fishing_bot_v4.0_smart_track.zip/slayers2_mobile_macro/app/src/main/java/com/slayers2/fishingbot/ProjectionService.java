package com.slayers2.fishingbot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spannable;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.nio.ByteBuffer;
import java.util.Locale;

public class ProjectionService extends Service {
    public static final String ACTION_TOGGLE = "com.slayers2.fishingbot.TOGGLE";
    private static final String CHANNEL = "s2bot";
    private static final int NOTIF_ID = 9;
    private static final int DIV = 2;              // capture at 1/2 resolution (faster), coords scaled back

    private static final int CASTING = 0, WAITING = 1, PLAYING = 2, FINISHING = 3;

    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay vdisplay;
    private HandlerThread captureThread;
    private Thread worker;
    private volatile boolean alive = true;
    private MediaProjection.Callback projectionCallback;

    // floating START/STOP button
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView overlay;
    private boolean lastShownRunning = false;

    private int cw, ch;
    private volatile Config cfg;
    private volatile long startAt = 0;

    // worker-thread state
    private int state = CASTING;
    private long lastCast = 0, lastActive = 0, lastIndTime = 0;
    private double lastInd = -1, lastTgt = -1, indVel = 0, tgtVel = 0, vel = 0, integ = 0, acc = 0;
    private int detectMisses = 0;

    @Override public void onCreate() {
        super.onCreate();
        cfg = Config.load(this);
    }

    @Override public int onStartCommand(Intent in, int flags, int id) {
        if (in != null && ACTION_TOGGLE.equals(in.getAction())) {
            toggle();
            return START_NOT_STICKY;
        }
        startForegroundCompat();
        if (in != null && in.hasExtra("data")) {
            int rc = in.getIntExtra("resultCode", 0);
            Intent data = getData(in);
            startCapture(rc, data);
        }
        return START_NOT_STICKY;
    }

    @SuppressWarnings("deprecation")
    private Intent getData(Intent in) {
        if (Build.VERSION.SDK_INT >= 33) return in.getParcelableExtra("data", Intent.class);
        return in.getParcelableExtra("data");
    }

    // ---------------------------------------------------------------- capture

    private void startCapture(int rc, Intent data) {
        releaseCapture();
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = m.getMediaProjection(rc, data);
        if (projection == null) { BotState.status = "Screen capture was denied"; return; }

        Point real = Config.realSize(this);
        cw = Math.max(2, real.x / DIV);
        ch = Math.max(2, real.y / DIV);
        cfg = Config.load(this);

        captureThread = new HandlerThread("s2-capture");
        captureThread.start();
        Handler handler = new Handler(captureThread.getLooper());

        // Android 14+ requires a callback to be registered BEFORE creating the virtual display.
        projectionCallback = new MediaProjection.Callback() {
            @Override public void onStop() {
                if (!alive) return;
                BotState.running = false;
                BotState.projectionReady = false;
                BotState.status = "Screen capture stopped";
                stopSelf();
            }
        };
        projection.registerCallback(projectionCallback, handler);

        reader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2);
        int dpi = getResources().getDisplayMetrics().densityDpi;
        vdisplay = projection.createVirtualDisplay("S2FishingCapture", cw, ch, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        reader.setOnImageAvailableListener(r -> {
            Image im = null;
            try {
                im = r.acquireLatestImage();
                if (im != null) process(im);
            } catch (Throwable t) {
                BotState.status = "Capture error: " + t.getClass().getSimpleName();
            } finally {
                if (im != null) im.close();
            }
        }, handler);

        BotState.projectionReady = true;
        BotState.status = "Ready";
        if (worker == null || !worker.isAlive()) {
            worker = new Thread(this::loop, "s2-bot");
            worker.start();
        }
        updateNotification();
        ui.removeCallbacks(tick);
        ui.post(tick);
    }

    private void releaseCapture() {
        BotState.projectionReady = false;
        try { if (reader != null) reader.close(); } catch (Throwable ignored) {}
        try { if (vdisplay != null) vdisplay.release(); } catch (Throwable ignored) {}
        try { if (projection != null && projectionCallback != null) projection.unregisterCallback(projectionCallback); } catch (Throwable ignored) {}
        try { if (projection != null) projection.stop(); } catch (Throwable ignored) {}
        try { if (captureThread != null) captureThread.quitSafely(); } catch (Throwable ignored) {}
        reader = null; vdisplay = null; projection = null; captureThread = null;
    }

    /**
     * Finds the white square (indicator) and the yellow-green box (target) inside the scan region.
     * Reads the raw frame buffer directly; no bitmap allocation.
     * Colours were checked against a real screenshot: white square ~ (196,197,199),
     * green box edge ~ (143,171,11), track background ~ (12,27,46).
     */
    /**
     * v3 vision pipeline.
     *
     * The minigame is a vertical control problem: a bright white indicator must stay
     * inside the moving green/yellow target.  We deliberately detect the two objects
     * independently and use their edges, not just their centres.
     *
     * This is tolerant of the target changing between green/yellow and of the white
     * indicator partially covering the target.
     */
    private void process(Image im) {
        Config c = cfg;
        Image.Plane pl = im.getPlanes()[0];
        ByteBuffer buf = pl.getBuffer();
        int rs = pl.getRowStride(), ps = pl.getPixelStride();

        int x0 = Math.max(0, c.x / DIV), x1 = Math.min(cw, (c.x + c.w) / DIV);
        int y0 = Math.max(0, c.y / DIV), y1 = Math.min(ch, (c.y + c.h) / DIV);
        if (x1 - x0 < 8 || y1 - y0 < 20) return;

        final int rw = x1 - x0;
        final int rows = y1 - y0;
        final int whiteNeed = Math.max(3, (int)(rw * 0.18));
        final int targetNeed = Math.max(2, (int)(rw * 0.14));
        int[] white = new int[rows];
        int[] target = new int[rows];

        for (int yy = y0; yy < y1; yy++) {
            int i = yy - y0, wc = 0, tc = 0;
            int base = yy * rs;
            for (int xx = x0; xx < x1; xx++) {
                int o = base + xx * ps;
                int r = buf.get(o) & 0xFF;
                int g = buf.get(o + 1) & 0xFF;
                int b = buf.get(o + 2) & 0xFF;
                int mx = Math.max(r, Math.max(g, b));
                int mn = Math.min(r, Math.min(g, b));
                int spread = mx - mn;

                // White indicator: bright and comparatively desaturated.
                if (mx >= 175 && mn >= 125 && spread <= 82) wc++;

                // Target: accept both the yellow and green phases seen in current guides.
                // The saturation/luminance tests reject the dark blue bar background.
                boolean yellow = r >= 95 && g >= 82 && b <= 145 && r > b + 28 && g > b + 12;
                boolean green = g >= 88 && g > r + 10 && g > b + 10 && spread >= 28;
                if ((yellow || green) && mx >= 110) tc++;
            }
            white[i] = wc;
            target[i] = tc;
        }

        // Build vertical components while allowing gaps from anti-aliasing or the white
        // indicator crossing the target.  We keep candidate bounds rather than taking the
        // first/last matching row, which was the source of many false target sizes.
        int gapLimit = Math.max(4, Math.min(14, rows / 18));
        int[][] wcands = components(white, whiteNeed, gapLimit);
        int[][] tcands = components(target, targetNeed, gapLimit);

        int[] w = chooseComponent(wcands, lastInd < 0 ? -1 : (int)(lastInd / DIV - y0));
        int[] t = chooseComponent(tcands, lastTgt < 0 ? -1 : (int)(lastTgt / DIV - y0));

        if (w != null && t != null) {
            double rawInd = (y0 + (w[0] + w[1]) / 2.0) * DIV;
            double rawIndH = Math.max(8, (w[1] - w[0] + 1) * (double)DIV);
            double rawTgt = (y0 + (t[0] + t[1]) / 2.0) * DIV;
            double rawTgtH = Math.max(12, (t[1] - t[0] + 1) * (double)DIV);

            // Reject impossible jumps, but permit a fast-moving target to travel farther
            // than the indicator between frames.
            boolean plausibleIndicator = lastInd < 0 || Math.abs(rawInd - lastInd) <= Math.max(110, c.h * 0.42);
            boolean plausibleTarget = lastTgt < 0 || Math.abs(rawTgt - lastTgt) <= Math.max(180, c.h * 0.70);
            if (plausibleIndicator && plausibleTarget) {
                long now = System.currentTimeMillis();
                double alpha = 0.62;
                double ind = lastInd < 0 ? rawInd : lastInd * (1 - alpha) + rawInd * alpha;
                double tgt = lastTgt < 0 ? rawTgt : lastTgt * (1 - alpha) + rawTgt * alpha;

                if (lastInd >= 0 && now > lastIndTime) {
                    double dt = (now - lastIndTime) / 1000.0;
                    if (dt >= 0.008 && dt <= 0.30) {
                        double iv = (ind - lastInd) / dt;
                        double tv = (tgt - lastTgt) / dt;
                        indVel = indVel * 0.68 + iv * 0.32;
                        tgtVel = tgtVel * 0.68 + tv * 0.32;
                        vel = vel * 0.70 + ((ind - tgt) - (lastInd - lastTgt)) / dt * 0.30;
                    }
                }

                lastInd = ind;
                lastTgt = tgt;
                lastIndTime = now;
                BotState.indicatorY = ind;
                BotState.indicatorH = rawIndH;
                BotState.targetY = tgt;
                BotState.targetH = rawTgtH;
                // Confidence rewards strong, reasonably sized components and a stable frame.
                double ws = Math.min(1.0, (w[1] - w[0] + 1) / 4.0);
                double ts = Math.min(1.0, (t[1] - t[0] + 1) / 8.0);
                BotState.confidence = Math.min(1.0, 0.45 + 0.25 * ws + 0.30 * ts);
                BotState.lastSeen = now;
                detectMisses = 0;
            }
        } else if (++detectMisses > 5) {
            BotState.confidence *= 0.65;
            BotState.lastSeen = Math.min(BotState.lastSeen, System.currentTimeMillis() - 350);
        }
    }

    /** Return [start,end] components from a row-score array. */
    private int[][] components(int[] score, int threshold, int gapLimit) {
        java.util.ArrayList<int[]> out = new java.util.ArrayList<>();
        int start = -1, lastGood = -1, gap = 0;
        for (int i = 0; i < score.length; i++) {
            if (score[i] >= threshold) {
                if (start < 0) start = i;
                lastGood = i;
                gap = 0;
            } else if (start >= 0) {
                if (++gap > gapLimit) {
                    if (lastGood >= start) out.add(new int[]{start, lastGood});
                    start = -1; lastGood = -1; gap = 0;
                }
            }
        }
        if (start >= 0 && lastGood >= start) out.add(new int[]{start, lastGood});
        return out.toArray(new int[out.size()][]);
    }

    /** Prefer the candidate nearest the previous position; otherwise prefer the largest. */
    private int[] chooseComponent(int[][] candidates, int previousRow) {
        if (candidates == null || candidates.length == 0) return null;
        int[] best = null;
        double bestScore = -1e9;
        for (int[] q : candidates) {
            int len = q[1] - q[0] + 1;
            int center = (q[0] + q[1]) / 2;
            double score = len * 2.0;
            if (previousRow >= 0) score -= Math.abs(center - previousRow) * 1.7;
            if (best == null || score > bestScore) { best = q; bestScore = score; }
        }
        return best;
    }

    // ---------------------------------------------------------------- bot loop

    private void toggle() {
        if (!BotState.projectionReady) {
            BotState.status = "Grant screen capture first";
            return;
        }
        if (BotState.running) {
            BotState.running = false;
            BotState.status = "Stopped";
            BotState.note = "";
        } else {
            if (InputService.instance == null) {
                BotState.status = "Enable the Accessibility service first";
                BotState.note = "ACCESS OFF";
                ui.postDelayed(() -> BotState.note = "", 3500);
                return;
            }
            BotState.gOk = 0; BotState.gCancel = 0; BotState.gFail = 0;
            BotState.rounds = 0; BotState.startedAt = System.currentTimeMillis();
            cfg = Config.load(this);
            state = CASTING; lastCast = 0; lastInd = -1; lastTgt = -1; indVel = 0; tgtVel = 0; vel = 0; integ = 0; acc = 0; detectMisses = 0; BotState.indicatorH = 0; BotState.confidence = 0;
            BotState.driverFails = 0;
            startAt = System.currentTimeMillis() + cfg.startDelay * 1000L;
            BotState.running = true;
            BotState.status = "Starting...";
        }
        updateNotification();
    }

    private void loop() {
        while (alive) {
            try {
                if (!BotState.running) {
                    InputService rin = InputService.instance;
                    if (rin != null) rin.release();
                    sleep(100);
                    continue;
                }
                InputService in = InputService.instance;
                if (in == null) { BotState.status = "Enable the Accessibility service"; BotState.note = "ACCESS OFF"; sleep(500); continue; }
                long now = System.currentTimeMillis();
                if (now < startAt) {
                    BotState.status = "Starting in " + ((startAt - now) / 1000 + 1) + "s - switch to the game";
                    BotState.note = "get ready";
                    sleep(150);
                    continue;
                }
                Config c = cfg;

                if (now - BotState.lastSeen < 300) {           // minigame on screen
                    state = PLAYING;
                    lastActive = now;
                    control(in, c);
                    continue;
                }
                lastInd = -1; lastTgt = -1; indVel = 0; tgtVel = 0; vel = 0; integ = 0; acc = 0; detectMisses = 0; BotState.indicatorH = 0; BotState.confidence = 0;
                in.release();

                switch (state) {
                    case PLAYING:
                        if (now - lastActive > 800) { state = FINISHING; BotState.rounds++; } else sleep(25);
                        break;
                    case FINISHING:
                        BotState.status = "Collecting";
                        BotState.note = "collecting";
                        if (c.collectOn) {
                            in.hold(c.colX, c.colY, c.collectHold);   // the collect prompt must be HELD for 1-2 s
                            sleep(c.collectHold + 400);
                        } else {
                            sleep(500);
                        }
                        state = CASTING;
                        break;
                    case CASTING:
                        BotState.status = "Casting";
                        BotState.note = "casting";
                        in.hold(c.castX, c.castY, c.castPress);   // press the hand-icon cast button
                        sleep(c.castPress + c.castWait);
                        lastCast = System.currentTimeMillis();
                        state = WAITING;
                        break;
                    default: // WAITING
                        BotState.status = "Waiting for a bite";
                        BotState.note = "no bar yet";
                        if (now - lastCast > c.failWait) state = CASTING; else sleep(30);
                }
            } catch (Throwable t) {
                BotState.status = "Error: " + t.getClass().getSimpleName();
                sleep(500);
            }
        }
    }

    /**
     * PD(+I) controller. The result is a "duty": the share of time the finger should be down.
     * Smooth mode turns it into press/release decisions every tick (sigma-delta) and lets InputService keep one touch
     * down between presses. If the phone rejects that, it falls back to one plain press per cycle.
     */
    /**
     * v3 controller: keep the whole white indicator inside the moving target.
     *
     * Slayers 2's documented control is direct: HOLD raises the white indicator and
     * RELEASE lets it fall. We therefore do not use an arbitrary baseline duty cycle.
     * The controller is edge-aware, has hysteresis, and only predicts a small amount
     * so a falling target cannot make the indicator overshoot.
     */
    /**
     * v4 adaptive controller.
     *
     * The game is a one-dimensional spring-like control problem:
     * HOLD -> the white indicator rises; RELEASE -> it falls.
     * We control against the target's edges and estimated velocity instead of
     * repeatedly chasing the target centre.  The controller deliberately brakes
     * early when the indicator is moving quickly, which reduces the classic
     * downward-target overshoot.
     */
    private void control(InputService in, Config c) {
        if (BotState.indicatorY < 0 || BotState.targetY < 0 || BotState.confidence < 0.25) {
            in.release();
            sleep(Math.max(25, c.cycle));
            return;
        }

        final int tick = Math.max(25, Math.min(70, c.cycle));
        final double ih = Math.max(8.0, BotState.indicatorH);
        final double th = Math.max(12.0, BotState.targetH);

        // Screen Y increases downward. Positive indicator velocity therefore means
        // the white marker is falling; negative means it is rising.
        final double iv = indVel;
        final double tv = tgtVel;

        // A very small prediction compensates for capture + accessibility latency.
        // It is deliberately capped: prediction is useful, but excessive prediction
        // was the main source of the old v2.x overshoot.
        final double lead = Math.max(0.0, Math.min(0.030, c.leadMs / 1000.0));
        final double predictedIndicator = BotState.indicatorY + iv * lead;
        final double predictedTarget = BotState.targetY + tv * lead;

        final double targetTop = predictedTarget - th / 2.0;
        final double targetBottom = predictedTarget + th / 2.0;
        final double indicatorTop = predictedIndicator - ih / 2.0;
        final double indicatorBottom = predictedIndicator + ih / 2.0;

        // Keep a safety band inside the target.  The margin grows with target size,
        // but never consumes most of a small target.
        final double margin = Math.max(3.0, Math.min(12.0,
                th * Math.max(0.05, Math.min(0.18, c.deadbandPct / 100.0))));
        final double safeTop = targetTop + margin;
        final double safeBottom = targetBottom - margin;

        // Positive error = indicator is below target centre and needs to rise.
        final double error = predictedIndicator - predictedTarget;
        final double halfSafe = Math.max(3.0, (th - ih) * 0.34);

        boolean hold;
        boolean lastHold = acc > 0.5;

        // First priority: if the whole indicator is outside the safe region, recover.
        if (indicatorTop > safeBottom) {
            hold = true;                  // clearly too low -> rise
        } else if (indicatorBottom < safeTop) {
            hold = false;                 // clearly too high -> fall
        } else {
            // Inside/overlapping the safe region: use momentum-aware braking.
            // If rising quickly, release BEFORE reaching the centre so momentum can
            // carry the marker into the target rather than through it.
            double brakeDistance = Math.max(4.0, Math.abs(Math.min(0.0, iv)) * 0.060);
            double riseBrakeLine = predictedTarget - Math.min(halfSafe, brakeDistance + margin);

            if (iv < -35.0 && predictedIndicator <= riseBrakeLine) {
                hold = false;             // rising too fast: brake early
            } else if (Math.abs(error) <= halfSafe) {
                // In the middle: keep the previous command only when it is helping
                // rather than creating a new excursion. Default is release because
                // a released marker naturally falls and is easier to recover upward.
                hold = lastHold && error > margin && iv > -25.0;
            } else if (error > 0) {
                // Below target: rise, but don't keep rising if momentum is already strong.
                hold = !(iv < -55.0 && error < th * 0.35);
            } else {
                hold = false;             // above target -> fall
            }
        }

        // Moving-target correction.  These are intentionally conservative: they only
        // override the decision when the target is moving fast enough to invalidate
        // the current edge test.
        if (tv > 100.0 && predictedTarget > BotState.targetY) {
            // Target is falling. If the marker is already above its lower half, release
            // so it can follow downward instead of chasing the old target position.
            if (predictedIndicator < predictedTarget + th * 0.20) hold = false;
        } else if (tv < -100.0 && predictedTarget < BotState.targetY) {
            // Target is rising. Hold only when the marker is genuinely below it.
            if (predictedIndicator > predictedTarget - th * 0.15) hold = true;
        }

        // If detection is stable but the target is very narrow, favour short, cautious
        // corrections.  This prevents rapid oscillation on small targets.
        if (th < ih * 1.45 && Math.abs(error) < th * 0.45) {
            if (Math.abs(iv) > 45.0) hold = iv > 0;
        }

        acc = hold ? 1.0 : -1.0;

        BotState.status = String.format(Locale.US,
                "Adaptive track  %.0f%%  %s", BotState.confidence * 100.0,
                hold ? "HOLD ↑" : "RELEASE ↓");
        BotState.note = String.format(Locale.US,
                "err %+.0f • %+.0f px/s", error, iv);

        // HOLD always means upward movement in Slayers 2. There is deliberately no
        // inversion option in the normal path.
        if (c.smooth && BotState.driverFails < 6) {
            in.setHold(c.cx, c.cy, hold);
        } else if (hold) {
            in.hold(c.cx, c.cy, Math.max(45, tick));
        } else {
            in.release();
        }
        sleep(tick);
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    // ---------------------------------------------------------------- floating button

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!alive) return;
            try {
                cfg = Config.load(ProjectionService.this);   // pick up Tune-tab changes live
                ensureOverlay();
                refreshOverlay();
                if (BotState.running != lastShownRunning) {
                    lastShownRunning = BotState.running;
                    updateNotification();
                }
            } catch (Throwable ignored) {}
            ui.postDelayed(this, 300);
        }
    };

    /**
     * Small draggable START/STOP bubble over the game. While the bot runs, its own gestures can cancel a
     * finger that is still down, so STOP fires on touch-DOWN (not on release).
     */
    private void ensureOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return;
        final WindowManager wm = getSystemService(WindowManager.class);
        final float d = getResources().getDisplayMetrics().density;
        final int size = (int) (58 * d);
        final TextView t = new TextView(this);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setMinWidth(size);
        t.setMinHeight(size);
        t.setPadding((int) (10 * d), (int) (6 * d), (int) (10 * d), (int) (6 * d));
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        final SharedPreferences sp = getSharedPreferences("bot", MODE_PRIVATE);
        Point real = Config.realSize(this);
        lp.x = sp.getInt("ox", (int) (8 * d));
        lp.y = sp.getInt("oy", real.y / 2 - size / 2);

        t.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean handled, dragging;
            final Runnable longPress = new Runnable() {
                @Override public void run() {
                    if (dragging || handled || BotState.running) return;
                    handled = true;
                    InputService in = InputService.instance;
                    Config c = cfg;
                    if (in == null) { BotState.note = "ACCESS OFF"; return; }
                    in.hold(c.cx, c.cy, 2000);            // test: does the game react to an injected hold?
                    BotState.note = "test hold 2s";
                    ui.postDelayed(() -> BotState.note = "", 2400);
                }
            };

            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = lp.x; startY = lp.y;
                        dragging = false; handled = false;
                        if (BotState.running) { handled = true; toggle(); refreshOverlay(); }
                        else ui.postDelayed(longPress, 700);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (handled) return true;
                        float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                        if (!dragging && Math.hypot(dx, dy) > 12 * d) { dragging = true; ui.removeCallbacks(longPress); }
                        if (dragging) {
                            lp.x = startX + (int) dx;
                            lp.y = startY + (int) dy;
                            wm.updateViewLayout(v, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ui.removeCallbacks(longPress);
                        if (handled) return true;
                        if (dragging) sp.edit().putInt("ox", lp.x).putInt("oy", lp.y).apply();
                        else { toggle(); refreshOverlay(); }
                        return true;
                    default:
                        ui.removeCallbacks(longPress);
                        return true;
                }
            }
        });

        try {
            wm.addView(t, lp);
            overlay = t;
            refreshOverlay();
        } catch (Throwable ex) {
            BotState.status = "Floating button error: " + ex.getClass().getSimpleName();
        }
    }

    private void refreshOverlay() {
        if (overlay == null) return;
        boolean on = BotState.running;
        long now = System.currentTimeMillis();
        String label = !on ? "START" : (now < startAt ? String.valueOf((startAt - now) / 1000 + 1) : "STOP");
        String note = BotState.note == null ? "" : BotState.note;
        if (note.isEmpty()) {
            overlay.setText(label);
        } else {
            SpannableString sp = new SpannableString(label + "\n" + note);
            sp.setSpan(new RelativeSizeSpan(0.7f), label.length() + 1, sp.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            overlay.setText(sp);
        }
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(29 * getResources().getDisplayMetrics().density);
        bg.setColor(on ? 0xCCC62828 : 0xCC2E7D32);
        overlay.setBackground(bg);
    }

    private void removeOverlay() {
        try {
            if (overlay != null) getSystemService(WindowManager.class).removeView(overlay);
        } catch (Throwable ignored) {}
        overlay = null;
    }

    // ---------------------------------------------------------------- notification

    private void startForegroundCompat() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Fishing Bot", NotificationManager.IMPORTANCE_LOW));
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private Notification buildNotification() {
        Intent t = new Intent(this, ProjectionService.class).setAction(ACTION_TOGGLE);
        PendingIntent toggle = PendingIntent.getService(this, 1, t,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this, 2, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean on = BotState.running;
        Notification.Action a = new Notification.Action.Builder(
                Icon.createWithResource(this, on ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play),
                on ? "STOP bot" : "START bot", toggle).build();
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Slayers 2 Fishing Bot")
                .setContentText(on ? "Running" : "Idle - tap START when the game is open")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .setContentIntent(open)
                .addAction(a)
                .build();
    }

    private void updateNotification() {
        getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification());
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onDestroy() {
        alive = false;
        BotState.running = false;
        InputService rin = InputService.instance;
        if (rin != null) rin.release();
        ui.removeCallbacks(tick);
        removeOverlay();
        releaseCapture();
        if (worker != null) worker.interrupt();
        super.onDestroy();
    }
}
