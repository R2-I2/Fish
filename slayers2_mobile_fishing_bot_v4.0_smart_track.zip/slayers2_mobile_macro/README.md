# Slayers 2 Fishing Bot — v4.0 Smart Track

Android screen-reading + Accessibility automation for the Slayers 2 fishing minigame. The project does not read Roblox memory or inject into the game.

## What v4.0 changes

- **Adaptive edge tracking:** controls against the white indicator and the target's actual top/bottom edges, not only their centers.
- **Momentum-aware braking:** estimates indicator velocity and releases early when the marker is rising quickly, reducing overshoot.
- **Moving-target handling:** follows a target that changes direction without blindly chasing its previous position.
- **Conservative prediction:** only 0–30 ms of prediction is allowed; the default is 10 ms.
- **Adaptive safety zone:** scales with the detected target size.
- **Detection confidence:** ignores low-confidence frames and releases safely rather than making a blind correction.
- **Temporal target selection:** prefers a plausible target near the previous target location, reducing jumps caused by UI noise.
- **Green/yellow tolerance:** accepts the target's observed green/yellow phases.
- **Simpler Advanced page:** old PID/hover controls are hidden because v4 calculates its response automatically.
- **Same simple workflow:** Accessibility + screen capture → START.

## Fishing model

Current Slayers 2 guides describe the minigame as keeping a white indicator inside a moving green/yellow target until the progress meter reaches 100%. Holding M1 raises the white indicator and releasing lowers it; after completion, T is used to collect the catch. See the cited sources in the development notes below.

## Research notes

The v4 controller was informed by current Slayers 2 guides and public implementations. In particular, the open-source PS2 Fisher Overlay describes a dead-zone controller that holds when the indicator is below the target and releases when it is above; current guides likewise describe short M1 adjustments rather than continuous holding.

## Safety / limitations

This is unofficial gameplay automation. Automating gameplay can violate Roblox or game-specific rules, so use it only where permitted. The project should be built from source rather than installing an APK from an unknown source.

The source package has not been compiled or executed against a live Slayers 2 session in this environment. Test first with a short fishing session.
