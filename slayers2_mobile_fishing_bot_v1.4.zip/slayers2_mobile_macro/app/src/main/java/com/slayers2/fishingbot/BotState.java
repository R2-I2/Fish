package com.slayers2.fishingbot;

/** Shared live state (activity, capture service and worker all run in one process). */
public final class BotState {
    public static volatile boolean running = false;
    public static volatile boolean projectionReady = false;
    public static volatile double indicatorY = -1;   // white square, screen px
    public static volatile double targetY = -1;      // centre of green box, screen px
    public static volatile double targetH = 0;       // height of green box, screen px
    public static volatile long lastSeen = 0;        // last time both were detected
    public static volatile String status = "Stopped";

    private BotState() {}
}
