package com.slayers2.fishingbot;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Point;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int CAPTURE = 44;

    private EditText x, y, w, h, cx, cy, colX, colY, castWait, failWait, delay, hover, kp, kd, ki;
    private CheckBox invert;
    private TextView status;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 24, 32, 24);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);

        Point s = Config.realSize(this);
        title(root, "Slayers 2 - Fishing Bot");
        text(root, "Screen: " + s.x + " x " + s.y + " px (all coordinates below are in these pixels). "
                + "Keep the phone in landscape. Screen-reading + touch automation only; nothing is injected into Roblox.");

        Button acc = button(root, "1. Enable Accessibility service");
        acc.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        Button cap = button(root, "2. Grant screen capture (choose ENTIRE screen)");
        cap.setOnClickListener(v -> requestCapture());
        Button bat = button(root, "3. Allow background use (set battery to Unrestricted)");
        bat.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)));

        Button ovl = button(root, "4. Allow floating START/STOP button (display over other apps)");
        ovl.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()))));

        text(root, "Scan region around the fishing bar (interior of the bar, not its outline)");
        x = field(root, "X"); y = field(root, "Y"); w = field(root, "Width"); h = field(root, "Height");
        text(root, "Press / hold point (empty area of the game screen, NOT the Exit button or joystick)");
        cx = field(root, "Hold X"); cy = field(root, "Hold Y");
        colX = field(root, "Collect tap X"); colY = field(root, "Collect tap Y");
        text(root, "Timing");
        castWait = field(root, "Wait after cast (ms)");
        failWait = field(root, "Recast if no bite after (ms)");
        delay = field(root, "Start delay (s) - time to switch to the game");
        text(root, "Tracking (tune these if the square oscillates or lags)");
        hover = field(root, "Hover hold % (how long to hold per cycle just to stay level)");
        kp = field(root, "Response P (x10)");
        kd = field(root, "Damping D (x10)");
        ki = field(root, "Auto-balance I (x10)");
        invert = new CheckBox(this);
        invert.setText("Invert: holding moves the square DOWN");
        root.addView(invert);

        Button save = button(root, "Save settings");
        save.setOnClickListener(v -> { save(); status.setText("Saved"); });
        Button start = button(root, "START / STOP BOT");
        start.setOnClickListener(v -> toggle());
        Button quit = button(root, "Shut down screen capture");
        quit.setOnClickListener(v -> {
            stopService(new Intent(this, ProjectionService.class));
            BotState.running = false;
            BotState.projectionReady = false;
            BotState.status = "Stopped";
        });

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, 16, 0, 16);
        root.addView(status);
        text(root, "In the game: tap the round START button (drag it wherever you like), the bot starts after the delay. "
                + "Tap it again, press VOLUME DOWN, or use the notification to stop. Watch the first few catches.");

        load();
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        ui.post(refresh);
    }

    @Override protected void onPause() {
        ui.removeCallbacks(refresh);
        super.onPause();
    }

    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            boolean seen = System.currentTimeMillis() - BotState.lastSeen < 500;
            String det = seen
                    ? String.format(Locale.US, "\nBar detected: square y=%.0f, target y=%.0f", BotState.indicatorY, BotState.targetY)
                    : "\nBar not detected";
            status.setText((BotState.running ? "RUNNING - " : "Idle - ") + BotState.status
                    + "\nCapture: " + (BotState.projectionReady ? "ready" : "not granted") + det);
            ui.postDelayed(this, 250);
        }
    };

    // ------------------------------------------------------------ helpers

    private void title(LinearLayout p, String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(22);
        p.addView(t);
    }

    private void text(LinearLayout p, String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setPadding(0, 20, 0, 4);
        p.addView(t);
    }

    private Button button(LinearLayout p, String s) {
        Button b = new Button(this);
        b.setText(s);
        p.addView(b);
        return b;
    }

    private EditText field(LinearLayout p, String label) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(12);
        p.addView(t);
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setSingleLine(true);
        p.addView(e);
        return e;
    }

    private int n(EditText e, int d) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (Exception z) { return d; }
    }

    private void load() {
        Config c = Config.load(this);
        x.setText("" + c.x); y.setText("" + c.y); w.setText("" + c.w); h.setText("" + c.h);
        cx.setText("" + c.cx); cy.setText("" + c.cy); colX.setText("" + c.colX); colY.setText("" + c.colY);
        castWait.setText("" + c.castWait); failWait.setText("" + c.failWait); delay.setText("" + c.startDelay);
        hover.setText("" + c.hoverPct); kp.setText("" + c.kp10); kd.setText("" + c.kd10); ki.setText("" + c.ki10);
        invert.setChecked(c.invert);
    }

    private void save() {
        Config d = Config.load(this);
        Config c = new Config();
        c.x = n(x, d.x); c.y = n(y, d.y); c.w = n(w, d.w); c.h = n(h, d.h);
        c.cx = n(cx, d.cx); c.cy = n(cy, d.cy); c.colX = n(colX, d.colX); c.colY = n(colY, d.colY);
        c.castWait = n(castWait, d.castWait); c.failWait = n(failWait, d.failWait); c.startDelay = n(delay, d.startDelay);
        c.hoverPct = Math.max(0, Math.min(100, n(hover, d.hoverPct)));
        c.kp10 = n(kp, d.kp10); c.kd10 = n(kd, d.kd10); c.ki10 = n(ki, d.ki10);
        c.invert = invert.isChecked();
        Config.save(this, c);
    }

    private void requestCapture() {
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent i;
        if (Build.VERSION.SDK_INT >= 34) {
            // Android 14+ lets users share "one app" only; force the entire screen so touches/coords line up.
            i = m.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay());
        } else {
            i = m.createScreenCaptureIntent();
        }
        startActivityForResult(i, CAPTURE);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == CAPTURE && res == RESULT_OK && data != null) {
            Intent s = new Intent(this, ProjectionService.class);
            s.putExtra("resultCode", res);
            s.putExtra("data", data);
            startForegroundService(s);
            status.setText("Starting screen capture...");
        } else if (req == CAPTURE) {
            status.setText("Screen capture was not granted");
        }
    }

    private void toggle() {
        save();
        if (!BotState.projectionReady) { status.setText("Grant screen capture first"); return; }
        startService(new Intent(this, ProjectionService.class).setAction(ProjectionService.ACTION_TOGGLE));
    }
}
