# Slayers 2 Fishing Bot (Android) - v1.9

Screen-reading + touch automation for the fishing bar minigame (keep the white square inside the yellow-green box).
No injection, no memory reading. Captures the screen (MediaProjection), finds the two shapes by colour,
presses/holds through an Accessibility service. Works on Android 8+ (Galaxy S21: Android 11-14+).

**What was tested (in the author's sandbox):** the bar detector on a real 2400x1080 screenshot of the minigame
(found square y=725, box y=670 correctly); the tracking controller in a physics simulation (about 65-75% of the time
inside the box on two very different guessed game-physics models); XML/YAML validity and Java syntax.
**Not tested:** compiling against the Android SDK, and running on a real phone / in the real game. Do the checklist below.

## The app (v1.6)
Four tabs on the left rail:
- **Home** - big START/STOP, live status, rounds played, and a live mini-preview of what the bot sees
  (yellow box = target, white square = your indicator).
- **Setup** - five cards (Accessibility, screen capture, floating button, background use, notifications), each with a
  green/red chip and a button that opens the right settings page.
- **Tune** - "Pick on screen" for the cast point (tap the water), hold point, optional collect-button tap and the bar area
  (tap top then bottom of the bar), plus steppers/sliders for timing and steering. Everything saves instantly and applies live.
- **Guide** - how fishing works in Slayers 2 (permit, rod, minigame inputs, loot), from community guides, Sept 2026.

Flow the bot follows (confirmed in-game): press the hand-icon Cast button -> wait for the bite -> minigame starts by itself ->
short presses keep the white square inside the box (holding lifts, releasing lowers; the box is yellow outside, green inside) ->
HOLD the white finger Collect circle for ~2 s -> cast again.

### What changed in v1.9 (fixes "it doesn't catch up with the box")
- A longer reaction time is SLOWER, not faster (0.25 s = 4 decisions a second). v1.9 goes the other way: it decides every 50 ms.
- **Smooth hold**: the finger used to be lifted and re-placed on every press (a gap each time), so the square could not climb at full speed.
  Now one touch stays down between presses (chained 40 ms strokes) and is lifted only when the square needs to drop.
  Tune > Steering > "Smooth hold". If the phone rejects chained strokes, the bot automatically falls back to plain presses
  (the floating button then says "pulses").
- New defaults for this mode: hover 40, response 40, damping 18, react every 50 ms.
- In the author's simulation (fast-moving box, guessed physics) time-in-box went from about 58% (old style, 90 ms) and 39% (250 ms) to about 70-73%.

### What changed in v1.8 (superseded)
- The bot now decides **every 250 ms** (Tune > "React every"). Each decision is delivered as short 50 ms presses
  (Tune > "Press pulses") so the square moves smoothly. Trade-off: in the author's simulation a 250 ms cycle keeps the square in
  the box roughly 54% of the time versus about 84% at 75 ms. If your progress bar fills slowly, set "React every" back to 75
  and raise Damping to about 12.

### What changed in v1.7
- Cast uses the hand-icon button (Tune > Cast button) and Collect holds the white finger circle for 2 s (adjustable).
  Default positions come from a 2400x1080 screenshot; the buttons sit next to your character, so use Tune > Pick if yours differ.
- Box detection now handles BOTH colours (yellow while outside, green while the square is inside).
- Faster steering: reacts every 75 ms (was 90) and damps against the target's own movement. In the author's simulation this raised
  the share of time the square stayed inside the box from about 71% to 84% (simulated physics, not the real game).
- Shorter idle delays between rounds. Tune > Reaction cycle lets you go faster or slower.

## Updating the app
Each GitHub build is signed with a fresh debug key, so **uninstall the old version first**, then install the new APK.

## Reading the floating button (v1.5)
The button shows a second line: `ACCESS OFF` (Accessibility service isn't connected), `no bar yet` (waiting for a bite),
`bar ok hold 80% g 12/3` (bar found; "g ok/cancelled" = gestures the phone accepted / dropped).
If the bar is found and gestures are accepted but the square doesn't move, the game isn't reacting to the injected hold:
move the Hold X/Y point. **Long-press START** (idle, bar on screen) sends a 2-second test hold at the hold point.

## Test checklist (do this in order)
1. Build succeeds (green check in GitHub Actions). If red, screenshot the failing step.
2. App opens, all 4 setup buttons work, "Capture: ready" shows after granting screen capture.
3. Go to a fishing bar in the game, open the app (or watch the floating button): the app's status line must say
   "Bar detected: square y=..., target y=...". If not, fix the scan region first - nothing else matters until it does.
4. Tap START. Watch the first catches: does the square rise when it's below the box? If it goes the wrong way, tick Invert.
5. Wobbles: lower P or raise D. Sinks/floats away: change Hover %. Slow to correct: raise P.

## Build the APK from your phone only (GitHub, free)
1. Make a free account at github.com and create a new repository (private is fine).
2. In the repo choose "uploading an existing file" (or Add file > Upload files) and upload THIS ZIP as one file. Commit.
3. Add file > Create new file. Name it `.github/workflows/build.yml` (typing the slashes makes the folders) and paste:

```
name: Build APK
on: workflow_dispatch
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: for z in *.zip; do unzip -q -o "$z"; done
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'
      - run: cd slayers2_mobile_macro && gradle assembleDebug --no-daemon
      - uses: actions/upload-artifact@v4
        with:
          name: fishing-bot-apk
          path: slayers2_mobile_macro/app/build/outputs/apk/debug/app-debug.apk
```
4. Commit, open the Actions tab > "Build APK" > Run workflow. Wait a few minutes for the green check.
5. Open the finished run, download the `fishing-bot-apk` artifact (a .zip), extract it in My Files, install app-debug.apk.
If the run fails, open it and screenshot the red error step.

## Install on a Galaxy S21
- Settings > Security and privacy > Auto Blocker: turn it OFF (it blocks installing APKs).
- Allow "Install unknown apps" for the app you opened the APK with (Chrome / My Files).
- Open the bot > "1. Enable Accessibility service". If the switch is greyed out: back out, open Settings > Apps >
  Slayers 2 Fishing Bot > menu (top right) > Allow restricted settings, then try again.
- "2. Grant screen capture": choose ENTIRE screen (not "one app"), then Start now.
- "3. Allow background use": set the app's battery to Unrestricted so One UI does not kill it mid-run.
- "4. Allow floating START/STOP button": turn on "Allow display over other apps" for the bot.
- The S21 screen is 2400x1080, which is what the defaults were tuned on. Keep the phone in landscape.

## Use while playing Roblox
- A round **START** button floats over the game (drag it anywhere; it remembers the spot). Tap it: a short countdown
  runs, then the bot fishes. The button turns red and says **STOP**.
- **Stop:** tap the red button, or press **Volume Down** (works instantly; volume only acts as a stop key while the bot runs),
  or use the notification.
- While the bot runs it sends its own touches, so you can't play manually at the same time.

## First-time calibration
1. In the app, check the live line "Bar detected: ..." while a fishing bar is on screen. If "not detected", adjust the
   scan region so it covers the inside of the bar (not the outline).
2. Open Slayers 2, stand at the fishing spot with the rod ready, tap the floating START button.

## What you probably need to adjust
- **Hold point** (Hold X/Y): an empty spot where a press controls the minigame. Never the Exit button or joystick.
- **Invert**: tick it if holding moves the square DOWN (default assumes holding moves it UP).
- **Cast / collect**: the bot taps the hold point to cast and the "collect tap" point after a catch. These are guesses.
- **Wobbling**: lower P, raise D. **Reacts late / drifts**: raise P. **Sinks while "level"**: raise Hover % (I auto-balances slowly).

## Risk
Automating gameplay may violate the game's or Roblox's rules and can get an account suspended. Use at your own risk.
