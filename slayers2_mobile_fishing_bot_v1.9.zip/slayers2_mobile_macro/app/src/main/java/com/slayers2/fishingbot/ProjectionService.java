package com.slayers2.fishingbot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spannable;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.nio.ByteBuffer;
import java.util.Locale;

public class ProjectionService extends Service {
    public static final String ACTION_TOGGLE = "com.slayers2.fishingbot.TOGGLE";
    private static final String CHANNEL = "s2bot";
    private static final int NOTIF_ID = 9;
    private static final int DIV = 2;              // capture at 1/2 resolution (faster), coords scaled back

    private static final int CASTING = 0, WAITING = 1, PLAYING = 2, FINISHING = 3;

    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay vdisplay;
    private HandlerThread captureThread;
    private Thread worker;
    private volatile boolean alive = true;
    private MediaProjection.Callback projectionCallback;

    // floating START/STOP button
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView overlay;
    private boolean lastShownRunning = false;

    private int cw, ch;
    private volatile Config cfg;
    private volatile long startAt = 0;

    // worker-thread state
    private int state = CASTING;
    private long lastCast = 0, lastActive = 0, lastIndTime = 0;
    private double lastInd = -1, lastTgt = -1, vel = 0, integ = 0, acc = 0;

    @Override public void onCreate() {
        super.onCreate();
        cfg = Config.load(this);
    }

    @Override public int onStartCommand(Intent in, int flags, int id) {
        if (in != null && ACTION_TOGGLE.equals(in.getAction())) {
            toggle();
            return START_NOT_STICKY;
        }
        startForegroundCompat();
        if (in != null && in.hasExtra("data")) {
            int rc = in.getIntExtra("resultCode", 0);
            Intent data = getData(in);
            startCapture(rc, data);
        }
        return START_NOT_STICKY;
    }

    @SuppressWarnings("deprecation")
    private Intent getData(Intent in) {
        if (Build.VERSION.SDK_INT >= 33) return in.getParcelableExtra("data", Intent.class);
        return in.getParcelableExtra("data");
    }

    // ---------------------------------------------------------------- capture

    private void startCapture(int rc, Intent data) {
        releaseCapture();
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = m.getMediaProjection(rc, data);
        if (projection == null) { BotState.status = "Screen capture was denied"; return; }

        Point real = Config.realSize(this);
        cw = Math.max(2, real.x / DIV);
        ch = Math.max(2, real.y / DIV);
        cfg = Config.load(this);

        captureThread = new HandlerThread("s2-capture");
        captureThread.start();
        Handler handler = new Handler(captureThread.getLooper());

        // Android 14+ requires a callback to be registered BEFORE creating the virtual display.
        projectionCallback = new MediaProjection.Callback() {
            @Override public void onStop() {
                if (!alive) return;
                BotState.running = false;
                BotState.projectionReady = false;
                BotState.status = "Screen capture stopped";
                stopSelf();
            }
        };
        projection.registerCallback(projectionCallback, handler);

        reader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2);
        int dpi = getResources().getDisplayMetrics().densityDpi;
        vdisplay = projection.createVirtualDisplay("S2FishingCapture", cw, ch, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        reader.setOnImageAvailableListener(r -> {
            Image im = null;
            try {
                im = r.acquireLatestImage();
                if (im != null) process(im);
            } catch (Throwable t) {
                BotState.status = "Capture error: " + t.getClass().getSimpleName();
            } finally {
                if (im != null) im.close();
            }
        }, handler);

        BotState.projectionReady = true;
        BotState.status = "Ready";
        if (worker == null || !worker.isAlive()) {
            worker = new Thread(this::loop, "s2-bot");
            worker.start();
        }
        updateNotification();
        ui.removeCallbacks(tick);
        ui.post(tick);
    }

    private void releaseCapture() {
        BotState.projectionReady = false;
        try { if (reader != null) reader.close(); } catch (Throwable ignored) {}
        try { if (vdisplay != null) vdisplay.release(); } catch (Throwable ignored) {}
        try { if (projection != null && projectionCallback != null) projection.unregisterCallback(projectionCallback); } catch (Throwable ignored) {}
        try { if (projection != null) projection.stop(); } catch (Throwable ignored) {}
        try { if (captureThread != null) captureThread.quitSafely(); } catch (Throwable ignored) {}
        reader = null; vdisplay = null; projection = null; captureThread = null;
    }

    /**
     * Finds the white square (indicator) and the yellow-green box (target) inside the scan region.
     * Reads the raw frame buffer directly; no bitmap allocation.
     * Colours were checked against a real screenshot: white square ~ (196,197,199),
     * green box edge ~ (143,171,11), track background ~ (12,27,46).
     */
    private void process(Image im) {
        Config c = cfg;
        Image.Plane pl = im.getPlanes()[0];
        ByteBuffer buf = pl.getBuffer();
        int rs = pl.getRowStride(), ps = pl.getPixelStride();

        int x0 = Math.max(0, c.x / DIV), x1 = Math.min(cw, (c.x + c.w) / DIV);
        int y0 = Math.max(0, c.y / DIV), y1 = Math.min(ch, (c.y + c.h) / DIV);
        if (x1 - x0 < 4 || y1 - y0 < 4) return;
        int rw = x1 - x0;
        int need = Math.max(3, rw * 3 / 10);

        int gMin = -1, gMax = -1;
        int bestS = -1, bestE = -1, runS = -1, lastW = -1;

        for (int yy = y0; yy < y1; yy++) {
            int wc = 0, gc = 0, base = yy * rs;
            for (int xx = x0; xx < x1; xx++) {
                int o = base + xx * ps;
                int r = buf.get(o) & 0xFF, g = buf.get(o + 1) & 0xFF, b = buf.get(o + 2) & 0xFF;
                int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
                if (mn > 150 && mx - mn < 35) wc++;
                else if (mx >= 140 && g * 5 >= r * 4 && g * 5 > b * 8 && (mx - mn) * 2 > mx) gc++;   // bright yellow OR green
            }
            if (wc >= need) {
                if (runS < 0) runS = yy;
                lastW = yy;
            } else if (runS >= 0 && yy - lastW > 2) {
                if (bestS < 0 || lastW - runS > bestE - bestS) { bestS = runS; bestE = lastW; }
                runS = -1;
            }
            if (gc >= need) { if (gMin < 0) gMin = yy; gMax = yy; }
        }
        if (runS >= 0 && (bestS < 0 || lastW - runS > bestE - bestS)) { bestS = runS; bestE = lastW; }

        if (bestS >= 0 && gMin >= 0) {
            BotState.indicatorY = (bestS + bestE) / 2.0 * DIV;
            BotState.targetY = (gMin + gMax) / 2.0 * DIV;
            BotState.targetH = (gMax - gMin + 1) * DIV;
            BotState.lastSeen = System.currentTimeMillis();
        }
    }

    // ---------------------------------------------------------------- bot loop

    private void toggle() {
        if (!BotState.projectionReady) {
            BotState.status = "Grant screen capture first";
            return;
        }
        if (BotState.running) {
            BotState.running = false;
            BotState.status = "Stopped";
            BotState.note = "";
        } else {
            if (InputService.instance == null) {
                BotState.status = "Enable the Accessibility service first";
                BotState.note = "ACCESS OFF";
                ui.postDelayed(() -> BotState.note = "", 3500);
                return;
            }
            BotState.gOk = 0; BotState.gCancel = 0; BotState.gFail = 0;
            BotState.rounds = 0; BotState.startedAt = System.currentTimeMillis();
            cfg = Config.load(this);
            state = CASTING; lastCast = 0; lastInd = -1; vel = 0; integ = 0; acc = 0;
            BotState.driverFails = 0;
            startAt = System.currentTimeMillis() + cfg.startDelay * 1000L;
            BotState.running = true;
            BotState.status = "Starting...";
        }
        updateNotification();
    }

    private void loop() {
        while (alive) {
            try {
                if (!BotState.running) {
                    InputService rin = InputService.instance;
                    if (rin != null) rin.release();
                    sleep(100);
                    continue;
                }
                InputService in = InputService.instance;
                if (in == null) { BotState.status = "Enable the Accessibility service"; BotState.note = "ACCESS OFF"; sleep(500); continue; }
                long now = System.currentTimeMillis();
                if (now < startAt) {
                    BotState.status = "Starting in " + ((startAt - now) / 1000 + 1) + "s - switch to the game";
                    BotState.note = "get ready";
                    sleep(150);
                    continue;
                }
                Config c = cfg;

                if (now - BotState.lastSeen < 300) {           // minigame on screen
                    state = PLAYING;
                    lastActive = now;
                    control(in, c);
                    continue;
                }
                lastInd = -1; vel = 0; integ = 0; acc = 0;
                in.release();

                switch (state) {
                    case PLAYING:
                        if (now - lastActive > 800) { state = FINISHING; BotState.rounds++; } else sleep(25);
                        break;
                    case FINISHING:
                        BotState.status = "Collecting";
                        BotState.note = "collecting";
                        if (c.collectOn) {
                            in.hold(c.colX, c.colY, c.collectHold);   // the collect prompt must be HELD for 1-2 s
                            sleep(c.collectHold + 400);
                        } else {
                            sleep(500);
                        }
                        state = CASTING;
                        break;
                    case CASTING:
                        BotState.status = "Casting";
                        BotState.note = "casting";
                        in.hold(c.castX, c.castY, c.castPress);   // press the hand-icon cast button
                        sleep(c.castPress + c.castWait);
                        lastCast = System.currentTimeMillis();
                        state = WAITING;
                        break;
                    default: // WAITING
                        BotState.status = "Waiting for a bite";
                        BotState.note = "no bar yet";
                        if (now - lastCast > c.failWait) state = CASTING; else sleep(30);
                }
            } catch (Throwable t) {
                BotState.status = "Error: " + t.getClass().getSimpleName();
                sleep(500);
            }
        }
    }

    /**
     * PD(+I) controller. The result is a "duty": the share of time the finger should be down.
     * Smooth mode turns it into press/release decisions every tick (sigma-delta) and lets InputService keep one touch
     * down between presses. If the phone rejects that, it falls back to one plain press per cycle.
     */
    private void control(InputService in, Config c) {
        double ind = BotState.indicatorY, tgt = BotState.targetY;
        long ft = BotState.lastSeen;
        if (lastInd >= 0 && ft > lastIndTime) {
            double dt = (ft - lastIndTime) / 1000.0;
            if (dt > 0.005 && dt < 0.8) vel = 0.6 * vel + 0.4 * (((ind - tgt) - (lastInd - lastTgt)) / dt);   // rate of change of the ERROR
        }
        if (ft != lastIndTime) { lastInd = ind; lastTgt = tgt; lastIndTime = ft; }
        final int tick = Math.max(30, c.cycle);

        double bar = Math.max(100, c.h);
        double e = (ind - tgt) / bar;        // > 0 : square is below the target, needs to rise
        double v = vel / bar;                // > 0 : error is growing (square falling away / target rising)
        integ = Math.max(-0.6, Math.min(0.6, integ + e * (tick / 1000.0)));
        double duty = c.hoverPct / 100.0 + (c.kp10 / 10.0) * e + (c.kd10 / 10.0) * v + (c.ki10 / 10.0) * integ;
        if (c.invert) duty = 1.0 - duty;     // for a game where holding moves the square DOWN
        duty = Math.max(0, Math.min(1, duty));

        final boolean smooth = c.smooth && BotState.driverFails < 6;
        BotState.status = String.format(Locale.US, "Tracking  err %+.0f px  hold %d%%", ind - tgt, (int) (duty * 100));
        BotState.note = String.format(Locale.US, smooth ? "bar ok  hold %d%%  g %d/%d" : "bar ok  pulses %d%%  g %d/%d",
                (int) (duty * 100), BotState.gOk, BotState.gCancel);

        if (smooth) {
            acc += duty;
            boolean wantDown = false;
            if (acc >= 1.0) { wantDown = true; acc -= 1.0; }
            in.setHold(c.cx, c.cy, wantDown);
            sleep(tick);
            return;
        }

        // ---- fallback: one plain press per cycle (old behaviour)
        final int cyc = Math.max(70, tick);
        int hold = (int) Math.round(duty * cyc);
        if (hold >= 22) {
            if (duty > 0.94) { in.hold(c.cx, c.cy, cyc + 30); sleep(cyc + 30); }
            else { in.hold(c.cx, c.cy, hold); sleep(cyc); }
        } else {
            sleep(cyc);
        }
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    // ---------------------------------------------------------------- floating button

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!alive) return;
            try {
                cfg = Config.load(ProjectionService.this);   // pick up Tune-tab changes live
                ensureOverlay();
                refreshOverlay();
                if (BotState.running != lastShownRunning) {
                    lastShownRunning = BotState.running;
                    updateNotification();
                }
            } catch (Throwable ignored) {}
            ui.postDelayed(this, 300);
        }
    };

    /**
     * Small draggable START/STOP bubble over the game. While the bot runs, its own gestures can cancel a
     * finger that is still down, so STOP fires on touch-DOWN (not on release).
     */
    private void ensureOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return;
        final WindowManager wm = getSystemService(WindowManager.class);
        final float d = getResources().getDisplayMetrics().density;
        final int size = (int) (58 * d);
        final TextView t = new TextView(this);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setMinWidth(size);
        t.setMinHeight(size);
        t.setPadding((int) (10 * d), (int) (6 * d), (int) (10 * d), (int) (6 * d));
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        final SharedPreferences sp = getSharedPreferences("bot", MODE_PRIVATE);
        Point real = Config.realSize(this);
        lp.x = sp.getInt("ox", (int) (8 * d));
        lp.y = sp.getInt("oy", real.y / 2 - size / 2);

        t.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean handled, dragging;
            final Runnable longPress = new Runnable() {
                @Override public void run() {
                    if (dragging || handled || BotState.running) return;
                    handled = true;
                    InputService in = InputService.instance;
                    Config c = cfg;
                    if (in == null) { BotState.note = "ACCESS OFF"; return; }
                    in.hold(c.cx, c.cy, 2000);            // test: does the game react to an injected hold?
                    BotState.note = "test hold 2s";
                    ui.postDelayed(() -> BotState.note = "", 2400);
                }
            };

            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = lp.x; startY = lp.y;
                        dragging = false; handled = false;
                        if (BotState.running) { handled = true; toggle(); refreshOverlay(); }
                        else ui.postDelayed(longPress, 700);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (handled) return true;
                        float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                        if (!dragging && Math.hypot(dx, dy) > 12 * d) { dragging = true; ui.removeCallbacks(longPress); }
                        if (dragging) {
                            lp.x = startX + (int) dx;
                            lp.y = startY + (int) dy;
                            wm.updateViewLayout(v, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ui.removeCallbacks(longPress);
                        if (handled) return true;
                        if (dragging) sp.edit().putInt("ox", lp.x).putInt("oy", lp.y).apply();
                        else { toggle(); refreshOverlay(); }
                        return true;
                    default:
                        ui.removeCallbacks(longPress);
                        return true;
                }
            }
        });

        try {
            wm.addView(t, lp);
            overlay = t;
            refreshOverlay();
        } catch (Throwable ex) {
            BotState.status = "Floating button error: " + ex.getClass().getSimpleName();
        }
    }

    private void refreshOverlay() {
        if (overlay == null) return;
        boolean on = BotState.running;
        long now = System.currentTimeMillis();
        String label = !on ? "START" : (now < startAt ? String.valueOf((startAt - now) / 1000 + 1) : "STOP");
        String note = BotState.note == null ? "" : BotState.note;
        if (note.isEmpty()) {
            overlay.setText(label);
        } else {
            SpannableString sp = new SpannableString(label + "\n" + note);
            sp.setSpan(new RelativeSizeSpan(0.7f), label.length() + 1, sp.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            overlay.setText(sp);
        }
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(29 * getResources().getDisplayMetrics().density);
        bg.setColor(on ? 0xCCC62828 : 0xCC2E7D32);
        overlay.setBackground(bg);
    }

    private void removeOverlay() {
        try {
            if (overlay != null) getSystemService(WindowManager.class).removeView(overlay);
        } catch (Throwable ignored) {}
        overlay = null;
    }

    // ---------------------------------------------------------------- notification

    private void startForegroundCompat() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Fishing Bot", NotificationManager.IMPORTANCE_LOW));
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private Notification buildNotification() {
        Intent t = new Intent(this, ProjectionService.class).setAction(ACTION_TOGGLE);
        PendingIntent toggle = PendingIntent.getService(this, 1, t,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this, 2, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean on = BotState.running;
        Notification.Action a = new Notification.Action.Builder(
                Icon.createWithResource(this, on ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play),
                on ? "STOP bot" : "START bot", toggle).build();
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Slayers 2 Fishing Bot")
                .setContentText(on ? "Running" : "Idle - tap START when the game is open")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .setContentIntent(open)
                .addAction(a)
                .build();
    }

    private void updateNotification() {
        getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification());
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onDestroy() {
        alive = false;
        BotState.running = false;
        InputService rin = InputService.instance;
        if (rin != null) rin.release();
        ui.removeCallbacks(tick);
        removeOverlay();
        releaseCapture();
        if (worker != null) worker.interrupt();
        super.onDestroy();
    }
}
