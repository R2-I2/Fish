package com.slayers2.fishingbot;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.view.Display;

/** Settings. Defaults are fractions of the real screen so they fit any phone (tuned on 2400x1080). */
public final class Config {
    public int x, y, w, h;          // scan region around the bar (screen px)
    public int cx, cy;              // where to press/hold during the minigame
    public int castX, castY;        // where to tap to cast (on the water)
    public boolean collectOn;       // tap a collect button after each catch
    public int colX, colY;          // tap used to collect the catch
    public int castWait, failWait;  // ms
    public int castPress, collectHold, cycle;
    public boolean smooth;          // continuous hold between presses   // ms: press length on the cast button, hold length on the collect button, control cycle
    public int startDelay;          // s
    public int hoverPct, kp10, kd10, ki10;
    public boolean invert;

    public static Point realSize(Context c) {
        Point p = new Point();
        DisplayManager dm = (DisplayManager) c.getSystemService(Context.DISPLAY_SERVICE);
        Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
        d.getRealSize(p);
        return p;
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("bot", Context.MODE_PRIVATE);
    }

    public static Config load(Context c) {
        Point s = realSize(c);
        SharedPreferences p = prefs(c);
        Config k = new Config();
        k.x = p.getInt("x", (int) (s.x * 0.7375));
        k.y = p.getInt("y", (int) (s.y * 0.148));
        k.w = p.getInt("w", (int) (s.x * 0.025));
        k.h = p.getInt("h", (int) (s.y * 0.556));
        k.cx = p.getInt("cx", (int) (s.x * 0.45));
        k.cy = p.getInt("cy", (int) (s.y * 0.50));
        // hand-icon cast button near the rod tip and the white "Collect" circle, as seen on a 2400x1080 screen
        k.castX = p.getInt("castX", (int) (s.x * 0.557));
        k.castY = p.getInt("castY", (int) (s.y * 0.581));
        k.colX = p.getInt("colX", (int) (s.x * 0.650));
        k.colY = p.getInt("colY", (int) (s.y * 0.585));
        k.collectOn = p.getBoolean("collectOn", true);
        k.castPress = p.getInt("castPress", 600);
        k.collectHold = p.getInt("colHold", 2000);
        k.cycle = p.getInt("cycle", 50);
        k.smooth = p.getBoolean("smooth", true);
        k.castWait = p.getInt("cast", 700);
        k.failWait = p.getInt("fail", 30000);
        k.startDelay = p.getInt("delay", 3);
        k.hoverPct = p.getInt("hover", 40);
        k.kp10 = p.getInt("kp", 40);
        k.kd10 = p.getInt("kd", 18);
        k.ki10 = p.getInt("ki", 5);
        k.invert = p.getBoolean("invert", false);
        return k;
    }

    public static void reset(Context c) {
        SharedPreferences p = prefs(c);
        int ox = p.getInt("ox", -1), oy = p.getInt("oy", -1);
        SharedPreferences.Editor e = p.edit().clear();
        if (ox >= 0) e.putInt("ox", ox);
        if (oy >= 0) e.putInt("oy", oy);
        e.apply();
    }

    public static void save(Context c, Config k) {
        prefs(c).edit()
            .putInt("x", k.x).putInt("y", k.y).putInt("w", k.w).putInt("h", k.h)
            .putInt("cx", k.cx).putInt("cy", k.cy).putInt("castX", k.castX).putInt("castY", k.castY).putInt("colX", k.colX).putInt("colY", k.colY)
            .putBoolean("collectOn", k.collectOn)
            .putInt("castPress", k.castPress).putInt("colHold", k.collectHold).putInt("cycle", k.cycle).putBoolean("smooth", k.smooth)
            .putInt("cast", k.castWait).putInt("fail", k.failWait).putInt("delay", k.startDelay)
            .putInt("hover", k.hoverPct).putInt("kp", k.kp10).putInt("kd", k.kd10).putInt("ki", k.ki10)
            .putBoolean("invert", k.invert).apply();
    }
}
