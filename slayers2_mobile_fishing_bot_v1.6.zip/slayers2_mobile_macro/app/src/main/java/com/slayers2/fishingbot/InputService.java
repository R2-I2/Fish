package com.slayers2.fishingbot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

public class InputService extends AccessibilityService {
    public static volatile InputService instance;

    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}
    @Override public boolean onUnbind(android.content.Intent i) { instance = null; return super.onUnbind(i); }
    @Override public void onDestroy() { instance = null; super.onDestroy(); }

    /** While the bot is running, Volume Down stops it instantly (a hardware key can't be cancelled by bot gestures). */
    @Override protected boolean onKeyEvent(KeyEvent e) {
        if (BotState.running && e.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (e.getAction() == KeyEvent.ACTION_DOWN) {
                BotState.running = false;
                BotState.status = "Stopped (Volume Down)";
            }
            return true;
        }
        return false;
    }

    public boolean tap(int x, int y) { return press(x, y, 40); }
    public boolean hold(int x, int y, long ms) { return press(x, y, Math.max(20, ms)); }

    /** Note: a new gesture cancels any gesture still in progress. Releasing = just not sending one. */
    private final GestureResultCallback resultCb = new GestureResultCallback() {
        @Override public void onCompleted(GestureDescription g) { BotState.gOk++; }
        @Override public void onCancelled(GestureDescription g) { BotState.gCancel++; }
    };

    private boolean press(int x, int y, long duration) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription s = new GestureDescription.StrokeDescription(p, 0, duration);
        GestureDescription g = new GestureDescription.Builder().addStroke(s).build();
        boolean ok = dispatchGesture(g, resultCb, null);
        if (!ok) BotState.gFail++;
        return ok;
    }
}
