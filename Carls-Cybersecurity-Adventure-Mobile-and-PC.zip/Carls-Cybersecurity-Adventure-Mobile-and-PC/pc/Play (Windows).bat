@echo off
rem Opens the game like a desktop app (Edge or Chrome app window), falls back to your default browser.
set "U=file:///%~dp0index.html"
set "U=%U:\=/%"
start "" msedge --app="%U%" --start-maximized 2>nul
if errorlevel 1 start "" chrome --app="%U%" --start-maximized 2>nul
if errorlevel 1 start "" "%~dp0index.html"
