Carl's Cybersecurity Adventure - PC version
===========================================
No install and no internet needed.

Windows : double-click  "Play (Windows).bat"   (opens in an app-style window)
Mac     : double-click  "Play (Mac).command"   (first time: right-click > Open)
Linux   : run           "Play (Linux).sh"
Any OS  : or just open  index.html  in Chrome, Edge or Firefox.

Tips
- Press F11 (or use Settings > Full) for fullscreen on a projector.
- Settings > A+ makes the text bigger. Press ? in the game for shortcuts.
- Progress resets every time you close the game (by design).
