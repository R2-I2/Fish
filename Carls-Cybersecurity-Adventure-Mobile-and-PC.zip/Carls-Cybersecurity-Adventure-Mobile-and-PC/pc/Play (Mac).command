#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
open -na "Google Chrome" --args --app="file://$DIR/index.html" 2>/dev/null \
 || open -na "Microsoft Edge" --args --app="file://$DIR/index.html" 2>/dev/null \
 || open "$DIR/index.html"
