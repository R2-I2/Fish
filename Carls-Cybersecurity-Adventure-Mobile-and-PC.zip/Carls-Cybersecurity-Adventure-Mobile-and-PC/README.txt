Carl's Cybersecurity Adventure - Mobile + PC
============================================

A) ANDROID APK  (folder: android-project)
   Needs: Android Studio (free) on a PC/Mac/Linux.
   1. Android Studio > File > Open > choose the "android-project" folder.
   2. Wait for "Gradle sync" to finish (first time downloads tools, needs internet).
   3. Build > Build Bundle(s) / APK(s) > Build APK(s).
   4. Click "locate" in the popup: app/build/outputs/apk/debug/app-debug.apk
   5. Copy it to the phone and tap it (allow "Install unknown apps" if asked).
   The game is bundled inside the APK, so it works fully offline.
   Phone Back button = in-game Esc; press Back twice quickly to exit.

B) INSTALL AS AN APP, NO APK  (folder: pwa)
   Upload the folder to any free HTTPS host (GitHub Pages, Netlify Drop, Cloudflare Pages).
   - Android Chrome: menu > "Install app" / "Add to Home screen"
   - Windows/Mac/Linux Chrome or Edge: install icon in the address bar
   It then opens in its own window and works offline.

C) PC, NO INSTALL  (folder: pc)
   Windows: "Play (Windows).bat"   Mac: "Play (Mac).command"   Linux: "Play (Linux).sh"
   Or just open index.html in any browser.

Note: the Android project was prepared without an Android SDK, so it has not been
compiled yet. If Android Studio shows a version prompt, accept its suggested update.


D) GITHUB (free)  - builds the APK for you and hosts the web app
   1. Make a free account at github.com and create a new repository (Public or Private), e.g. "carls-cyber".
   2. Upload EVERYTHING in this folder to the repository root (Add file > Upload files).
      The hidden ".github" folder must be included. If it is missing after upload, use
      Add file > Create new file, type  .github/workflows/build-apk.yml  and paste the text from
      github-workflows-copy/build-apk.yml. Repeat for pages.yml.
   3. APK: open the "Actions" tab > "Build Android APK" > latest run > download the
      "Carls-Cybersecurity-Adventure-apk" artifact (a zip containing app-debug.apk). Takes about 3-5 minutes.
   4. Web app: Settings > Pages > Source = "GitHub Actions". Your game goes live at
      https://YOUR-NAME.github.io/REPO-NAME/ and can be installed from Chrome/Edge (Android and PC).
   Note: the APK workflow has not been run yet, so the first build may need small fixes.
