package com.slayers2.fishingbot;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Small styling toolkit so the whole app looks consistent (dark theme, rounded cards, teal accent). */
final class Ui {
    static final int BG = 0xFF0E1224, CARD = 0xFF1A2040, CARD2 = 0xFF283061, ACCENT = 0xFF4FD1C5,
            GOOD = 0xFF34D399, BAD = 0xFFF87171, WARN = 0xFFFBBF24, TEXT = 0xFFE8ECFF,
            MUTED = 0xFF9AA3C7, RED = 0xFFE5484D, GREEN_BTN = 0xFF16A34A, VIOLET = 0xFF6D5BE0;
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    interface OnInt { void run(int v); }
    interface OnBool { void run(boolean b); }

    private Ui() {}

    static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    static GradientDrawable round(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static LinearLayout.LayoutParams lp(Context c, int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(round(c, CARD, 16));
        int p = dp(c, 14);
        l.setPadding(p, p, p, p);
        l.setLayoutParams(lp(c, MATCH, WRAP, 0, 10, 0, 0));
        return l;
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static Button button(Context c, String label, int bg, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(round(c, bg, 12));
        b.setStateListAnimator(null);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8));
        b.setOnClickListener(l);
        return b;
    }

    static TextView chip(Context c) {
        TextView t = text(c, "", 12, Color.WHITE, true);
        t.setPadding(dp(c, 10), dp(c, 4), dp(c, 10), dp(c, 4));
        t.setGravity(Gravity.CENTER);
        return t;
    }

    static void setChip(Context c, TextView t, boolean ok, String yes, String no) {
        t.setText(ok ? "✓ " + yes : "✗ " + no);
        t.setBackground(round(c, ok ? 0xFF0F3D2B : 0xFF4A1D1D, 10));
        t.setTextColor(ok ? GOOD : BAD);
    }

    static LinearLayout hrow(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    // ------------------------------------------------------------------ widgets

    static final class Stepper {
        final LinearLayout view;
        final TextView valueView;
        final int min, max, step;
        final String unit;
        int value;

        Stepper(LinearLayout view, TextView valueView, int min, int max, int step, String unit) {
            this.view = view; this.valueView = valueView;
            this.min = min; this.max = max; this.step = step; this.unit = unit;
        }

        void set(int v) {
            value = Math.max(min, Math.min(max, v));
            valueView.setText(value + unit);
        }
    }

    /** Label on the left, [-] value [+] on the right. Easier than typing numbers on a phone. */
    static Stepper stepper(final Context c, String label, int min, int max, int step, int initial,
                           String unit, final OnInt onChange) {
        LinearLayout row = hrow(c);
        row.setPadding(0, dp(c, 4), 0, dp(c, 4));
        row.addView(text(c, label, 14, TEXT, false), new LinearLayout.LayoutParams(0, WRAP, 1f));
        final TextView val = text(c, "", 14, ACCENT, true);
        val.setGravity(Gravity.CENTER);
        final Stepper s = new Stepper(row, val, min, max, step, unit);
        Button minus = button(c, "−", CARD2, v -> { s.set(s.value - s.step); onChange.run(s.value); });
        Button plus = button(c, "+", CARD2, v -> { s.set(s.value + s.step); onChange.run(s.value); });
        row.addView(minus, new LinearLayout.LayoutParams(dp(c, 44), dp(c, 40)));
        row.addView(val, new LinearLayout.LayoutParams(dp(c, 92), WRAP));
        row.addView(plus, new LinearLayout.LayoutParams(dp(c, 44), dp(c, 40)));
        s.set(initial);
        return s;
    }

    static final class SeekRow {
        final LinearLayout view;
        final SeekBar bar;
        final TextView valueView;
        final int min;
        final String unit;

        SeekRow(LinearLayout view, SeekBar bar, TextView valueView, int min, String unit) {
            this.view = view; this.bar = bar; this.valueView = valueView; this.min = min; this.unit = unit;
        }

        void set(int v) {
            bar.setProgress(v - min);
            valueView.setText(v + unit);
        }
    }

    static SeekRow seek(Context c, String label, String hint, final int min, int max, int initial,
                        final String unit, final OnInt onChange) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(c, 6), 0, dp(c, 2));
        LinearLayout top = hrow(c);
        top.addView(text(c, label, 14, TEXT, false), new LinearLayout.LayoutParams(0, WRAP, 1f));
        final TextView val = text(c, "", 14, ACCENT, true);
        top.addView(val);
        box.addView(top);
        if (hint != null && !hint.isEmpty()) box.addView(text(c, hint, 11, MUTED, false));
        SeekBar sb = new SeekBar(c);
        sb.setMax(max - min);
        sb.setProgressTintList(ColorStateList.valueOf(ACCENT));
        sb.setThumbTintList(ColorStateList.valueOf(ACCENT));
        box.addView(sb, new LinearLayout.LayoutParams(MATCH, WRAP));
        final SeekRow row = new SeekRow(box, sb, val, min, unit);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                val.setText((p + min) + unit);
                if (fromUser) onChange.run(p + min);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        row.set(initial);
        return row;
    }

    static Switch toggle(Context c, String label, boolean initial, final OnBool cb) {
        Switch s = new Switch(c);
        s.setText(label);
        s.setTextColor(TEXT);
        s.setTextSize(14);
        s.setChecked(initial);
        s.setPadding(0, dp(c, 6), 0, dp(c, 6));
        s.setOnCheckedChangeListener((b, on) -> cb.run(on));
        return s;
    }
}
