package com.slayers2.fishingbot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

public class InputService extends AccessibilityService {
    public static volatile InputService instance;

    /** Length of one chained segment of the smooth hold. The finger stays down between segments. */
    private static final long SEG = 40;

    // ---- smooth-hold driver state (guarded by lock)
    private final Object lock = new Object();
    private GestureDescription.StrokeDescription cur;   // stroke that is currently down (willContinue = true), else null
    private boolean want;                               // controller wants the finger down
    private boolean busy;                               // a segment is in flight
    private int hx, hy, cancelStreak;

    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}
    @Override public boolean onUnbind(android.content.Intent i) { instance = null; return super.onUnbind(i); }
    @Override public void onDestroy() { instance = null; super.onDestroy(); }

    /** While the bot is running, Volume Down stops it instantly (a hardware key can't be cancelled by bot gestures). */
    @Override protected boolean onKeyEvent(KeyEvent e) {
        if (BotState.running && e.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (e.getAction() == KeyEvent.ACTION_DOWN) {
                BotState.running = false;
                BotState.status = "Stopped (Volume Down)";
                release();
            }
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ simple gestures (cast, collect, tests)

    public boolean tap(int x, int y) { return press(x, y, 40); }
    public boolean hold(int x, int y, long ms) { return press(x, y, Math.max(20, ms)); }

    private final GestureResultCallback resultCb = new GestureResultCallback() {
        @Override public void onCompleted(GestureDescription g) { BotState.gOk++; }
        @Override public void onCancelled(GestureDescription g) { BotState.gCancel++; }
    };

    /** Note: a new gesture cancels any gesture still in progress (including a smooth hold). */
    private boolean press(int x, int y, long duration) {
        synchronized (lock) { want = false; }
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription s = new GestureDescription.StrokeDescription(p, 0, duration);
        GestureDescription g = new GestureDescription.Builder().addStroke(s).build();
        boolean ok = dispatchGesture(g, resultCb, null);
        if (!ok) BotState.gFail++;
        return ok;
    }

    /**
     * Sends one press and WAITS until the phone reports it finished. Because the next press is only sent afterwards,
     * no press is ever cancelled by a newer one (that was losing most presses). Also measures the dead time of a press.
     */
    public boolean pressAndWait(int x, int y, long ms) {
        synchronized (lock) { want = false; }
        final long len = Math.max(20, ms);
        final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(1);
        final boolean[] ok = {false};
        final long t0 = System.currentTimeMillis();
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, len)).build();
        boolean sent = dispatchGesture(g, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription d) {
                BotState.gOk++;
                ok[0] = true;
                long lag = System.currentTimeMillis() - t0 - len;
                BotState.pressLagMs = (int) (BotState.pressLagMs * 0.7 + Math.max(0, lag) * 0.3);
                latch.countDown();
            }
            @Override public void onCancelled(GestureDescription d) {
                BotState.gCancel++;
                latch.countDown();
            }
        }, null);
        if (!sent) { BotState.gFail++; return false; }
        try {
            latch.await(len + 500, java.util.concurrent.TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return ok[0];
    }

    // ------------------------------------------------------------------ smooth hold

    /**
     * Keeps ONE continuous touch down while wantDown is true (chained 40 ms segments, no lift in between) and lifts it
     * at the next segment boundary once wantDown turns false. Call it every control tick.
     */
    public void setHold(int x, int y, boolean wantDown) {
        synchronized (lock) {
            hx = x; hy = y; want = wantDown;
            if (!busy) {
                if (wantDown) startOrContinue();
                else if (cur != null) liftStroke();
            }
        }
    }

    /** Lift the finger (if down) and stop holding. */
    public void release() {
        synchronized (lock) {
            want = false;
            if (!busy && cur != null) liftStroke();
        }
    }

    private void startOrContinue() {            // lock held
        Path p = new Path();
        p.moveTo(hx, hy);
        try {
            GestureDescription.StrokeDescription s = (cur == null)
                    ? new GestureDescription.StrokeDescription(p, 0, SEG, true)
                    : cur.continueStroke(p, 0, SEG, true);
            if (send(s)) { cur = s; busy = true; } else { fail(); }
        } catch (Throwable t) {
            fail();
        }
    }

    private void liftStroke() {                 // lock held; finger is down but no longer wanted
        Path p = new Path();
        p.moveTo(hx, hy);
        try {
            GestureDescription.StrokeDescription s = cur.continueStroke(p, 0, 1, false);
            cur = null;
            if (send(s)) busy = true; else fail();
        } catch (Throwable t) {
            cur = null;
            fail();
        }
    }

    private boolean send(GestureDescription.StrokeDescription s) {
        return dispatchGesture(new GestureDescription.Builder().addStroke(s).build(), driverCb, null);
    }

    private void fail() {                       // lock held
        cur = null;
        busy = false;
        BotState.driverFails++;
    }

    private final GestureResultCallback driverCb = new GestureResultCallback() {
        @Override public void onCompleted(GestureDescription g) {
            synchronized (lock) {
                BotState.gOk++;
                cancelStreak = 0;
                busy = false;
                if (cur != null) {                       // finger still down after this segment
                    if (want) startOrContinue(); else liftStroke();
                } else if (want) {                       // a lifting segment just finished and a new press is wanted
                    startOrContinue();
                }
            }
        }

        @Override public void onCancelled(GestureDescription g) {
            synchronized (lock) {
                BotState.gCancel++;
                busy = false;
                cur = null;
                // the device keeps rejecting chained strokes -> let the bot fall back to plain pulses
                if (++cancelStreak >= 8) BotState.driverFails += 100;
            }
        }
    };
}
