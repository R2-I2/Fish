package com.slayers2.fishingbot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Live mini-preview of what the bot sees: yellow box (target) and white square (your indicator). */
public class BarView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private int regionY = 0, regionH = 1;

    public BarView(Context c) { super(c); }

    public void setRegion(int y, int h) {
        regionY = y;
        regionH = Math.max(1, h);
    }

    private float mapY(double y, float top, float bottom) {
        double f = (y - regionY) / (double) regionH;
        f = Math.max(0, Math.min(1, f));
        return (float) (top + f * (bottom - top));
    }

    @Override protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float d = getResources().getDisplayMetrics().density;
        float top = 4 * d, bottom = h - 4 * d;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF10142A);
        r.set(w * 0.2f, top, w * 0.8f, bottom);
        cv.drawRoundRect(r, 10 * d, 10 * d, p);

        boolean seen = System.currentTimeMillis() - BotState.lastSeen < 500;
        if (!seen) {
            p.setColor(0xFF9AA3C7);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(11 * d);
            cv.drawText("no bar", w / 2, h / 2, p);
            return;
        }
        float track = bottom - top;
        float boxH = (float) (BotState.targetH / regionH * track);
        float cy = mapY(BotState.targetY, top, bottom);
        boolean inside = Math.abs(BotState.indicatorY - BotState.targetY) < BotState.targetH / 2;
        p.setColor(inside ? 0xFF34D399 : 0xFFFACC15);   // green when the square is inside, like the game
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.5f * d);
        r.set(w * 0.12f, cy - boxH / 2, w * 0.88f, cy + boxH / 2);
        cv.drawRoundRect(r, 4 * d, 4 * d, p);

        float sq = Math.max(8 * d, 40f / regionH * track);
        float iy = mapY(BotState.indicatorY, top, bottom);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFF1F5F9);
        r.set(w * 0.3f, iy - sq / 2, w * 0.7f, iy + sq / 2);
        cv.drawRoundRect(r, 4 * d, 4 * d, p);
    }
}
