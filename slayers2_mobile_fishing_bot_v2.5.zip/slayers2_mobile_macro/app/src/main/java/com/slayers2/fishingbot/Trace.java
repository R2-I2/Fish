package com.slayers2.fishingbot;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import java.io.OutputStream;
import java.util.Locale;

/**
 * Keeps a compact log of the last fishing run (square/box positions ~60 times a second, every press the bot sent) so it
 * can be saved as Download/slayers_trace.csv. Stays on the phone unless you attach it somewhere yourself.
 */
final class Trace {
    private static final String HEADER = "t_ms,type,a,b,c,d\n";
    private static final StringBuilder sb = new StringBuilder(HEADER);
    private static long t0 = 0;

    private Trace() {}

    static synchronized void reset() {
        sb.setLength(0);
        sb.append(HEADER);
        t0 = 0;
    }

    /** F: a=square y, b=box y, c=box height | P: a=press ms, b=duty, c=error, d=style | E: a=ok, b=lag ms
     *  S: a=want down, b=duty, c=error | W: a=style, b=in-box share, c=style score */
    static synchronized void add(String type, double a, double b, double c, double d) {
        long now = System.currentTimeMillis();
        if (t0 == 0) t0 = now;
        if (sb.length() > 400000) sb.delete(HEADER.length(), HEADER.length() + 150000);
        sb.append(now - t0).append(',').append(type).append(',')
          .append(String.format(Locale.US, "%.2f,%.2f,%.2f,%.2f", a, b, c, d)).append('\n');
    }

    /** Returns null when saved, otherwise a short error text. */
    static String save(Context ctx) {
        String text;
        synchronized (Trace.class) { text = sb.toString(); }
        if (Build.VERSION.SDK_INT < 29) return "Saving needs Android 10 or newer";
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, "slayers_trace.csv");
            v.put(MediaStore.Downloads.MIME_TYPE, "text/csv");
            v.put(MediaStore.Downloads.RELATIVE_PATH, "Download");
            Uri uri = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return "Could not create the file";
            OutputStream os = ctx.getContentResolver().openOutputStream(uri);
            if (os == null) return "Could not open the file";
            try {
                os.write(text.getBytes("UTF-8"));
            } finally {
                os.close();
            }
            return null;
        } catch (Throwable t) {
            return "Save failed: " + t.getClass().getSimpleName();
        }
    }
}
