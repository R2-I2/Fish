package com.slayers2.fishingbot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spannable;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.nio.ByteBuffer;
import java.util.Locale;

public class ProjectionService extends Service {
    public static final String ACTION_TOGGLE = "com.slayers2.fishingbot.TOGGLE";
    public static final String ACTION_QUIT = "com.slayers2.fishingbot.QUIT";
    private static final String CHANNEL = "s2bot";
    private static final int NOTIF_ID = 9;
    private static final int DIV = 1;              // capture at full resolution: thin outlines survive, coords map 1:1

    private static final int CASTING = 0, WAITING = 1, PLAYING = 2, FINISHING = 3;

    private volatile boolean scanCollect = false;   // true while the worker waits for the collect button
    private byte[] cmask;
    private int[] cstack;

    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay vdisplay;
    private HandlerThread captureThread;
    private Thread worker;
    private volatile boolean alive = true;
    private MediaProjection.Callback projectionCallback;

    // floating START/STOP button
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView overlay;
    private boolean lastShownRunning = false;

    private int cw, ch;
    private volatile Config cfg;
    private volatile long startAt = 0;

    // worker-thread state
    private int state = CASTING;
    private long lastCast = 0, lastActive = 0, lastIndTime = 0;
    private double lastInd = -1, lastTgt = -1, vel = 0, integ = 0, acc = 0, liftInd = 0;
    private long liftStart = 0, lastCtrlMs = 0;
    private int noResp = 0;
    private long playBegan = 0;

    // press styles: 0 = presses (length grows with how hard we need to push), 1 = smooth hold (one touch kept down)
    private int arm = 0;
    private boolean armInit = false;
    private double winIn = 0, winTot = 0;
    private final double[] armScore = {-1, -1, -1};
    private final int[] armTries = {0, 0, 0};

    @Override public void onCreate() {
        super.onCreate();
        cfg = Config.load(this);
        loadArms();
    }

    @Override public int onStartCommand(Intent in, int flags, int id) {
        if (in != null && ACTION_QUIT.equals(in.getAction())) {   // 'Stop capture' from the notification
            BotState.running = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        if (in != null && ACTION_TOGGLE.equals(in.getAction())) {
            toggle();
            return START_NOT_STICKY;
        }
        startForegroundCompat();
        if (in != null && in.hasExtra("data")) {
            int rc = in.getIntExtra("resultCode", 0);
            Intent data = getData(in);
            startCapture(rc, data);
        }
        return START_NOT_STICKY;
    }

    @SuppressWarnings("deprecation")
    private Intent getData(Intent in) {
        if (Build.VERSION.SDK_INT >= 33) return in.getParcelableExtra("data", Intent.class);
        return in.getParcelableExtra("data");
    }

    // ---------------------------------------------------------------- capture

    private void startCapture(int rc, Intent data) {
        releaseCapture();
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = m.getMediaProjection(rc, data);
        if (projection == null) { BotState.status = "Screen capture was denied"; return; }

        Point real = Config.realSize(this);
        cw = Math.max(2, real.x / DIV);
        ch = Math.max(2, real.y / DIV);
        cfg = Config.load(this);

        captureThread = new HandlerThread("s2-capture");
        captureThread.start();
        Handler handler = new Handler(captureThread.getLooper());

        // Android 14+ requires a callback to be registered BEFORE creating the virtual display.
        projectionCallback = new MediaProjection.Callback() {
            @Override public void onStop() {
                if (!alive) return;
                BotState.running = false;
                BotState.projectionReady = false;
                BotState.status = "Screen capture stopped";
                stopSelf();
            }
        };
        projection.registerCallback(projectionCallback, handler);

        reader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2);
        int dpi = getResources().getDisplayMetrics().densityDpi;
        vdisplay = projection.createVirtualDisplay("S2FishingCapture", cw, ch, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        reader.setOnImageAvailableListener(r -> {
            Image im = null;
            try {
                im = r.acquireLatestImage();
                if (im != null) process(im);
            } catch (Throwable t) {
                BotState.status = "Capture error: " + t.getClass().getSimpleName();
            } finally {
                if (im != null) im.close();
            }
        }, handler);

        BotState.projectionReady = true;
        BotState.status = "Ready";
        if (worker == null || !worker.isAlive()) {
            worker = new Thread(this::loop, "s2-bot");
            worker.start();
        }
        updateNotification();
        ui.removeCallbacks(tick);
        ui.post(tick);
    }

    private void releaseCapture() {
        BotState.projectionReady = false;
        try { if (reader != null) reader.close(); } catch (Throwable ignored) {}
        try { if (vdisplay != null) vdisplay.release(); } catch (Throwable ignored) {}
        try { if (projection != null && projectionCallback != null) projection.unregisterCallback(projectionCallback); } catch (Throwable ignored) {}
        try { if (projection != null) projection.stop(); } catch (Throwable ignored) {}
        try { if (captureThread != null) captureThread.quitSafely(); } catch (Throwable ignored) {}
        reader = null; vdisplay = null; projection = null; captureThread = null;
    }

    /**
     * Finds the white square (indicator) and the yellow-green box (target) inside the scan region.
     * Reads the raw frame buffer directly; no bitmap allocation.
     * Colours were checked against a real screenshot: white square ~ (196,197,199),
     * green box edge ~ (143,171,11), track background ~ (12,27,46).
     */
    private boolean[] rowW, rowB;
    private int glitch = 0;
    private double knownBoxH = 0;

    private void process(Image im) {
        Config c = cfg;
        Image.Plane pl = im.getPlanes()[0];
        ByteBuffer buf = pl.getBuffer();
        int rs = pl.getRowStride(), ps = pl.getPixelStride();

        int x0 = Math.max(0, c.x / DIV), x1 = Math.min(cw, (c.x + c.w) / DIV);
        int y0 = Math.max(0, c.y / DIV), y1 = Math.min(ch, (c.y + c.h) / DIV);
        if (x1 - x0 < 4 || y1 - y0 < 4) return;
        final int rw = x1 - x0, rh = y1 - y0;
        final int needW = Math.max(3, rw * 35 / 100), needB = Math.max(3, rw * 3 / 10);
        if (rowW == null || rowW.length < rh) { rowW = new boolean[rh]; rowB = new boolean[rh]; }

        for (int yy = 0; yy < rh; yy++) {
            int wc = 0, gc = 0, base = (y0 + yy) * rs;
            for (int xx = x0; xx < x1; xx++) {
                int o = base + xx * ps;
                int r = buf.get(o) & 0xFF, g = buf.get(o + 1) & 0xFF, b = buf.get(o + 2) & 0xFF;
                int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
                boolean neutral = mn > 150 && mx - mn < 35;                                     // the white square
                boolean greenish = mn >= 140 && g >= r && g >= b && g - mn <= 75 && g - b >= 15;   // ...light green inside the green box
                if (neutral || greenish) wc++;
                else if (mx >= 140 && g * 5 >= r * 4 && g * 5 > b * 8 && (mx - mn) * 2 > mx) gc++;   // bright yellow OR green outline
            }
            rowW[yy] = wc >= needW;
            rowB[yy] = gc >= needB;
        }

        final long nowMs = System.currentTimeMillis();
        final boolean fresh = nowMs - BotState.lastSeen < 250 && BotState.indicatorY > 0;
        final double refRow = fresh ? BotState.indicatorY / DIV - y0 : -1;
        final double refBox = (nowMs - BotState.lastSeen < 400 && BotState.targetY > 0) ? BotState.targetY / DIV - y0 : -1;

        // ---- the square: a white run about 40 px tall (the top cap is 1-2 rows, water glare is much taller); when
        // several candidates exist take the one closest to where the square just was
        final int minSq = Math.max(6, 14 / DIV), maxSq = 62 / DIV;
        int bestS = -1, bestE = -1;
        double bestCost = Double.MAX_VALUE;
        int s0 = -1, last = -1;
        for (int yy = 0; yy <= rh; yy++) {
            boolean on = yy < rh && rowW[yy];
            if (on) {
                if (s0 < 0) s0 = yy;
                last = yy;
            } else if (s0 >= 0 && (yy >= rh || yy - last > 8 / DIV)) {   // gap of up to 8 px: the box outline can cut the square in two
                int hgt = last - s0 + 1;
                if (hgt >= minSq && hgt <= maxSq) {
                    double cen = (s0 + last) / 2.0;
                    double cost = refRow >= 0 ? Math.abs(cen - refRow) : Math.abs(hgt - 40.0 / DIV);
                    if (cost < bestCost) { bestCost = cost; bestS = s0; bestE = last; }
                }
                s0 = -1;
            }
        }

        // ---- the box: yellow/green outline rows (top and bottom edge); partial detections are completed with the known height
        int gMin = -1, gMax = -1;
        double bestG = Double.MAX_VALUE;
        int gs = -1, gl = -1, cnt = 0;
        for (int yy = 0; yy <= rh; yy++) {
            boolean on = yy < rh && rowB[yy];
            if (on) {
                if (gs < 0) { gs = yy; cnt = 0; }
                gl = yy;
                cnt++;
            } else if (gs >= 0 && (yy >= rh || yy - gl > 90 / DIV)) {
                double cen = (gs + gl) / 2.0;
                double cost = refBox >= 0 ? Math.abs(cen - refBox) : -cnt;
                if (cost < bestG) { bestG = cost; gMin = gs; gMax = gl; }
                gs = -1;
            }
        }
        if (bestS < 0 || gMin < 0) {
            if (scanCollect) findCollectButton(buf, rs, ps, c);
            return;
        }

        final double span = gMax - gMin + 1;
        double boxCenter = (gMin + gMax) / 2.0;
        if (span > 85.0 / DIV) return;                                         // far too tall to be the box
        if (span >= 50.0 / DIV) {
            knownBoxH = knownBoxH == 0 ? span : 0.8 * knownBoxH + 0.2 * span;
        } else if (knownBoxH > 0) {                                             // only one edge was seen
            double prev = refBox >= 0 ? refBox : boxCenter;
            double below = boxCenter + knownBoxH / 2, above = boxCenter - knownBoxH / 2;
            boxCenter = Math.abs(below - prev) <= Math.abs(above - prev) ? below : above;
        }

        final double indY = (y0 + (bestS + bestE) / 2.0) * DIV;
        final double tgtY = (y0 + boxCenter) * DIV;
        // a sudden jump of the square or the box between two frames is a misread: ignore it (but accept after 3 in a row)
        if (fresh && (Math.abs(indY - BotState.indicatorY) > 120 || Math.abs(tgtY - BotState.targetY) > 150) && glitch < 3) {
            glitch++;
            return;
        }
        glitch = 0;
        BotState.indicatorY = indY;
        BotState.targetY = tgtY;
        BotState.targetH = (knownBoxH > 0 ? knownBoxH : span) * DIV;
        BotState.lastSeen = nowMs;
        if (BotState.running) Trace.add("F", BotState.indicatorY, BotState.targetY, BotState.targetH, 0);
        if (scanCollect) findCollectButton(buf, rs, ps, c);
    }

    /**
     * Looks for the round white "collect" button (55-95 px wide) in the middle of the screen. Its position follows the
     * fish in the water, so a fixed tap point can miss it.
     */
    private void findCollectButton(ByteBuffer buf, int rs, int ps, Config c) {
        final int x0 = 300 / DIV, x1 = Math.min(cw, 2100 / DIV);
        final int y0 = 260 / DIV, y1 = Math.min(ch, 800 / DIV);
        final int w = x1 - x0, h = y1 - y0;
        if (w <= 0 || h <= 0) return;
        if (cmask == null || cmask.length != w * h) { cmask = new byte[w * h]; cstack = new int[w * h]; }
        for (int yy = 0; yy < h; yy++) {
            int base = (y0 + yy) * rs;
            for (int xx = 0; xx < w; xx++) {
                int o = base + (x0 + xx) * ps;
                boolean white = (buf.get(o) & 0xFF) > 220 && (buf.get(o + 1) & 0xFF) > 220 && (buf.get(o + 2) & 0xFF) > 220;
                cmask[yy * w + xx] = (byte) (white ? 1 : 0);
            }
        }
        int bestX = -1, bestY = -1;
        double bestDist = Double.MAX_VALUE;
        for (int start = 0; start < w * h; start++) {
            if (cmask[start] != 1) continue;
            int sp = 0, area = 0;
            int minX = w, maxX = 0, minY = h, maxY = 0;
            cstack[sp++] = start;
            cmask[start] = 2;
            while (sp > 0) {
                int p = cstack[--sp];
                int px = p % w, py = p / w;
                area++;
                if (px < minX) minX = px;
                if (px > maxX) maxX = px;
                if (py < minY) minY = py;
                if (py > maxY) maxY = py;
                if (px > 0 && cmask[p - 1] == 1) { cmask[p - 1] = 2; cstack[sp++] = p - 1; }
                if (px < w - 1 && cmask[p + 1] == 1) { cmask[p + 1] = 2; cstack[sp++] = p + 1; }
                if (py > 0 && cmask[p - w] == 1) { cmask[p - w] = 2; cstack[sp++] = p - w; }
                if (py < h - 1 && cmask[p + w] == 1) { cmask[p + w] = 2; cstack[sp++] = p + w; }
            }
            int bw = maxX - minX + 1, bh = maxY - minY + 1;
            if (bw < 54 / DIV || bw > 96 / DIV || bh < 54 / DIV || bh > 96 / DIV) continue;   // 54-96 px at full size
            double ratio = bw / (double) bh;
            if (ratio < 0.8 || ratio > 1.25) continue;
            double fill = area / (double) (bw * bh);
            if (fill < 0.45 || fill > 0.9) continue;                                // a disc with a dark finger inside
            int fx = (x0 + (minX + maxX) / 2) * DIV, fy = (y0 + (minY + maxY) / 2) * DIV;
            double dist = Math.hypot(fx - c.colX, fy - c.colY);
            if (dist < bestDist) { bestDist = dist; bestX = fx; bestY = fy; }
        }
        if (bestX >= 0) {
            BotState.collectX = bestX;
            BotState.collectY = bestY;
            BotState.collectTime = System.currentTimeMillis();
        }
    }


    // ---------------------------------------------------------------- bot loop

    private void toggle() {
        if (!BotState.projectionReady) {
            BotState.status = "Grant screen capture first";
            return;
        }
        if (BotState.running) {
            BotState.running = false;
            BotState.status = "Stopped";
            BotState.note = "";
        } else {
            if (InputService.instance == null) {
                BotState.status = "Enable the Accessibility service first";
                BotState.note = "ACCESS OFF";
                ui.postDelayed(() -> BotState.note = "", 3500);
                return;
            }
            BotState.gOk = 0; BotState.gCancel = 0; BotState.gFail = 0;
            BotState.rounds = 0; BotState.startedAt = System.currentTimeMillis();
            cfg = Config.load(this);
            state = CASTING; lastCast = 0; lastInd = -1; vel = 0; integ = 0; acc = 0;
            BotState.driverFails = 0;
            BotState.response = 0; noResp = 0; liftStart = 0; lastCtrlMs = 0;
            loadArms(); armInit = false; Trace.reset();
            startAt = System.currentTimeMillis() + cfg.startDelay * 1000L;
            BotState.running = true;
            BotState.status = "Starting...";
        }
        updateNotification();
    }

    private void loop() {
        while (alive) {
            try {
                if (!BotState.running) {
                    scanCollect = false;
                    InputService rin = InputService.instance;
                    if (rin != null) rin.release();
                    sleep(100);
                    continue;
                }
                InputService in = InputService.instance;
                if (in == null) { BotState.status = "Enable the Accessibility service"; BotState.note = "ACCESS OFF"; sleep(500); continue; }
                long now = System.currentTimeMillis();
                if (now < startAt) {
                    BotState.status = "Starting in " + ((startAt - now) / 1000 + 1) + "s - switch to the game";
                    BotState.note = "get ready";
                    sleep(150);
                    continue;
                }
                Config c = cfg;

                if (now - BotState.lastSeen < 300) {           // minigame on screen
                    if (state != PLAYING) playBegan = now;
                    state = PLAYING;
                    lastActive = now;
                    control(in, c);
                    continue;
                }
                lastInd = -1; vel = 0; integ = 0; acc = 0; lastCtrlMs = 0;
                in.release();

                switch (state) {
                    case PLAYING:
                        if (now - lastActive > 1500) {
                            // the bar must be gone for 1.5 s (short dropouts happen); a very short 'minigame' was just a misread
                            if (lastActive - playBegan > 1500) { state = FINISHING; BotState.rounds++; }
                            else { state = WAITING; lastCast = System.currentTimeMillis(); }
                        } else sleep(25);
                        break;
                    case FINISHING: {
                        BotState.status = "Collecting";
                        BotState.note = "collecting";
                        boolean resumed = false;
                        if (c.collectOn) {
                            // The collect button follows the fish and can lag: look for it (up to 5 s), hold it, and check
                            // that it went away; retry up to 3 times. If the bar comes back, go straight back to playing.
                            scanCollect = true;
                            long w0 = System.currentTimeMillis();
                            while (alive && BotState.running && System.currentTimeMillis() - w0 < 5000
                                    && System.currentTimeMillis() - BotState.collectTime > 400) {
                                if (barBack()) { resumed = true; break; }
                                sleep(50);
                            }
                            for (int attempt = 0; attempt < 3 && !resumed && alive && BotState.running; attempt++) {
                                if (barBack()) { resumed = true; break; }
                                boolean found = System.currentTimeMillis() - BotState.collectTime < 400;
                                int hx = found ? BotState.collectX : c.colX, hy = found ? BotState.collectY : c.colY;
                                BotState.note = found ? "collect found" : "collect (fixed spot)";
                                in.pressAndWait(hx, hy, c.collectHold);
                                if (sleepWatch(500)) { resumed = true; break; }
                                if (System.currentTimeMillis() - BotState.collectTime >= 700) break;   // button gone -> collected
                            }
                            scanCollect = false;
                        } else {
                            resumed = sleepWatch(500);
                        }
                        if (resumed) { state = PLAYING; BotState.rounds = Math.max(0, BotState.rounds - 1); playBegan = System.currentTimeMillis(); lastActive = playBegan; }
                        else state = CASTING;
                        break;
                    }
                    case CASTING:
                        BotState.status = "Casting";
                        BotState.note = "casting";
                        in.hold(c.castX, c.castY, c.castPress);   // press the hand-icon cast button
                        sleepWatch(c.castPress + c.castWait);
                        lastCast = System.currentTimeMillis();
                        state = WAITING;
                        break;
                    default: // WAITING
                        BotState.status = "Waiting for a bite";
                        BotState.note = "no bar yet";
                        if (now - lastCast > c.failWait) state = CASTING; else sleep(30);
                }
            } catch (Throwable t) {
                BotState.status = "Error: " + t.getClass().getSimpleName();
                sleep(500);
            }
        }
    }

    /**
     * PD(+I) controller. The result is a "duty": the share of time the finger should be down.
     * Smooth mode turns it into press/release decisions every tick (sigma-delta) and lets InputService keep one touch
     * down between presses. If the phone rejects that, it falls back to one plain press per cycle.
     */
    private void control(InputService in, Config c) {
        double ind = BotState.indicatorY, tgt = BotState.targetY;
        long ft = BotState.lastSeen;
        if (lastInd >= 0 && ft > lastIndTime) {
            double dt = (ft - lastIndTime) / 1000.0;
            if (dt > 0.005 && dt < 0.8) vel = 0.6 * vel + 0.4 * (((ind - tgt) - (lastInd - lastTgt)) / dt);   // rate of change of the ERROR
            vel = Math.max(-1500, Math.min(1500, vel));
        }
        if (ft != lastIndTime) { lastInd = ind; lastTgt = tgt; lastIndTime = ft; }
        final int tick = Math.max(20, c.cycle);
        final long nowC = System.currentTimeMillis();
        final double dtc = lastCtrlMs == 0 ? tick / 1000.0 : Math.min(0.4, (nowC - lastCtrlMs) / 1000.0);
        lastCtrlMs = nowC;

        double bar = Math.max(100, c.h);
        double e = (ind - tgt) / bar;        // > 0 : square is below the target, needs to rise
        double v = vel / bar;                // > 0 : error is growing (square falling away / target rising)
        integ = Math.max(-0.6, Math.min(0.6, integ + e * dtc));
        double duty = c.hoverPct / 100.0 + (c.kp10 / 10.0) * e + (c.kd10 / 10.0) * v + (c.ki10 / 10.0) * integ;
        if (c.invert) duty = 1.0 - duty;     // for a game where holding moves the square DOWN
        duty = Math.max(0, Math.min(1, duty));

        // ---- which press style is active? (Auto learns from how long the square stays inside the box)
        trackStyle(in, c, dtc, Math.abs(ind - tgt) < BotState.targetH / 2);

        // ---- response check: does the game actually move the square when we press?
        final long nowMs = System.currentTimeMillis();
        final boolean room = c.invert ? ind < c.y + c.h - 60 : ind > c.y + 60;
        if (duty > 0.8 && room) {
            if (liftStart == 0) { liftStart = nowMs; liftInd = ind; }
            double moved = c.invert ? ind - liftInd : liftInd - ind;
            if (moved >= 6) {
                BotState.response = 1; noResp = 0; liftStart = nowMs; liftInd = ind;
            } else if (nowMs - liftStart > 700) {
                noResp++;
                liftStart = 0;
                if (noResp >= 2) onNoResponse(c);
            }
        } else {
            liftStart = 0;
        }

        final boolean smooth = arm == 1 && BotState.driverFails < 6;
        final String armName = arm == 1 ? "smooth" : "presses";
        BotState.status = String.format(Locale.US, "Tracking  err %+.0f px  hold %d%%", ind - tgt, (int) (duty * 100))
                + (BotState.response < 0 ? "   [game not reacting]" : "");
        BotState.note = BotState.response < 0 ? "NO RESPONSE"
                : String.format(Locale.US, smooth ? "%s  %d%%  g %d/%d" : "%s  %d%%  lag %dms",
                        armName, (int) (duty * 100), smooth ? BotState.gOk : BotState.pressLagMs, smooth ? BotState.gCancel : 0);

        if (smooth) {
            acc += duty;
            boolean wantDown = false;
            if (acc >= 1.0) { wantDown = true; acc -= 1.0; }
            Trace.add("S", wantDown ? 1 : 0, duty, e, 2);
            in.setHold(c.cx, c.cy, wantDown);
            sleep(Math.max(40, tick));
            return;
        }

        // ---- safe presses: send one press, wait until the phone has finished it, then decide again.
        // (Sending the next press early cancelled the previous one - most presses were being lost.)
        acc = Math.min(acc + duty, 2.0);
        if (acc >= 1.0) {
            acc -= 1.0;
            // Long presses when we must push hard (the game's gravity needs the finger down ~2/3 of the time, and every
            // press has some dead time), short ones when only a small correction is needed.
            int len = (int) Math.round(c.pressMs + (c.pressMax - c.pressMs) * duty);
            Trace.add("P", len, duty, e, arm);
            boolean ok = in.pressAndWait(c.cx, c.cy, len);
            Trace.add("E", ok ? 1 : 0, BotState.pressLagMs, 0, 0);
        } else {
            sleep(tick);
        }
    }

    // ---------------------------------------------------------------- style learning

    /** Time-weighted share of the window the square spent inside the box; picks the style for the next window. */
    private void trackStyle(InputService in, Config c, double dtc, boolean inside) {
        if (!armInit) {
            armInit = true;
            arm = chooseArm(c);
            winIn = 0; winTot = 0;
            updateStyleInfo(c);
        }
        if (c.style != 0) {                  // a style was picked by hand: no learning
            if (arm != c.style - 1) { if (arm == 1) in.release(); arm = c.style - 1; updateStyleInfo(c); }
            return;
        }
        winTot += dtc;
        if (inside) winIn += dtc;
        if (winTot >= 6.0) {
            double frac = winIn / winTot;
            armScore[arm] = armTries[arm] == 0 ? frac : 0.6 * armScore[arm] + 0.4 * frac;
            armTries[arm]++;
            saveArms();
            Trace.add("W", arm, frac, armScore[arm], 0);
            int next = chooseArm(c);
            if (arm == 1 && next != 1) in.release();
            arm = next;
            winIn = 0; winTot = 0;
            updateStyleInfo(c);
        }
    }

    private int chooseArm(Config c) {
        if (c.style != 0) return c.style - 1;
        final int n = BotState.driverFails < 6 ? 2 : 1;
        int least = 0;
        for (int i = 1; i < n; i++) if (armTries[i] < armTries[least]) least = i;
        if (armTries[least] < 2) return least;                    // try every style twice first
        int best = 0;
        for (int i = 1; i < n; i++) if (armScore[i] > armScore[best]) best = i;
        if (Math.random() < 0.2) return (best + 1 + (int) (Math.random() * (n - 1))) % n;   // now and then re-check another style
        return best;
    }

    private void updateStyleInfo(Config c) {
        final String[] nm = {"presses", "smooth"};
        StringBuilder sb = new StringBuilder(c.style == 0 ? "auto" : "fixed");
        sb.append(": ").append(nm[Math.max(0, Math.min(1, arm))]).append("   |   ");
        for (int i = 0; i < 2; i++) {
            sb.append(nm[i]).append(' ');
            sb.append(armTries[i] == 0 ? "-" : String.format(Locale.US, "%d%%", (int) Math.round(armScore[i] * 100)));
            if (i < 1) sb.append("   ");
        }
        BotState.styleInfo = sb.toString();
    }

    private void saveArms() {
        SharedPreferences.Editor ed = getSharedPreferences("bot", MODE_PRIVATE).edit();
        for (int i = 0; i < 3; i++) ed.putFloat("as" + i, (float) armScore[i]).putInt("at" + i, armTries[i]);
        ed.apply();
    }

    private void loadArms() {
        SharedPreferences p = getSharedPreferences("bot", MODE_PRIVATE);
        for (int i = 0; i < 3; i++) { armScore[i] = p.getFloat("as" + i, -1f); armTries[i] = p.getInt("at" + i, 0); }
    }

    /** The square did not rise although we pressed hard for a while. */
    private void onNoResponse(Config c) {
        noResp = 0;
        if (arm == 1 && BotState.driverFails < 6) {
            BotState.driverFails += 100;     // smooth hold is not working on this phone -> plain presses
        } else {
            BotState.response = -1;          // plain presses do not work either: the Hold point is being ignored
        }
    }

    /** True when the fishing bar is on screen right now. */
    private boolean barBack() {
        return System.currentTimeMillis() - BotState.lastSeen < 400;
    }

    /** Sleeps in small steps and stops early (returning true) as soon as the bar shows up. */
    private boolean sleepWatch(long ms) {
        long end = System.currentTimeMillis() + ms;
        while (alive && BotState.running && System.currentTimeMillis() < end) {
            if (barBack()) return true;
            sleep(30);
        }
        return false;
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    // ---------------------------------------------------------------- floating button

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!alive) return;
            try {
                cfg = Config.load(ProjectionService.this);   // pick up Tune-tab changes live
                ensureOverlay();
                refreshOverlay();
                if (BotState.running != lastShownRunning) {
                    lastShownRunning = BotState.running;
                    updateNotification();
                }
            } catch (Throwable ignored) {}
            ui.postDelayed(this, 300);
        }
    };

    /**
     * Small draggable START/STOP bubble over the game. While the bot runs, its own gestures can cancel a
     * finger that is still down, so STOP fires on touch-DOWN (not on release).
     */
    private void ensureOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return;
        final WindowManager wm = getSystemService(WindowManager.class);
        final float d = getResources().getDisplayMetrics().density;
        final int size = (int) (58 * d);
        final TextView t = new TextView(this);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setMinWidth(size);
        t.setMinHeight(size);
        t.setPadding((int) (10 * d), (int) (6 * d), (int) (10 * d), (int) (6 * d));
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        final SharedPreferences sp = getSharedPreferences("bot", MODE_PRIVATE);
        Point real = Config.realSize(this);
        lp.x = sp.getInt("ox", (int) (8 * d));
        lp.y = sp.getInt("oy", real.y / 2 - size / 2);

        t.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean handled, dragging;
            final Runnable longPress = new Runnable() {
                @Override public void run() {
                    if (dragging || handled || BotState.running) return;
                    handled = true;
                    InputService in = InputService.instance;
                    Config c = cfg;
                    if (in == null) { BotState.note = "ACCESS OFF"; return; }
                    in.hold(c.cx, c.cy, 2000);            // test: does the game react to an injected hold?
                    BotState.note = "test hold 2s";
                    ui.postDelayed(() -> BotState.note = "", 2400);
                }
            };

            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = lp.x; startY = lp.y;
                        dragging = false; handled = false;
                        if (BotState.running) { handled = true; toggle(); refreshOverlay(); }
                        else ui.postDelayed(longPress, 700);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (handled) return true;
                        float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                        if (!dragging && Math.hypot(dx, dy) > 12 * d) { dragging = true; ui.removeCallbacks(longPress); }
                        if (dragging) {
                            lp.x = startX + (int) dx;
                            lp.y = startY + (int) dy;
                            wm.updateViewLayout(v, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ui.removeCallbacks(longPress);
                        if (handled) return true;
                        if (dragging) sp.edit().putInt("ox", lp.x).putInt("oy", lp.y).apply();
                        else { toggle(); refreshOverlay(); }
                        return true;
                    default:
                        ui.removeCallbacks(longPress);
                        return true;
                }
            }
        });

        try {
            wm.addView(t, lp);
            overlay = t;
            refreshOverlay();
        } catch (Throwable ex) {
            BotState.status = "Floating button error: " + ex.getClass().getSimpleName();
        }
    }

    private void refreshOverlay() {
        if (overlay == null) return;
        boolean on = BotState.running;
        long now = System.currentTimeMillis();
        String label = !on ? "START" : (now < startAt ? String.valueOf((startAt - now) / 1000 + 1) : "STOP");
        String note = BotState.note == null ? "" : BotState.note;
        if (note.isEmpty()) {
            overlay.setText(label);
        } else {
            SpannableString sp = new SpannableString(label + "\n" + note);
            sp.setSpan(new RelativeSizeSpan(0.7f), label.length() + 1, sp.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            overlay.setText(sp);
        }
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(29 * getResources().getDisplayMetrics().density);
        bg.setColor(on ? 0xCCC62828 : 0xCC2E7D32);
        overlay.setBackground(bg);
    }

    private void removeOverlay() {
        try {
            if (overlay != null) getSystemService(WindowManager.class).removeView(overlay);
        } catch (Throwable ignored) {}
        overlay = null;
    }

    // ---------------------------------------------------------------- notification

    private void startForegroundCompat() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Fishing Bot", NotificationManager.IMPORTANCE_LOW));
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private Notification buildNotification() {
        Intent t = new Intent(this, ProjectionService.class).setAction(ACTION_TOGGLE);
        PendingIntent toggle = PendingIntent.getService(this, 1, t,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this, 2, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean on = BotState.running;
        Notification.Action a = new Notification.Action.Builder(
                Icon.createWithResource(this, on ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play),
                on ? "STOP bot" : "START bot", toggle).build();
        Intent q = new Intent(this, ProjectionService.class).setAction(ACTION_QUIT);
        PendingIntent quit = PendingIntent.getService(this, 3, q,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Action stopCap = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "STOP capture", quit).build();
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Slayers 2 Fishing Bot")
                .setContentText(on ? "Running" : "Idle - tap START when the game is open")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .setContentIntent(open)
                .addAction(a)
                .addAction(stopCap)
                .build();
    }

    private void updateNotification() {
        getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification());
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onDestroy() {
        alive = false;
        BotState.running = false;
        BotState.status = "Screen capture stopped";
        BotState.note = "";
        InputService rin = InputService.instance;
        if (rin != null) rin.release();
        ui.removeCallbacks(tick);
        removeOverlay();
        releaseCapture();
        if (worker != null) worker.interrupt();
        super.onDestroy();
    }
}
