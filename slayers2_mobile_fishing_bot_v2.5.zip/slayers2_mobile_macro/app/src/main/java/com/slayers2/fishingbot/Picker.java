package com.slayers2.fishingbot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

/**
 * "Pick on screen": a see-through full-screen layer over the game. You tap where you want a point
 * (cast spot, hold spot, bar corners); the raw screen coordinates are handed back.
 */
final class Picker {
    interface Done { void onDone(float[] xs, float[] ys); }

    private Picker() {}

    static void start(final Context ctx, final String[] prompts, final Done done) {
        if (!Settings.canDrawOverlays(ctx)) return;
        final WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        final PickView v = new PickView(ctx, prompts);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        v.setListener(new PickView.Listener() {
            @Override public void finished(float[] xs, float[] ys) {
                v.post(() -> { try { wm.removeView(v); } catch (Throwable ignored) {} });
                done.onDone(xs, ys);
            }
            @Override public void cancelled() {
                v.post(() -> { try { wm.removeView(v); } catch (Throwable ignored) {} });
            }
        });
        try { wm.addView(v, lp); } catch (Throwable ignored) {}
    }

    static final class PickView extends View {
        interface Listener { void finished(float[] xs, float[] ys); void cancelled(); }

        private final String[] prompts;
        private final float[] xs, ys, vx, vy;
        private int step = 0;
        private Listener listener;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();

        PickView(Context c, String[] prompts) {
            super(c);
            this.prompts = prompts;
            xs = new float[prompts.length]; ys = new float[prompts.length];
            vx = new float[prompts.length]; vy = new float[prompts.length];
        }

        void setListener(Listener l) { listener = l; }

        @Override protected void onDraw(Canvas cv) {
            float d = getResources().getDisplayMetrics().density;
            float w = getWidth();
            cv.drawColor(0x33000000);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xF00E1224);
            cv.drawRect(0, 0, w, 74 * d, p);

            p.setTextAlign(Paint.Align.LEFT);
            p.setColor(0xFF4FD1C5);
            p.setTextSize(14 * d);
            cv.drawText("Step " + Math.min(step + 1, prompts.length) + " of " + prompts.length, 16 * d, 26 * d, p);
            p.setColor(0xFFFFFFFF);
            p.setTextSize(17 * d);
            cv.drawText(step < prompts.length ? prompts[step] : "Done", 16 * d, 56 * d, p);

            p.setColor(0xFFE5484D);
            r.set(w - 110 * d, 12 * d, w - 12 * d, 62 * d);
            cv.drawRoundRect(r, 12 * d, 12 * d, p);
            p.setColor(0xFFFFFFFF);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(15 * d);
            cv.drawText("Cancel", w - 61 * d, 44 * d, p);

            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3 * d);
            for (int i = 0; i < step; i++) {
                p.setColor(0xFF4FD1C5);
                cv.drawCircle(vx[i], vy[i], 16 * d, p);
                cv.drawLine(vx[i] - 24 * d, vy[i], vx[i] + 24 * d, vy[i], p);
                cv.drawLine(vx[i], vy[i] - 24 * d, vx[i], vy[i] + 24 * d, p);
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() != MotionEvent.ACTION_DOWN) return true;
            float d = getResources().getDisplayMetrics().density;
            if (e.getX() > getWidth() - 120 * d && e.getY() < 70 * d) {
                if (listener != null) listener.cancelled();
                return true;
            }
            if (step < prompts.length) {
                xs[step] = e.getRawX(); ys[step] = e.getRawY();
                vx[step] = e.getX(); vy[step] = e.getY();
                step++;
                invalidate();
                if (step >= prompts.length && listener != null) listener.finished(xs, ys);
            }
            return true;
        }
    }
}
